<?php $__env->startSection('style'); ?>
    <style>
        .loader {
            border: 16px solid #f3f3f3; /* Light grey */
            border-top: 16px solid #3498db; /* Blue */
            border-radius: 50%;
            width: 120px;
            height: 120px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }


        .header {
            position: sticky;
            top: 0;
            background-color: #fff;
        }
        @media print {
            .to_hide {
                display: none !important;
            }
            #print_content {
                display: block !important;
            }
            #account_list table {
                table-layout: fixed;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row g-3 m-2 to_hide">
        <div class="col">
            <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.From Date")); ?></label>
            <input type="date" name="from_date" value="<?php echo e(date("Y-m-d",time())); ?>" class="form-control search_keys"
                id="from_date">
        </div>

        <div class="col">
            <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.To Date")); ?></label>
            <input type="date" name="to_date" value="<?php echo e(date("Y-m-d",time())); ?>" class="form-control search_keys"
                id="from_date">
        </div>

        <div class="col">
            <br>
            <button type="button" id="search_button" class="btn btn-sm btn-success float-right mt-2">
                <i class="fa fa-search"></i> <?php echo e(__("finance::finance.Search")); ?>

            </button>
        </div>

    </div>
    <div class="row g-3 m-2" id="account_list"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('.select2').select2();
        $("#search_button").on("click", function (e) {
            e.preventDefault()
            var emptyFields = $(".search_keys").filter(function () {
                return $(this).val() === "";
            });

            if (emptyFields.length > 0) {
                alert("يرجي ادخال كل البيانات اولا");
            } else {
                var data = $(".search_keys").serialize();
                let url = '<?php echo e(route("finance.income-list.index")); ?>';
                $.ajax({
                    url: url,
                    type: 'GET',
                    data: data,
                    beforeSend: function () {
                        $("#account_list").html('<div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">' +
                            '  <div class="loader" style="margin: auto;"></div>' +
                            '</div>');
                    },
                    success: function (result) {
                        console.log(result);
                        $("#account_list").html(result.data.html)
                        // $("#account_list").html(result.data2.html)
                    },
                    error: function (errorObj, errorText, errorThrown) {
                        handleErrorResponce(errorObj);
                    }
                });
            }

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/income_list/index.blade.php ENDPATH**/ ?>