<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- First row with two text inputs -->
        <div class="col-md-6">
            <label for="taxRateExpenditure" class="form-label"><?php echo e(__('finance::finance.Tax expense ratio')); ?>:</label>
            <input type="hidden" value="tax_rate_expenditure" id="taxRateExpenditureTitle"
                name="data[tax_rate_expenditure][title]">
            
            <label for="TextInput" class="form-label">
                
                <?php echo addUpButton(route('finance.tax-setting.create'), 'tax_rate_expenditure', false, 'name', true); ?>

            </label> <select name="data[tax_rate_expenditure][value]" id="tax_rate_expenditure"
                class="form-control tax-rate-value">
                <option value=""><?php echo e(__('finance::finance.choose')); ?></option>
                <?php $__currentLoopData = $tax_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"
                        <?php echo e($obj->get('tax_rate_expenditure') && $obj->get('tax_rate_expenditure')->value == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6">
            <label for="taxRateRevenue" class="form-label"><?php echo e(__('finance::finance.Tax to revenue ratio')); ?>:</label>
            <input type="hidden" value="tax_rate_revenue" id="taxRateRevenueTitle" name="data[tax_rate_revenue][title]">
            <label for="TextInput" class="form-label">
                            <?php echo e(__('finance::finance.taxSettings')); ?>

                <?php echo addUpButton(route('finance.tax-setting.create'), 'tax_rate_revenue', false, 'name', true); ?>

            </label>
            <select name="data[tax_rate_revenue][value]" id="tax_rate_revenue" class="form-control tax-rate-value">
                <option value=""><?php echo e(__('finance::finance.choose')); ?></option>
                <?php $__currentLoopData = $tax_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"
                        <?php echo e($obj->get('tax_rate_revenue') && $obj->get('tax_rate_revenue')->value == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Bonds Accounts -->
        <div class="col-md-6">
            <label for="taxRateRevenue" class="form-label"><?php echo e(__('finance::finance.Bond Sarf Account')); ?>:</label>
            <input type="hidden" value="bond_sarf_account" id="taxRateRevenueTitle" name="data[bond_sarf_account][title]">
            <label for="TextInput" class="form-label">
                            <?php echo e(__('finance::finance.Directory account')); ?>

                <?php echo addUpButton(route('finance.accounts.create'), 'bond_sarf_account', false, 'name', true); ?>

            </label>
            <select name="data[bond_sarf_account][value]" id="bond_sarf_account" class="form-control select2">
                <option value=""><?php echo e(__('finance::finance.choose')); ?></option>
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"
                        <?php echo e($obj->get('bond_sarf_account') && $obj->get('bond_sarf_account')->value == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-6">
            <label for="taxRateRevenue" class="form-label"><?php echo e(__('finance::finance.Bond Qabd Account')); ?>:</label>
            <input type="hidden" value="bond_qabd_account" id="bondQabdAccount" name="data[bond_qabd_account][title]">
            <label for="TextInput" class="form-label">
                            <?php echo e(__('finance::finance.Directory account')); ?>

                <?php echo addUpButton(route('finance.accounts.create'), 'bond_qabd_account', false, 'name', true); ?>

            </label>
            <select name="data[bond_qabd_account][value]" id="bond_qabd_account" class="form-control select2">
                <option value=""><?php echo e(__('finance::finance.choose')); ?></option>
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"
                        <?php echo e($obj->get('bond_qabd_account') && $obj->get('bond_qabd_account')->value == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <!-- Bonds Accounts -->

        <!-- Cost Center Radio Buttons -->
        

        <?php if(auth('admin')->user()->admin_type == \App\Enums\AdminTypeisEnum::Developer->value): ?>
            <div class="col-md-6">
                <label class="form-label"><?php echo e(__('finance::finance.Screens need to cost centers')); ?>:</label>
                <div class="form-check">
                    <input type="hidden" name="data[cost_center_sarf_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="costCenterSarfBond"
                        name="data[cost_center_sarf_bond][value]"
                        <?php echo e(($obj->get('cost_center_sarf_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="cost_center_sarf_bond" name="data[cost_center_sarf_bond][title]">
                    <label class="form-check-label" for="costCenterSarfBond"><?php echo e(__('finance::finance.sarf_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[cost_center_qabd_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="costCenterQabdBond"
                        name="data[cost_center_qabd_bond][value]"
                        <?php echo e(($obj->get('cost_center_qabd_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="cost_center_qabd_bond" name="data[cost_center_qabd_bond][title]">
                    <label class="form-check-label" for="costCenterQabdBond"><?php echo e(__('finance::finance.qabd_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[cost_center_general_sarf_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="costCenterGeneralSarfBond"
                        name="data[cost_center_general_sarf_bond][value]"
                        <?php echo e(($obj->get('cost_center_general_sarf_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="cost_center_general_sarf_bond"
                        name="data[cost_center_general_sarf_bond][title]">
                    <label class="form-check-label"
                        for="costCenterGeneralSarfBond"><?php echo e(__('finance::finance.general_sarf_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[cost_center_general_qabd_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="costCenterGeneralQabdBond"
                        name="data[cost_center_general_qabd_bond][value]"
                        <?php echo e(($obj->get('cost_center_general_qabd_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="cost_center_general_qabd_bond"
                        name="data[cost_center_general_qabd_bond][title]">
                    <label class="form-check-label"
                        for="costCenterGeneralQabdBond"><?php echo e(__('finance::finance.general_qabd_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[cost_center_account_transfer][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="costCenterAccountTransfer"
                        name="data[cost_center_account_transfer][value]"
                        <?php echo e(($obj->get('cost_center_account_transfer')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="cost_center_account_transfer"
                        name="data[cost_center_account_transfer][title]">
                    <label class="form-check-label"
                        for="costCenterAccountTransfer"><?php echo e(__('finance::finance.account_transfers')); ?></label>
                </div>
            </div>

            <!-- Second row with multiple checkboxes -->
            <div class="col-md-6">
                <label class="form-label"><?php echo e(__('finance::finance.Screens need to be approved')); ?>:</label>
                <div class="form-check">
                    <input type="hidden" name="data[sarf_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="sarfBond"
                        name="data[sarf_bond][value]" <?php echo e(($obj->get('sarf_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="sarf_bond" name="data[sarf_bond][title]">
                    <label class="form-check-label" for="sarfBond"><?php echo e(__('finance::finance.sarf_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[qabd_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="qabdBond"
                        name="data[qabd_bond][value]" <?php echo e(($obj->get('qabd_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="qabd_bond" name="data[qabd_bond][title]">
                    <label class="form-check-label" for="qabdBond"><?php echo e(__('finance::finance.qabd_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[general_sarf_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="generalSarfBond"
                        name="data[general_sarf_bond][value]"
                        <?php echo e(($obj->get('general_sarf_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="general_sarf_bond" name="data[general_sarf_bond][title]">
                    <label class="form-check-label" for="generalSarfBond"><?php echo e(__('finance::finance.general_sarf_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[general_qabd_bond][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="generalQabdBond"
                        name="data[general_qabd_bond][value]"
                        <?php echo e(($obj->get('general_qabd_bond')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="general_qabd_bond" name="data[general_qabd_bond][title]">
                    <label class="form-check-label" for="generalQabdBond"><?php echo e(__('finance::finance.general_qabd_bond')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[account_transfer][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="accountTransfer"
                        name="data[account_transfer][value]"
                        <?php echo e(($obj->get('account_transfer')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="account_transfer" name="data[account_transfer][title]">
                    <label class="form-check-label" for="accountTransfer"><?php echo e(__('finance::finance.account_transfers')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[bill_sales][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="bill_sales"
                           name="data[bill_sales][value]"
                        <?php echo e(($obj->get('bill_sales')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="general_qabd_bond" name="data[bill_sales][title]">
                    <label class="form-check-label" for="bill_sales"><?php echo e(__('finance::finance.bill-sales')); ?></label>
                </div>
                <div class="form-check">
                    <input type="hidden" name="data[bill_purchases][value]" value="off">
                    <input class="form-check-input" type="checkbox" value="on" id="bill_purchases"
                           name="data[bill_purchases][value]"
                        <?php echo e(($obj->get('bill_purchases')->value ?? 'off') == 'on' ? 'checked' : ''); ?>>
                    <input type="hidden" value="bill_purchases" name="data[bill_purchases][title]">
                    <label class="form-check-label" for="bill_sales"><?php echo e(__('finance::finance.bill_purchases')); ?></label>
                </div>
            </div>
        <?php endif; ?>

        <!-- Modal footer with buttons -->
        <div class="col-12 modal-footer">
            <?php echo submitButton($storeRoute); ?>

        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('.select2').select2({
            dropdownParent: $('#upCreateModal .modal-body'),
        });
        $('.select2').select2();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/confirm_settings/index.blade.php ENDPATH**/ ?>