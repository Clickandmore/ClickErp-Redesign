<div class="container">
    <div class="row align-items-start">
        <?php if(isset($settings)): ?>
            <!-- الشعار والوصف -->
            <div class="col-lg-4 col-md-6 mb-4 mb-md-0 footer-about">
                <img src="<?php echo e(showFile($settings->logo_footer)); ?>" alt="Logo" class="footer-logo" />
                <p class="footer-desc">
                    <?php echo e($settings->footer_text); ?>

                </p>

                <div class="tax-info">
                    <img src="<?php echo e(asset('site/assets/images/zatca-logo.png')); ?>" alt="شعار هيئة الزكاة والضريبة والجمارك" class="tax-logo" />
                    <p class="tax-number">
                        الرقم الضريبي: <span><?php echo e($settings->tax_number ?? '310012345600003'); ?></span>
                    </p>
                </div>

              
            </div>
        <?php else: ?>
            <!-- الحالة الافتراضية -->
            <div class="col-lg-4 col-md-6 mb-4 footer-about">
                <img src="<?php echo e(asset('site/assets/images/logo.svg')); ?>" alt="Logo" class="footer-logo" />
                <p class="footer-desc">
                    بلاتينيوم للاستقدام يقدم خدمات استقدام العمالة المنزلية باحترافية وجودة مميزة.
                </p>

                <div class="tax-info">
                    <img src="<?php echo e(asset('site/assets/images/zatca-logo.png')); ?>" alt="شعار هيئة الزكاة والضريبة والجمارك" class="tax-logo" />
                    <p class="tax-number">الرقم الضريبي: <span>310012345600003</span></p>
                </div>

               
            </div>
        <?php endif; ?>

        <!-- خدماتنا -->
        <div class="col-6 col-lg-2 col-md-6 mb-4">
            <h6 class="footer-title"><?php echo e(__("ingaz.our_services")); ?></h6>
            <ul class="footer-links">
                <li><a href="<?php echo e(route('site.all-workers.index')); ?>?type=estqdam"><?php echo e(__("ingaz.recruitment_request")); ?></a></li>
                <li><a href="<?php echo e(route('site.all-workers.index')); ?>?type=egar"><?php echo e(__("ingaz.labor_rental_request")); ?></a></li>
                <li><a href="<?php echo e(route('site.daily-lebor-demand.index')); ?>"><?php echo e(__("ingaz.request_professional_labor")); ?></a></li>
                <li><a href="<?php echo e(route('site.renew-contract.index')); ?>"><?php echo e(__("ingaz.renewing_employment_contract")); ?></a></li>
            </ul>
        </div>

        <!-- سياسات الاستقدام -->
        <div class="col-6 col-lg-3 col-md-6 mb-4">
            <h6 class="footer-title"><?php echo e(__("ingaz.recruitment_policies")); ?></h6>
            <ul class="footer-links">
                <li><a href="<?php echo e(route('site.visa.index')); ?>"><?php echo e(__("ingaz.visa_issuance")); ?></a></li>
                <li><a href="<?php echo e(route('site.select-worker.index')); ?>"><?php echo e(__("ingaz.selection_of_workers")); ?></a></li>
                <li><a href="<?php echo e(route('site.all-workers.index')); ?>"><?php echo e(__("ingaz.recruitment_contract")); ?></a></li>
                <li><a href="<?php echo e(route('site.arrival-worker.index')); ?>"><?php echo e(__("ingaz.arrival_worker")); ?></a></li>
            </ul>
        </div>

        <!-- تواصل معنا -->
        <div class="col-12 col-lg-3 col-md-6 mb-4">
            <h6 class="footer-title"><?php echo e(__("ingaz.contact_us")); ?></h6>
            <ul class="footer-contact">
                <?php if(isset($settings)): ?>
                    <li><i class="fa-solid fa-map-marker-alt"></i> <?php echo e($settings->location); ?></li>
                    <li><i class="fas fa-envelope"></i> <?php echo e($settings->email); ?></li>
                    <li><i class="fa-solid fa-phone"></i> <?php echo e($settings->phone); ?></li>
                    <li><i class="fa-solid fa-headset"></i> <?php echo e($settings->other_phone); ?></li>
                <?php else: ?>
                    <li><i class="fa-solid fa-map-marker-alt"></i> الدمام 32413</li>
                    <li><i class="fas fa-envelope"></i> info@platinumeastern.com</li>
                    <li><i class="fa-solid fa-phone"></i> 920003174</li>
                    <li><i class="fa-solid fa-headset"></i> 0552333182</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<div class="footer-bottom">
    <div class="container">
        <div class="footer-bottom-content">
            <p>
                <?php echo e(__("ingaz.all_rights_reserved")); ?> ©
                <script>document.write(new Date().getFullYear());</script>
                <a target="_blank" href="http://nami-tec.com">NAMI</a>
            </p>
              <ul class="footer-social">
                    <?php if($settings->facebook): ?>
                        <li><a href="<?php echo e($settings->facebook); ?>"><i class="fab fa-facebook-f"></i></a></li>
                    <?php endif; ?>
                    <?php if($settings->twitter): ?>
                        <li><a href="<?php echo e($settings->twitter); ?>"><i class="fab fa-twitter"></i></a></li>
                    <?php endif; ?>
                    <?php if($settings->instagram): ?>
                        <li><a href="<?php echo e($settings->instagram); ?>"><i class="fab fa-instagram"></i></a></li>
                    <?php endif; ?>
                    <?php if($settings->snapchat): ?>
                        <li><a href="<?php echo e($settings->snapchat); ?>"><i class="fab fa-snapchat-ghost"></i></a></li>
                    <?php endif; ?>
                    <?php if($settings->whatsapp): ?>
                        <li>
                            <a href="https://wa.me/<?php echo e(ltrim($settings->whatsapp, '+')); ?>" target="_blank" rel="noopener">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($settings->email): ?>
                        <li>
                            <a href="mailto:<?php echo e($settings->email); ?>"><i class="fas fa-envelope"></i></a>
                        </li>
                    <?php endif; ?>
                </ul>
        </div>
    </div>
</div>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/site/layouts/footer.blade.php ENDPATH**/ ?>