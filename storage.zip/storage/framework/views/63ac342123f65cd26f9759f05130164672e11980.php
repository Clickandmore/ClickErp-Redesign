<div class="row g-2">
    <div class="col-md-12 col-12 mb-2">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.salary")); ?> </label>
        <input type="text" name="salary" id="salary" value="<?php echo e($obj->salary); ?>" class="form-control" data-validation="required" oninput="updateNetSalary()">
    </div>

    <div class="col-12">
        <div class="row">
            <div class="col-md-6">
                <table id="taxTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th scope="col"><?php echo e(__("hr::hr.Select")); ?></th>
                        <th scope="col"><?php echo e(__("hr::hr.Choose your tax bracket")); ?></th>
                        <th scope="col"><?php echo e(__("hr::hr.percentage")); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $taxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="tax" name="tax[]" value="<?php echo e($tax->id); ?>"
                                    <?php echo e(isset($obj) && $obj->hasTax($tax->id) ? 'checked' : ''); ?>>
                            </td>
                            <td><?php echo e($tax->title); ?></td>
                            <td>
                                <div class="d-flex">
                                    <input type="text" name="taxValue[]"  class="form-control" value="<?php echo e($tax->value); ?>" readonly>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-6">
                <table id="insuranceTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th scope="col"><?php echo e(__("hr::hr.Select")); ?></th>
                        <th scope="col"><?php echo e(__("hr::hr.Choose the insurance category")); ?></th>
                        <th scope="col"><?php echo e(__("hr::hr.value")); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="insurance" data-type="<?php echo e($insurance->type); ?>" name="insurances[]" value="<?php echo e($insurance->id); ?>"
                                    <?php echo e(isset($obj) && $obj->hasInsurance($insurance->id) ? 'checked' : ''); ?>>
                            </td>
                            <td><?php echo e($insurance->title); ?></td>
                            <td>
                                <div class="d-flex">
                                    <input type="hidden" name="insuranceType[<?php echo e($insurance->id); ?>]" value="<?php echo e($insurance->type); ?>">
                                    <label><?php echo e($insurance->type == 0 ? __("hr::hr.percentage") : __("hr::hr.value")); ?> </label>
                                    <?php
                                        $selectedInsurance = $obj->manyInsurances()->where('insurances_id', $insurance->id)->first();
                                    ?>

                                    <input type="text" name="insuranceValue[<?php echo e($insurance->id); ?>]" class="form-control"
                                           value="<?php echo e($selectedInsurance ? $selectedInsurance->value : $insurance->emp_value); ?>">
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-12">
                <table id="allowanceTable" class="table table-bordered">
                    <thead>
                    <tr>
                        <th scope="col"><?php echo e(__("hr::hr.Select")); ?></th>
                        <th scope="col"><?php echo e(__("hr::hr.Choose the Allowance")); ?></th>
                        <th scope="col"><?php echo e(__("hr::hr.value")); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $allowances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allowance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="allowances" data-type="<?php echo e($allowance->type); ?>" name="allowances[]" value="<?php echo e($allowance->id); ?>"
                                    <?php echo e(isset($obj) && $obj->hasAllowance($allowance->id) ? 'checked' : ''); ?>>
                            </td>
                            <td><?php echo e($allowance->title); ?></td>
                            <td>
                                <div class="d-flex">
                                    <label>
                                        <?php if($allowance->type == 1): ?>
                                            <?php echo e(__("hr::hr.day")); ?>

                                        <?php elseif($allowance->type == 2): ?>
                                            <?php echo e(__("hr::hr.value")); ?>

                                        <?php else: ?>
                                            <?php echo e(__("hr::hr.percentage")); ?>

                                        <?php endif; ?>
                                    </label>

                                    <?php
                                        $selectedAllowance = $obj->manyAllowances()->where('allowances_id', $allowance->id)->first();
                                    ?>

                                    <input type="hidden" name="typeInput[<?php echo e($allowance->id); ?>]" value="<?php echo e($allowance->type); ?>">
                                    <input type="text" name="valueInput[<?php echo e($allowance->id); ?>]" class="form-control valueInput"
                                           value="<?php echo e($selectedAllowance ? $selectedAllowance->value : $allowance->value); ?>">
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-3 col-12 mb-2">
        <label for="totalTax" class="form-label"><?php echo e(__("hr::hr.totalTax")); ?></label>
        <input type="text" id="totalTax" name="total_tax" class="form-control" readonly>
    </div>

    <div class="col-md-3 col-12 mb-2">
        <label for="totalInsurances" class="form-label"><?php echo e(__("hr::hr.totalInsurances")); ?></label>
        <input type="text" id="totalInsurances" name="total_insurances" class="form-control" readonly>
    </div>

    <div class="col-md-3 col-12 mb-2">
        <label for="totalAllowances" class="form-label"><?php echo e(__("hr::hr.totalAllowances")); ?></label>
        <input type="text" id="totalAllowances" name="total_allowances" class="form-control" readonly>
    </div>

    <div class="col-md-3 col-12 mb-2">
        <label for="netSalary" class="form-label"><?php echo e(__("hr::hr.netSalary")); ?></label>
        <input type="text" id="netSalary" name="net_salary" value="<?php echo e($obj->net_salary); ?>" class="form-control" readonly>
    </div>
</div>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employees/edit/step4.blade.php ENDPATH**/ ?>