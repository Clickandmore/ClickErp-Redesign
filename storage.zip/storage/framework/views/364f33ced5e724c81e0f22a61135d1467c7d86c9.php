<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="branch_admin_id"><?php echo e(__('finance::finance.banks')); ?></label>
            <select id="bank_id" name="bank_id" class="form-control select2">
                <option value=""><?php echo e(__('finance::finance.choose')); ?></option>
                <?php $__currentLoopData = \Nami\Finance\Models\Bank::all() ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php echo addButton($createRoute , $addButtonText); ?>

    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th><?php echo e(__("finance::finance.banks")); ?></th>
            <th><?php echo e(__("finance::finance.account_name")); ?></th>
            <th><?php echo e(__("finance::finance.code")); ?></th>
            <th><?php echo e(__("finance::finance.bank_number")); ?></th>
            <th><?php echo e(__("finance::finance.iban")); ?></th>
            <th><?php echo e(__("finance::finance.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {"data": "bank", orderable: true, searchable: true},
                {"data": "name", orderable: true, searchable: true},
                {"data": "code", orderable: true, searchable: true},

                {"data": "bank_number", orderable: true, searchable: true},
                {"data": "iban", orderable: true, searchable: true},
                {"data": "actions", orderable: true, searchable: true}
            ];
            


            let table = $("#dataTableObject").DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                ordering: true,
                searching: true,
                iDisplayLength: 10,
                lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
                ajax: {
                    url: "<?php echo e($dataTableRoute); ?>",
                    data: function (response) {
                        response.bank_id = $('#bank_id').val();
                    }
                },
                columns,
                language: {
                    sProcessing: "<?php echo e(trans('dataTable.sProcessing')); ?>",
                    sLengthMenu: "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                    sZeroRecords: "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                    sInfo: "<?php echo e(trans('dataTable.sInfo')); ?>",
                    sInfoEmpty: "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                    sInfoFiltered: "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                    sSearch: "<?php echo e(trans('dataTable.sSearch')); ?>:",
                    oPaginate: {
                        sFirst: "<?php echo e(trans('dataTable.sFirst')); ?>",
                        sPrevious: "<?php echo e(trans('dataTable.sPrevious')); ?>",
                        sNext: "<?php echo e(trans('dataTable.sNext')); ?>",
                        sLast: "<?php echo e(trans('dataTable.sLast')); ?>"
                    }
                },
                order: [[2, "desc"]]
            });

            $('#bank_id').on('change', function () {
                table.ajax.reload();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/bank_accounts/index.blade.php ENDPATH**/ ?>