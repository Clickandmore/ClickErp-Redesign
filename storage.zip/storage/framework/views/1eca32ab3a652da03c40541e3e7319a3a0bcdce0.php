<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("admin.layout.inc._meta", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('page-title'); ?></title>


    <?php echo $__env->make("admin.layout.inc._css", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link href="<?php echo e(asset('admin/custom/style.css')); ?>" rel="stylesheet" type="text/css" />
    <?php if(App::getLocale() == 'ar'): ?>
        <link href="<?php echo e(asset('admin/custom/style-rtl.css')); ?>" rel="stylesheet" type="text/css" />
    <?php endif; ?>

    <!-- Admin Tables & Sidebar Design System -->
    
    <?php echo $__env->yieldContent("style"); ?>
    <?php echo $__env->yieldContent("css"); ?>
    <?php echo $__env->yieldPushContent("style"); ?>
    <?php echo $__env->yieldPushContent("css"); ?>


</head>
<body class="layout-1  <?php if(app()->getLocale() == 'ar'): ?> rtl_mode <?php endif; ?> " data-luno="theme-blue"> <!-- h-menu  -->

<?php echo $__env->make("admin.layout.inc.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="wrapper">

    <?php echo $__env->make("admin.layout.inc.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     
    <?php echo $__env->make('admin.layout.inc.page_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('up-card'); ?>


    <?php echo $__env->make("admin.layout.inc.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make("admin.layout.inc.global_modals", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("admin.layout.inc.siderbar_models", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make("admin.layout.inc._js", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("admin.layout.inc._js_custom", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('admin/assets/js/notifications.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/locale/ar.js"></script>
    <script>
        moment.locale('ar');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->yieldContent("js"); ?>
<?php echo $__env->yieldPushContent("js"); ?>
</body>
</html>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/admin/layout/indexs/index.blade.php ENDPATH**/ ?>