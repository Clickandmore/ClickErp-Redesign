<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/jquerysteps.min.css">
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/css/luno-style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.employees')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-12 mt-5">
        <h6 class="card-title"><?php echo e(__("buttons.add button")); ?> <?php echo e(__('hr::hr.employees')); ?></h6>
        <div class="card">
            <form class="card-body step-app h-wizard-demo4 from-submit-global" method="POST"
                  action="<?php echo e(route("employees.update", $obj->id)); ?>" enctype="multipart/form-data">
                <?php echo method_field('put'); ?>
                <ul class="step-steps">
                    <li data-step-target="step1"><span class="fa fa-credit-card"></span><?php echo e(__("hr::hr.basic information")); ?>

                    </li>
                    <li data-step-target="step2"><span class="fa fa-credit-card"></span> <?php echo e(__("hr::hr.Functional data")); ?>

                    </li>
                    <li data-step-target="step3"><span class="fa fa-user"></span> <?php echo e(__("hr::hr.Employee papers")); ?></li>
                    <li data-step-target="step4"><span class="fa fa-share-alt"></span> <?php echo e(__("hr::hr.Salary details")); ?>

                    </li>
                </ul>
                <div class="step-content">
                    <div class="step-tab-panel" data-step="step1">
                        <?php echo $__env->make('hr::hr.employees.edit.step1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="step-tab-panel" data-step="step2">
                        <?php echo $__env->make('hr::hr.employees.edit.step2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="step-tab-panel" data-step="step3">
                        <?php echo $__env->make('hr::hr.employees.edit.step3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="step-tab-panel" data-step="step4">
                        <?php echo $__env->make('hr::hr.employees.edit.step4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="step-footer d-flex">
                    <button class="btn step-btn" data-step-action="prev"><?php echo e(__("hr::hr.previous")); ?> </button>
                    <button class="btn step-btn" data-step-action="next"><?php echo e(__("hr::hr.next")); ?> </button>
                </div>
                <hr>
                <div class="text-end mt-2">
                    <button type="submit" class="btn btn-primary"><?php echo e(__("hr::hr.save")); ?> </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('hr::hr.employees.inc._js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employees/edit.blade.php ENDPATH**/ ?>