<?php if(count($data)): ?>
    <div class="row mb-3">
        <div class="col-6">
            <label class=""><?php echo e(__('finance::finance.statement')); ?></label>
            <textarea rows="3" name="statement" id="statement"
                      class="form-control" <?php echo e($data['check_previous_constraint'] ? 'disabled' : ''); ?>>
                <?php echo e($data['constraint']->statement ?? ''); ?>

            </textarea>
        </div>
        <div class="col-6 mt-4">
            <label class=""><?php echo e(__('finance::finance.date')); ?></label>
            <input name="date" id="date" type="date" value="<?php echo e($data['constraint']->date ??  date('Y-m-d')); ?>"
                   class="form-control" <?php echo e($data['check_previous_constraint']  ? 'disabled' : ''); ?>>
        </div>
        <?php if(!$data['check_previous_constraint'] && $data['constraint']): ?>
            <div class="col-12 mt-2 text-center">
                <button data-action="<?php echo e(route('finance::finance.constraints.destroy',$data['constraint']->id)); ?>"
                        class="btn btn-danger deleteFirstBalance">
                    <?php echo e(__('finance::finance.delete-first-balance')); ?> <i class="fa fa-trash"></i>
                </button>
            </div>
        <?php endif; ?>
    </div>
    <table class="table table-bordered table-responsive" id="table-to-export" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.Account code')); ?></th>
            <th><?php echo e(__('finance::finance.Account Name')); ?></th>
            <th><?php echo e(__('finance::finance.debtor')); ?></th>
            <th><?php echo e(__('finance::finance.creditor')); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $data['accounts_with_no_children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr title="">
                <td><?php echo e($row->code); ?></td>
                <td><?php echo e($row->name); ?></td>
                <?php
                    $accountData = $data['constraint_details']->where('account_id', $row->id)->first();
                    $debtorValue = $accountData['debtor_value'] ?? null;
                    $creditorValue = $accountData['creditor_value'] ?? null;
                ?>
                <?php if($data['constraint']): ?>
                    <td><?php echo e($debtorValue ?? 0); ?></td>
                    <td><?php echo e($creditorValue ?? 0); ?></td>
                <?php else: ?>
                    <td>
                        <input id="debtor_value<?php echo e($row->id); ?>" data-edited="false" class="form-control debtor-input"
                               type="number" value="0" data-account-id="<?php echo e($row->id); ?>"
                               data-account-status="<?php echo e(@$row->status->value); ?>">
                        <span class="error-span" hidden style='color:red'><?php echo e(__("finance::finance.Enter Valid Values")); ?></span>
                    </td>
                    <td>
                        <input id="creditor_value<?php echo e($row->id); ?>" data-edited="false" class="form-control creditor-input"
                               type="number" value="0" data-account-id="<?php echo e($row->id); ?>"
                               data-account-status="<?php echo e(@$row->status->value); ?>">
                        <span class="error-span" hidden style='color:red'><?php echo e(__("finance::finance.Enter Valid Values")); ?></span>
                    </td>
                <?php endif; ?>
                
                
                
                
                
                
                
                
                
                
                
                
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if(!$data['constraint']): ?>
        <div class="row">
            <form id="formOfFirstBalance">
                <input name="balance" id="balance" type="hidden">
                <input name="year_id" value="<?php echo e($data['year_id']); ?>" type="hidden">
                <input name="value" id="total_value" type="hidden">
                <div class="col-3">
                    <button type="submit" class="btn btn-primary mt-2"
                            id="addOrUpdateConstraints"><?php echo e(__('finance::finance.Confirm')); ?></button>
                </div>
            </form>
        </div>
    <?php endif; ?>
<?php else: ?>

<?php endif; ?>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/opening_balance/table.blade.php ENDPATH**/ ?>