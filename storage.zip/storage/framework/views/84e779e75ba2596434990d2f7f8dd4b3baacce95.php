<?php if(count($data)): ?>
    <div class="col d-flex justify-content-end no-print" id="print_excel">
        <button onclick="handlePrint()" class="btn btn-success ml-2"><i class="fa fa-print"></i></button>
    </div>

    <div id="print_section">
        <?php echo $__env->make('print-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="text-center" style="margin: 10px auto">
            <h5><?php echo e(__("finance::finance.Income statement")); ?> <?php echo e(request('from_date') ? __('finance::finance.from_date') : ''); ?> <?php echo e(request('from_date')); ?> <?php echo e(request('to_date') ? __('finance::finance.to_date') : ''); ?> <?php echo e(request('to_date')); ?></h5>
        </div>
        <table class="table table-hover table-bordered table-striped" style="width:100%;font-size: 17px">
            <?php
                $income = 0;
                $outcome = 0;
            ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody style="font-size: 19px">
                <tr>
                    <th rowspan="<?php echo e(count($account['list']) +1); ?>"
                        style="text-align: center;background-color: #dddddd; font-size: 20px"
                        scope="col"><?php echo e($account['account']->name); ?></th>
                </tr>
                <?php $__currentLoopData = $account['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="one"><?php echo e($children['account']->name ?? " "); ?></td>
                        <td class="one" colspan="2"><?php echo e($children['total_price'] ?? " "); ?></td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tbody>

            <tbody style="font-size: 19px">
            <tr style="background-color: #7dd3e4;text-align: center;font-size: 20px">
                <td class="one"> مجموع <?php echo e($account['account']->name); ?></td>
                <td class="one" colspan="2"><?php echo e($account['account_total_price'] ?? " "); ?></td>
            </tr>
            </tbody>
            <?php
                if($account['account']->type == Nami\Finance\Enums\AccountTypesEnum::GeneralIncome){
                    $income += $account['account_total_price'];
                }elseif($account['account']->type == Nami\Finance\Enums\AccountTypesEnum::GeneralOutcome){
                    $outcome += $account['account_total_price'];
                }
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr style="font-weight: bold;text-align: center;font-size: 21px">
                <?php if($income > $outcome): ?>
                    <td class="one">صافي الربح</td>
                    <td class="one" colspan="2"><?php echo e($income - $outcome ?? " "); ?></td>
                <?php else: ?>
                    <td class="one">صافي الخسارة</td>
                    <td class="one" colspan="2"><?php echo e($outcome - $income ?? " "); ?></td>
                <?php endif; ?>
            </tr>
        </table>
    </div>
<?php else: ?>
    <div role="alert" class="alert alert-danger text-center"> <?php echo e(__('finance::finance.no_data_found')); ?></div>
<?php endif; ?>

<script>
    function handlePrint() {
        const printContent = document.getElementById('print_section').innerHTML;
        const styleSheet = `
            <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/css/bootstrap.rtl.min.css">
            <style>
                body {
                    direction: rtl;
                    font-family: "Arial", sans-serif;
                    padding: 20px;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px 8px;
                    text-align: center;
                    vertical-align: middle;
                    font-size: 12px;
                }
                h5 {
                    text-align: center;
                    margin-bottom: 20px;
                }
                @media  print {
                    html, body {
                        width: 95%;
                        height: 100%;
                        margin: auto;
                        padding: 0;
                        overflow: visible;
                    }
                }
            </style>
        `;

        const printWindow = window.open('', '_blank');

        printWindow.document.open();
        printWindow.document.write(`
            <html>
                <head>
                    <title><?php echo e(__("finance::finance.sales-analysis")); ?></title>
                    ${styleSheet}
                </head>
                <body>
                    ${printContent}
                    <script>
                        window.onload = function() {
                            window.print();
                        };
                        window.onafterprint = function() {
                            window.close();
                        };
                    <\/script>
                </body>
            </html>
        `);
        printWindow.document.close();
    }
</script>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/income_list/result.blade.php ENDPATH**/ ?>