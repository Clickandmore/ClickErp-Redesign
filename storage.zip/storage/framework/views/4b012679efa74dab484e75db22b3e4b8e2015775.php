<footer class="page-footer px-xl-4 px-sm-2 px-0 py-3">
    <div class="container-fluid d-flex flex-wrap justify-content-center align-items-center">
        <p class=" text-muted d-flex align-items-center gap-1">
            <?php echo e(__('auth.All Rights Reserved.')); ?>

            <a href="#" target="_blank" title="Assus" class="namiFotter">
                 بلاتنيوم الشرقية للاستقدام
            </a>
            © 2024
            ❤️
        </p>
    </div>
</footer>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/admin/layout/inc/footer.blade.php ENDPATH**/ ?>