<form class="row g-3 from-submit-global" method="post" action="<?php echo e(route('departments.update', $obj->id)); ?>"
    enctype="multipart/form-data">
    <?php echo method_field('put'); ?>
    <div class="col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.department_name")); ?>  </label>
        <input type="text" name="title" value="<?php echo e($obj->title); ?>" class="form-control" data-validation="required">
        <input type="hidden" name="department_id" value="<?php echo e($obj->id); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-12 modal-footer">
        <?php echo submitButton(route('departments.update', $obj->id)); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/department/edit.blade.php ENDPATH**/ ?>