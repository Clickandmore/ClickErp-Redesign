<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($settings->website_name ??  'Nami'); ?> | <?php echo e(__("auth.login")); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('admin/login')); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin/login')); ?>/css/fontawesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/vendor/toster/css/jquery.toast.css">
</head>

<body <?php if(app()->getLocale()=='ar'): ?> dir="rtl" <?php endif; ?>>
<div class="container">
    <div class="side">
        <div class="inner">
            <div class="form-wrap">
                <?php if(isset($settings)): ?>
                    <img class="logo" src="<?php echo e(showFile($settings->logo_header)); ?>" alt="">
                <?php else: ?>
                    <img class="logo" src="<?php echo e(asset('admin/login')); ?>/imgs/Frame 36125.svg" alt="">
                <?php endif; ?>
                <h1><?php echo e(__('auth.welcomeback')); ?> 👋</h1>
                <!-- <p>Glad to see you again</p> -->
                <form id="loginForm" action="<?php echo e(route('admin.login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="input-field">
                            <label for="email"><img src="<?php echo e(asset('admin/login')); ?>/imgs/email.svg"
                                                    alt="email"> <?php echo e(__('auth.email')); ?>*</label>
                            <input type="email" id="email" name="login" placeholder="<?php echo e(__('auth.placeholderEmail')); ?>">
                        </div>
                        <div class="input-field">
                            <label for="password"><img src="<?php echo e(asset('admin/login')); ?>/imgs/password.svg"
                                                       alt="password"> <?php echo e(__('auth.password')); ?>*</label>
                            <input type="password" id="password" name="password"
                                   placeholder="•••••••••••••••••••••••">
                        </div>
                        <div class="check-field check">
                            <div>
                                <input type="checkbox" name="rememberme" id="rememberme">
                                <label for="rememberme"><?php echo e(__('auth.rememberme')); ?></label>
                            </div>
                            <!-- <a href="">Forgot your password?</a> -->
                        </div>
                    </div>
                    <button type="submit"><?php echo e(__('auth.sign in')); ?></button>
                </form>
            </div>
        </div>
        <p class="footer">
            <?php echo e($main_setting->copyright_text ?? __('auth.All Rights Reserved.')); ?>

            <a href="<?php echo e($main_setting->copyright_link ?? ''); ?>" target="_blank" title="ROMOZ" class="namiFotter">
                <img src="<?php echo e(showFile( $main_setting->footer_logo ?? '')); ?>" width="50px" alt="">
            </a>
            © <?php echo e(date('Y')); ?>

        </p>
    </div>

    <div class="animation">
        <!-- orbit canvas -->
        <div id="globe">
            <canvas></canvas>
        </div>
    </div>
</div>
<!-- orbit -->
<script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
<script>
    $(function () {
        $('#password').password()
    })
</script>
<script src="<?php echo e(asset('admin')); ?>/assets/js/plugins.js"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/js/theme.js"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/vendor/toster/js/jquery.toast.js"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/js/custom.js"></script>
<script src="<?php echo e(asset('admin/login')); ?>/js/three.js"></script>
<script src="<?php echo e(asset('admin/login')); ?>/js/orbit.js"></script>
<script src="<?php echo e(asset('admin/login')); ?>/js/custom_orbit.js"></script>
<script type="text/javascript">
    $(function () {

        console.clear()
        /*------------------------------------------
        --------------------------------------------
        Submit Event
        --------------------------------------------
        --------------------------------------------*/
        $(document).on("submit", "#loginForm", function (e) {
            e.preventDefault();
            let formObj = $(this);
            formObj.find("[type='submit']").html("<?php echo e(__('auth.sign in')); ?>...");
            $.ajax({
                url: formObj.attr('action'),
                data: formObj.serialize(),
                type: "POST",
                dataType: 'json',
                success: function (result) {
                    console.log("success =  200")
                    formObj.find("[type='submit']").html("<?php echo e(__('auth.sign in')); ?>");
                    if (result.code === 200) {
                        successToster('<?php echo e(__("auth.done successfully")); ?>', result.message);
                        // console.log(result.data.url)
                        window.location.href = result.data.url;
                    } else if (result.code === 401) {
                        warningToster('<?php echo e(__("auth.an error occurred")); ?>', result.message)
                    } else {
                        warningToster('<?php echo e(__("auth.an error occurred")); ?>', result.message)
                    }
                },
                error: function (errorObj, errorText, errorThrown) {
                    console.log("error =  500")
                    formObj.find("[type='submit']").html("<?php echo e(__('auth.sign in')); ?>");
                    if (errorObj.status === 500) {
                        errorToster('<?php echo e(__("auth.an error occurred")); ?>', "<?php echo e(__("auth.code error")); ?>");
                    } else if (errorObj.status == 422) {
                        let errorsObj = $.parseJSON(errorObj.responseText);
                        let listObject = errorsObj.errors;
                        let testArr = [];
                        $.each(listObject, function (errorKey, errorArr) {
                            $.each(errorArr, function (key, value) {
                                testArr.push(value);
                            });
                        });
                        // console.log(testArr)
                        validToster('<?php echo e(__("auth.an error occurred")); ?>', testArr)
                    }

                }
            });
            return false;
        });

    });
</script>
</body>

</html>
<?php /**PATH /mnt/Data/test/resources/views/nami/auth/login.blade.php ENDPATH**/ ?>