<div class="sidebar p-2 sidebar-img-bg py-md-3 @cardClass">
    <div class="container-fluid">

        <div class="title-text d-flex align-items-center mb-4 mt-1">
            <h4 class="sidebar-title mb-0 flex-grow-1"><span class="sm-txt"></span>
                <span>
                    <?php if(isset($settings) && isset($settings->website_name)): ?>
                        <?php echo e($settings->website_name); ?>

                    <?php endif; ?>
                </span>
            </h4>
            
        </div>


        <div class="main-menu flex-grow-1">

            <ul class="menu-list nav-sidebar">
                <li class="divider py-2 lh-sm"><span class="small"><?php echo e(trans('auth.dashboard')); ?> </span><br> <small
                        class="text-muted">
                        <?php echo e($main_setting->sidebar_text ?? __('auth.develop_design') . 'NAMI'); ?>

                    </small></li>
                <li>
                    <a class="m-link <?php echo e(Route::currentRouteName() == 'dashboard.index' ? 'active' : ''); ?>"
                        href="<?php echo e(route('dashboard.index')); ?>">
                        <i class="fa fa-home"></i>
                        <span class="ms-2"><?php echo e(trans('auth.home')); ?> </span>
                    </a>
                </li>

                <!-- general settings -->
                <?php if(checkIfHasPermission('settings-read')): ?>
                    <li>
                        <a class="m-link <?php echo e(Route::currentRouteName() == 'settings.index' ? 'active' : ''); ?>"
                            href="<?php echo e(route('settings.index')); ?>">
                            <i class="fa fa-cogs"></i>
                            <span class="ms-2"><?php echo e(__('auth.site_settings')); ?> </span>
                        </a>
                    </li>
                <?php endif; ?>
                
                <!-- general settings -->
                <!-- developer settings -->
                <?php if(auth('admin')->user()->admin_type == \App\Enums\AdminTypeisEnum::Developer->value): ?>
                    <li class="collapsed">
                        <a class="m-link
                    <?php echo e(in_array(Route::currentRouteName(), ['env.index', 'file-manager.index', 'terminal.index', 'commands.index', 'main-settings.index']) ? 'active' : ''); ?>"
                            data-bs-toggle="collapse" data-bs-target="#my_dashboard1" href="#"
                            aria-expanded="<?php echo e(in_array(Route::currentRouteName(), ['env.index', 'file-manager.index', 'terminal.index', 'commands.index', 'main-settings.index']) ? 'true' : ''); ?>">
                            <i class="fa fa-cogs"></i>
                            <span class="ms-2"><?php echo e(trans('auth.system_settings')); ?> </span>
                            <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                        </a>
                        <ul class="sub-menu collapse
                    <?php echo e(in_array(Route::currentRouteName(), ['env.index', 'file-manager.index', 'terminal.index', 'commands.index', 'main-settings.index']) ? 'show' : ''); ?>"
                            id="my_dashboard1">
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'env.index' ? 'active' : ''); ?>"
                                    href="<?php echo e(route('env.index')); ?>">
                                    <i class="fa fa-cogs"></i>
                                    <span class="ms-2"> env </span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'file-manager.index' ? 'active' : ''); ?>"
                                    href="<?php echo e(route('file-manager.index')); ?>">
                                    <i class="fa fa-file-archive-o"></i>
                                    <span class="ms-2"><?php echo e(__('auth.file_manager')); ?> </span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'terminal.index' ? 'active' : ''); ?>"
                                    href="<?php echo e(route('terminal.index')); ?>">
                                    <i class="fa fa-terminal"></i>
                                    <span class="ms-2"><?php echo e(__('auth.terminal')); ?> </span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'commands.index' ? 'active' : ''); ?>"
                                    href="<?php echo e(route('commands.index')); ?>">
                                    <i class="fa fa-terminal"></i>
                                    <span class="ms-2"><?php echo e(__('auth.commands')); ?> </span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'main-settings.index' ? 'active' : ''); ?>"
                                    href="<?php echo e(route('main-settings.index')); ?>">
                                    <i class="fa fa-cog"></i>
                                    <span class="ms-2"><?php echo e(__('auth.main_settings')); ?> </span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'main-settings.index' ? 'active' : ''); ?>"
                                    href="<?php echo e(url('/log-viewer')); ?>" target="_blank">
                                    <i class="fa fa-cog"></i>
                                    <span class="ms-2">log viewer </span>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <!-- developer settings -->

                
                <?php if(checkIfHasPermission('roles-read')): ?>
                    <li class="collapsed">
                        <a class="m-link" data-bs-toggle="collapse" data-bs-target="#adminsandroles" href="#">
                            <i class="icon-lock"></i>
                            <span class="ms-2"> <?php echo e(__('permission.users and roles')); ?> </span>
                            <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                        </a>
                        <ul class="sub-menu collapse
                    <?php echo e(in_array(Route::currentRouteName(), ['permissions.index','roles.index', 'roles.create', 'roles.edit', 'admins.index']) ? 'show' : ''); ?>"
                            id="adminsandroles">

                            <?php if(checkIfHasPermission('admins-read')): ?>
                                <li>
                                    <a class="m-link <?php echo e(Route::currentRouteName() == 'admins.index' ? 'active' : ''); ?>"
                                        href="<?php echo e(route('admins.index')); ?>">
                                        <i class="icon-user"></i>
                                        <span class="ms-2"> <?php echo e(__('auth.users')); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(auth('admin')->user()->admin_type == \App\Enums\AdminTypeisEnum::Developer->value): ?>
                                <li>
                                    <a class="m-link <?php echo e(Route::currentRouteName() == 'permissions.index' ? 'active' : ''); ?>"
                                        href="<?php echo e(route('permissions.index')); ?>">
                                        <i class="icon-lock"></i>
                                        <span class="ms-2"> <?php echo e(__('permission.permissions')); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(checkIfHasPermission('roles-read')): ?>
                                <li>
                                    <a class="m-link <?php echo e(in_array(Route::currentRouteName(), ['roles.index', 'roles.create', 'roles.edit']) ? 'active' : ''); ?>"
                                        href="<?php echo e(route('roles.index')); ?>">
                                        <i class="icon-lock"></i>
                                        <span class="ms-2"> <?php echo e(__('permission.roles')); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                


                
                <?php
                    $resources = [
                        // 'orders' => ['icon' => 'fa-bell', 'label' => __('homefix.orders'), 'childrens' => [
                        //     'new-orders' => ['icon' => 'fa-code-pull-request', 'label' => __('homefix.new_orders'), 'permission' => 'new-orders-read'],
                        // ]],
                        // 'general-notification' => ['icon' => 'fa-message', 'label' => __('homefix.general_notification'), 'permission' => 'general-notification-read'],
                    ];
                ?>

                <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($data['childrens']) && count($data['childrens']) > 0): ?>
                        <?php
                            $resources_names = getAllChildrensRouteNames($data['childrens']);
                            $resources_permissions = getAllChildrensRoutePermission($data['childrens']);
                            $group_current_route_name = explode('.',Route::currentRouteName())[0];
                            $goroup_active = in_array($group_current_route_name, $resources_names);
                        ?>
                        <?php if(checkIfHasMultiplePermission($resources_permissions)): ?>
                            <li class="collapsed">
                                <a class="m-link <?php echo e($goroup_active ? 'active' : ''); ?>"
                                    data-bs-toggle="collapse" data-bs-target="#<?php echo e($route); ?>" href="#"
                                    aria-expanded="<?php echo e($goroup_active ? 'true' : ''); ?>">
                                    <i class="fa <?php echo e($data['icon']); ?>"></i>
                                    <span class="ms-2"><?php echo e($data['label']); ?> </span>
                                    <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                                </a>
                                <ul class="sub-menu collapse <?php echo e($goroup_active ? 'show' : ''); ?>"
                                    id="<?php echo e($route); ?>">
                                    <?php renderNestedMenu($data['childrens'], $route); ?>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if(checkIfHasPermission($data['permission']) && !isset($data['notVisible'])): ?>
                            <?php
                                $active = false;
                                if(isset($data['otherActive']) && count($data['otherActive'])) {
                                    $other_active = $data['otherActive'];
                                    $current_route_name = explode('.',Route::currentRouteName())[0];
                                    $active = in_array($current_route_name, $other_active);
                                }
                            ?>
                            <li>
                                <a class="m-link <?php echo e(Str::startsWith(Route::currentRouteName(), $route . '.') || $active ? 'active' : ''); ?>"
                                    href="<?php echo e(route($route . '.index')); ?>">
                                    <i class="fa <?php echo e($data['icon']); ?>"></i>
                                    <span class="ms-2"><?php echo e($data['label']); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isHr = request()->is('hr*');
                ?>
                <li class="<?php echo e($isHr ? '' : 'collapsed'); ?>">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#hr" href="#">
                        <i class="fa fa-file-text"></i>
                        <span class="ms-2"><?php echo e(helperTrans('hr')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e($isHr ? 'show' : ''); ?>" id="hr">
                        <?php echo $__env->make('hr::hr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </li>
                <?php
                    $isFinance = request()->is('finance*');
                ?>
                <li class="<?php echo e($isFinance ? '' : 'collapsed'); ?>">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#finance" href="#">
                        <i class="fa fa-file-text"></i>
                        <span class="ms-2"><?php echo e(helperTrans('finance')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e($isFinance ? 'show' : ''); ?>" id="finance">
                        <?php echo $__env->make('finance::finance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </li>
                
            </ul>
        </div>


        <ul class="menu-list nav navbar-nav flex-row text-center menu-footer-link">
            <li class="nav-item flex-fill p-2">
                <?php if(checkIfHasPermission('settings-read')): ?>
                    <a class="d-inline-block w-100 color-400" href="<?php echo e(route('settings.index')); ?>">
                    <i class="fa fa-cogs"></i>
                    </a>
                <?php endif; ?>
            </li>
            <li class="nav-item flex-fill p-2">
                <a class="d-inline-block w-100 color-400" href="<?php echo e(route('admin.logout')); ?>" title="sign-out">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M7.5 1v7h1V1h-1z" />
                        <path class="fill-secondary"
                            d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z" />
                    </svg>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /mnt/Data/test/resources/views/nami/layout/inc/sidebar.blade.php ENDPATH**/ ?>