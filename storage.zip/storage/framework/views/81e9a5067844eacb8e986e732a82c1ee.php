<?php $__env->startSection("style"); ?>
    
    
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/vendor/tree_collapse/tree-co.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo addButton($createRoute , $addButtonText); ?>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th><?php echo e(__('finance::finance.title')); ?></th>
            <th><?php echo e(__('finance::finance.from_date')); ?></th>
            <th><?php echo e(__('finance::finance.to_date')); ?></th>
            <th><?php echo e(__('finance::finance.actions')); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>

    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {"data": "title", orderable: false, searchable: true},
                {"data": "from_date", orderable: false, searchable: true},
                {"data": "to_date", orderable: false, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ];
            showDataTable("<?php echo e($dataTableRoute); ?>", columns);
        });

        $(document).on('click', '.status-toggle', function () {
            var id = $(this).data('id');
            var status = $(this).data('status');
            var actionText = status == 1 ? '<?php echo e(__("finance::finance.activate")); ?>' : '<?php echo e(__("finance::finance.deactivate")); ?>';
            // alert([id,status,actionText])

            Swal.fire({
                title: '<?php echo e(__("finance::finance.Are you sure?")); ?>',
                text: '<?php echo e(__("finance::finance.You are about to ")); ?>' + actionText + '<?php echo e(__("finance::finance. this item.")); ?>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '<?php echo e(__("finance::finance.Yes, ")); ?>' + actionText,
                cancelButtonText: '<?php echo e(__("finance::finance.Cancel")); ?>'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '<?php echo e(route("finance.year-status.show", ":id")); ?>'.replace(':id', id),
                        method: 'PUT',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            status: status
                        },
                        success: function (response) {
                            Swal.fire({
                                // title: '<?php echo e(__("finance::finance.Updated!")); ?>',
                                text: '<?php echo e(__("finance::finance.Status has been updated successfully.")); ?>',
                                icon: 'success',
                                timer: 3000,
                                showConfirmButton: false
                            });
                            $('#dataTableObject').DataTable().ajax.reload();
                        },
                        error: function (errorObj, errorText, errorThrown) {
                            console.log(500);
                            handleErrorResponce(errorObj);
                        }
                    });
                }
            });
        });

    </script>
    <?php if(request()->has('year')): ?>
        <?php if(request()->has('year')): ?>
            <script>
                window.onload = function() {
                    var buttons = document.getElementsByClassName('addButton');
                    for (var i = 0; i < buttons.length; i++) {
                        buttons[i].click();
                    }
                }
            </script>
        <?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/years/index.blade.php ENDPATH**/ ?>