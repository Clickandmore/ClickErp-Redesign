<?php if($data_report->count() > 0 ): ?>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #D9D9F3;
        }

        td {
            background-color: #F9F9F9;
        }

        .section-header {
            background-color: #CCCCFF;
        }

        .section-header th {
            border-bottom: 2px solid black;
        }

        .table thead th {
            vertical-align: bottom;
            border: 2px solid #23223e;
        }
    </style>
<div class="row g-2 m-2">
    <div class="col d-flex printExcel justify-content-end">
        <button onclick="window.print()" class="btn btn-primary mr-2 mx-2">
            <i class="fa fa-print"></i> <?php echo e(__("finance::finance.print")); ?>

        </button>
        <button type="button" id="toExcel" class="btn btn-sm btn-warning">
            <i class="fa fa-file-excel"></i> <?php echo e(__("finance::finance.toExcel")); ?>

        </button>
    </div>
</div>

<div class="col-md-12">
    <div class="row">
        <div class="col-md-12 text-center">
            <div class="title-box">
                <h3><?php echo app('translator')->get('finance::finance.asset_list'); ?></h3>
            </div>
        </div>
        <div class="col-md-6">
            <h6><?php echo app('translator')->get('finance::finance.group_code'); ?> : <?php echo e($group_code); ?></h6>
        </div>
        <div class="col-md-6">
            <h6><?php echo app('translator')->get('finance::finance.group_name'); ?> : <?php echo e($group_name); ?></h6>
        </div>
    </div>
    <br>
</div>

    <div class="col-md-12">
        <table class="table table-hover table-bordered table-striped" id="toExcelTable" style="width:100%">
            <thead>
                <tr class="section-header">
                    <th><?php echo app('translator')->get('finance::finance.principle_code'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.principle_name'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.principle_site'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.responsible_employee'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.purchase_date'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.purchase_value'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.first_tax'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.second_tax'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.depreciated_value'); ?></th>
                    <th><?php echo app('translator')->get('finance::finance.financial_value'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $total_purchase_value = 0;
                    $total_first_tax = 0;
                    $total_second_tax = 0;
                    $total_depreciated_value = 0;
                    $total_financial_value = 0;
                ?>
                <?php $__currentLoopData = $data_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data['principle_code']); ?></td>
                        <td><?php echo e($data['principle_name']); ?></td>
                        <td><?php echo e($data['principle_site']); ?></td>
                        <td><?php echo e($data['responsible_employee']); ?></td>
                        <td><?php echo e($data['purchase_date']); ?></td>
                        <td><?php echo e($data['purchase_value']); ?></td>
                        <td><?php echo e($data['first_value']); ?></td>
                        <td><?php echo e($data['second_value']); ?></td>
                        <td><?php echo e($data['depreciated_value']); ?></td>
                        <td><?php echo e($data['financial_value']); ?></td>
                    </tr>
                    <?php
                        $total_purchase_value += $data['purchase_value'];
                        $total_first_tax += $data['first_value'];
                        $total_second_tax += $data['second_value'];
                        $total_depreciated_value += $data['depreciated_value'];
                        $total_financial_value += $data['financial_value'];
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" class="text-right"><?php echo app('translator')->get('finance::finance.total'); ?></td>
                    <td><?php echo e($total_purchase_value); ?></td>
                    <td><?php echo e($total_first_tax); ?></td>
                    <td><?php echo e($total_second_tax); ?></td>
                    <td><?php echo e($total_depreciated_value); ?></td>
                    <td><?php echo e($total_financial_value); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php else: ?>
    <div role="alert" class="alert alert-danger text-center"
         style="width: 100%"><?php echo e(__("finance::finance.No data available")); ?></div>
    <br>
<?php endif; ?>

<?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/principle_report/result.blade.php ENDPATH**/ ?>