<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .loader {
            border: 12px solid #f3f3f3;
            border-top: 12px solid #F7941D;
            border-radius: 50%;
            width: 120px;
            height: 120px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }


        .header{
            position:sticky;
            top: 0 ;
            background-color: #ffc800;
        }

        td{
            font-size: small;
        }
        @media print {
            body * {
                visibility: hidden;
            }
            #simpleTable4, #simpleTable4 * {
                visibility: visible;
            }
            #simpleTable4 {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                padding: 20px;
                font-size: 12pt;
            }
            .sidebar {
                display: none !important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(count($accounts)): ?>
        <div class="row print-and-excel-buttons mb-3">
            <div class="col-12 mt-4" style="text-align: left">
                <button onclick="window.print()" class="btn btn-primary" id="printBalanceTable"><i class="fa fa-print"></i></button>
                <button id="toExcel" class="btn btn-info"><i class="fa fa-file-excel-o"></i></button>
            </div>
        </div>
        <table class="table table-hover table-bordered table-striped" id="simpleTable4" style="width:100%">
            <thead>
                <tr class="header">
                    <th style="width: 3%" scope="col">#</th>
                    <th style="width: 10%" scope="col">  <?php echo e(__('finance::finance.code')); ?></th>
                    <th style="width: 10%" scope="col"> <?php echo e(__("finance::finance.Account")); ?></th>
                    <th style="width: 5%" scope="col"><?php echo e(__("finance::finance.total_depit")); ?></th>
                    <th style="width: 5%" scope="col"><?php echo e(__("finance::finance.total_credit")); ?></th>
                    <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.Balance")); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($account['code']); ?></td>
                        <td><?php echo e($account['name']); ?></td>
                        <td><?php echo e($account['debtor_value']); ?></td>
                        <td><?php echo e($account['creditor_value']); ?></td>
                        <td><?php echo e($account['balance']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <th colspan="3"><?php echo e(__('finance::finance.Total')); ?></th>
                <th class="currency-egp"><?php echo e($total_depitors); ?></th>
                <th class="currency-egp"><?php echo e($total_creditors); ?></th>
                <th class="currency-egp" style="background-color: yellow"><?php echo e($total_balance); ?></th>
            </tfoot>
        </table>
    <?php else: ?>
        <div class="d-flex justify-content-center align-items-center" style="height: 50vh !important;">
            <div class="no-data text-center">
                <?php echo e(__('finance::finance.no_data')); ?>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("plugins")); ?>/exelJs/dist/tableToExcel.517b1af9.js"></script>
    <script>
        var button = document.querySelector('#toExcel');
        button.addEventListener('click', function (e) {
            var table = document.querySelector('#simpleTable4');
            TableToExcel.convert(table);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/balances/index.blade.php ENDPATH**/ ?>