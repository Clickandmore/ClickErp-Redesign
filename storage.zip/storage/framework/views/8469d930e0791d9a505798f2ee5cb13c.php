<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php echo addButton($createRoute , $addButtonText); ?>

    <table class="table" id="dataTableObject">
        <thead class="thead-inverse">
            <tr>
                <th><?php echo e(__('hr::hr.SL')); ?></th>
                <th><?php echo e(__("hr::hr.employees")); ?></th>
                <th><?php echo e(__("hr::hr.rewards")); ?></th>
                <th><?php echo e(__("hr::hr.salary")); ?></th>
                <th><?php echo e(__("hr::hr.net_value")); ?></th>
                <th><?php echo e(__("hr::hr.exchange_timing")); ?></th>
                <th><?php echo e(__("hr::hr.date")); ?></th>
                <th><?php echo e(__('hr::hr.actions')); ?></th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                {"data": "employee_id", orderable: false, searchable: true},
                {"data": "reward_id", orderable: false, searchable: true},
                {"data": "salary", orderable: false, searchable: true},
                {"data": "net_value", orderable: false, searchable: true},
                {"data": "exchange_timing", orderable: false, searchable: true},
                {"data": "date", orderable: false, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ];
            showDataTable("<?php echo e($dataTableRoute); ?>", columns);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employee_rewards/index.blade.php ENDPATH**/ ?>