<?php $__env->startSection('style'); ?>
    <style>
        .loader {
            border: 12px solid #f3f3f3;
            border-top: 12px solid #F7941D;
            border-radius: 50%;
            width: 120px;
            height: 120px;
            animation: spin 2s linear infinite;
        }

        @keyframes  spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }


        .header{
            position:sticky;
            top: 0 ;
            background-color: #ffc800;
        }

        td{
            font-size: small;
        }
        @media  print {
            body * {
                visibility: hidden;
            }
            #account_list, #account_list * {
                visibility: visible;
            }
            #account_list {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                padding: 20px;
                font-size: 12pt;
            }
            .sidebar {
                display: none !important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row g-3 my-2">
        <div class="col-md-3">
            <label for="TextInput" class="form-label"><?php echo e(__("finance::finance.Select the Duplicated Account")); ?></label>
            <select name="double_account_id" id="account_id" class="form-control  show-tick ms select2 search_keys">
                <?php echo showSelectElement($double_accounts,'name'); ?>

            </select>
        </div>

        <div class="col-md-2">
            <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.from_date")); ?></label>
            <input type="date" name="from_date" class="form-control search_keys" id="from_date">
        </div>

        <div class="col-md-2">
            <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.to_date")); ?></label>
            <input type="date" name="to_date" value="<?php echo e(date("Y-m-d",time())); ?>" class="form-control search_keys" id="from_date">
        </div>

        <div class="col-md-2">
            <label for="TextInput" class="form-label"><?php echo e(__("finance::finance.Transaction status")); ?></label>
            <select name="type" id="type" class="form-control search_keys">
                <option value="both"><?php echo e(__('finance::finance.choose')); ?></option>
                <option value="debtor" ><?php echo e(__('finance::finance.debtor')); ?></option>
                <option value="creditor" ><?php echo e(__('finance::finance.creditor')); ?></option>
            </select>
        </div>

        <div class="col-md-2">
            <label for="TextInput" class="form-label"> <?php echo e(__('finance::finance.Show Counter Account')); ?></label>
            <select name="other_account" id="other_account" class="form-control search_keys">
                <option value="no"><?php echo e(__('finance::finance.No')); ?>  </option>
                <option value="yes"><?php echo e(__('finance::finance.Yes')); ?> </option>
            </select>
        </div>

        <div class="col-md-1 mt-4">
            <br>
            <button type="button" id="search_button" class="btn btn-sm btn-success float-right">
                <i class="fa fa-search"></i> <?php echo e(__("finance::finance.Search")); ?>

            </button>
        </div>
    </div>
    <div class="row print-and-excel-buttons d-none">
        <div class="col-12 mt-4" style="text-align: left">
            
            <?php echo printButton(route("finance.double-account-statement-print.index", request()->all()), null, 'finance::finance.double-account-statement-print-read'); ?>

            <button id="toExcel" class="btn btn-info"><i class="fa fa-file-excel-o"></i></button>
        </div>
    </div>
    <div class="row g-3 m-2" id="account_list"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('.select2').select2();
        $("#search_button").on("click", function (e) {
            e.preventDefault()
            var data = $(".search_keys").serialize();
            let accountId = $("#account_id").val();

            if (!accountId || accountId === "") {
                validToster("من فضلك اختر حساب أولاً")
                return; // وقف التنفيذ
            }
            let url = '<?php echo e(route("finance.double-account-statement.index")); ?>';
            $.ajax({
                url: url,
                type: 'GET',
                data: data,
                beforeSend: function () {
                    $("#account_list").html('<div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">' +
                        '  <div class="loader" style="margin: auto;"></div>' +
                        '</div>');
                },
                success: function (result) {
                    console.log(result);
                    $("#account_list").html(result.data.html);
                    $('.print-and-excel-buttons').removeClass('d-none');
                    const filterData = $(".search_keys").serialize();
                    $('#print_button').attr('href', `<?php echo e(route('finance.double-account-statement-print.index')); ?>?${filterData}`);
                },
                error: function (errorObj, errorText, errorThrown) {
                    handleErrorResponce(errorObj);
                }
            });
        });
    </script>
    <script src="<?php echo e(asset("plugins")); ?>/exelJs/dist/tableToExcel.517b1af9.js"></script>
    <script>
        var button = document.querySelector('#toExcel');
        button.addEventListener('click', function (e) {
            var table = document.querySelector('#simpleTable4');
            TableToExcel.convert(table);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/double_account_statment/index.blade.php ENDPATH**/ ?>