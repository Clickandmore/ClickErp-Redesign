<!DOCTYPE html>
<html <?php if(app()->getLocale() == 'ar'): ?> lang="ar" dir="rtl" <?php else: ?>  lang="en" dir="ltr"<?php endif; ?>>
<head>
    <?php echo $__env->make('site.includes.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('site.includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('style'); ?>
    <title>  <?php echo $__env->yieldContent('title'); ?> | <?php echo e(__("ingaz.Platinum Al Sharqiyah Recruitment Agency")); ?></title>

</head>
<body>
<div class="preloader">
    <div class="preloaderImg"></div>
</div>
<header class="sticky-top">
    <?php echo $__env->make('site.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<main>
    <div id="ad-popup" class="ad-popup">
        <div class="ad-popup-content">
            <h5 class="ad-popup-title"><?php echo e(__("ingaz.Special offer!")); ?></h5>
            <p class="ad-popup-desc"><?php echo e(__("ingaz.Take advantage of our new recruitment discounts for a limited time")); ?></p>
        </div>
        <button id="close-ad" class="ad-popup-close" aria-label="إغلاق">&times;</button>
    </div>

    <?php echo $__env->yieldContent('content'); ?>
    <div class="modal fade add_location" id="addLocation" tabindex="-1" aria-labelledby="addLocationLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                </div>
            </div>
        </div>
    </div>
</main>
<!-- themeColor -->
<!-- <div class="themeColor">
    <input type="color" id="colorInput" class="color-input">
</div> -->
<footer class="footer">
    <?php echo $__env->make('site.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php echo $__env->make('site.includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/site/layouts/index.blade.php ENDPATH**/ ?>