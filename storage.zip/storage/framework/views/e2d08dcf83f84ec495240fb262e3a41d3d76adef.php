<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>" enctype="multipart/form-data">
    <div class="col-md-6">
        <label for="name" class="form-label"><?php echo e(__("finance::finance.banks")); ?> </label>
       <select name="bank_id" id="bank_id" class="form-select" data-validation="required">
           <?php echo showSelectElement($banks,'name'); ?>

       </select>
    </div>
    <div class="col-md-6">
        <label for="name" class="form-label"><?php echo e(__("finance::finance.account_name")); ?> </label>
        <input type="text" id="name" name="name" class="form-control" data-validation="required">
    </div>

    <div class="col-md-6">
        <label for="bank_number" class="form-label"><?php echo e(__("finance::finance.bank_number")); ?> </label>
        <input type="text" id="bank_number" name="bank_number" class="form-control" data-validation="required">
    </div>
    <div class="col-md-6">
        <label for="iban" class="form-label"><?php echo e(__("finance::finance.iban")); ?> </label>
        <input type="text" id="iban" name="iban" class="form-control" data-validation="required">
    </div>


    <div class="col-12 modal-footer">
        <?php echo submitButton($storeRoute); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/bank_accounts/create.blade.php ENDPATH**/ ?>