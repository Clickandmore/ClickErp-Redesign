<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.employeePermissions')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance.clients")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php echo addButton(route("employeePermissions.create") , __('hr::hr.Permission')); ?>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('hr::hr.SL')); ?></th>
            <th><?php echo e(__("hr::hr.Employee")); ?> </th>
            <th><?php echo e(__("hr::hr.Permission")); ?> </th>
            <th><?php echo e(__("hr::hr.date")); ?> </th>
            <th><?php echo e(__("hr::hr.Permission time")); ?> </th>
            <th><?php echo e(__("hr::hr.reason")); ?> </th>
            <th><?php echo e(__("hr::hr.Status")); ?></th>
            <th><?php echo e(__("hr::hr.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('hr::hr.employeePermissions._js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ajaxComplete(function () {
            function calculateDuration() {
                const fromTime = $('#from_time').val();
                const toTime = $('#to_time').val();

                if (fromTime && toTime) {
                    const fromDate = new Date('1970-01-01T' + fromTime + 'Z');
                    const toDate = new Date('1970-01-01T' + toTime + 'Z');

                    let diffInMinutes = (toDate - fromDate) / 60000;

                    if (diffInMinutes < 0) {
                        diffInMinutes += 24 * 60;
                    }

                    $('#time').val(diffInMinutes);
                } else {
                    $('#time').val('');
                }
            }
            $('#from_time, #to_time').on('change', calculateDuration);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employeePermissions/index.blade.php ENDPATH**/ ?>