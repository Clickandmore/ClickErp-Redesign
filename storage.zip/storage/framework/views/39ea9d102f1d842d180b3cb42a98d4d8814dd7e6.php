


    <?php if($accounts->count() > 0): ?>

        <table class="table table-hover table-bordered table-striped" id="toExcelTable" style="width:100%">
            <thead>
            <tr class="header">
                <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.account_code")); ?></th>
                <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.account_name")); ?></th>
                <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.notes")); ?></th>
                <th style="width: 5%" scope="col"><?php echo e(__('finance::finance.Balance')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php ( $balance = 0 ); ?>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ( $balance += $row->balance ); ?>

                <tr >
                    <td><?php echo e($row->code); ?></td>
                    <td><?php echo e(@$row->name); ?></td>
                    <td><?php echo e($row->status == 'debtor' ? __('finance::finance.creditor_from_debtor_natural') : __('finance::finance.debtor_from_creditor_natural')); ?></td>
                    <td><?php echo e(-$row->balance); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="3" class="text-center"><?php echo e(__('finance::finance.total')); ?></td>

                <td class="currency-egp" ><?php echo e(-$balance); ?></td>
            </tr>
            </tbody>
        </table>
    <?php else: ?>
        <div role="alert" class="alert alert-danger text-center"> <?php echo e(__('finance::finance.no_data_found')); ?></div>
    <?php endif; ?>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/account_balance_differed_normal/result.blade.php ENDPATH**/ ?>