<form class="row g-3 from-submit-global" method="post" action="<?php echo e(route("departments.store")); ?>" enctype="multipart/form-data">
    <div class="col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.department_name")); ?> </label>
        <input type="text" name="title" class="form-control" data-validation="required">
    </div>

    <div class="col-12 modal-footer">
         <?php echo submitButton( route("departments.store") ); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/department/create.blade.php ENDPATH**/ ?>