<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.departments')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance.clients")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('up-card'); ?>
    <?php echo $__env->make('hr::hr._nav_tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php echo addButton(route("departments.create") , $addButtonText); ?>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('hr::hr.SL')); ?></th>
            <th><?php echo e(__("hr::hr.name")); ?> </th>
            <th><?php echo e(__("hr::hr.number_employees")); ?> </th>
            <th><?php echo e(__("hr::hr.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                {"data": "title", orderable: false, searchable: true},
                {"data": "number_employees", orderable: false, searchable: false},
                {"data": "actions", orderable: false, searchable: false}
            ];
            showDataTable("<?php echo e(route("departments.index")); ?>", columns);
        });




    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/department/index.blade.php ENDPATH**/ ?>