<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo addButton($createRoute , $addButtonText); ?>

    <!-- Button to open the first modal -->

    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th><?php echo e(__('finance::finance.code')); ?> </th>
            <th><?php echo e(__('finance::finance.name')); ?> </th>
            <th><?php echo e(__('finance::finance.phone')); ?> </th>
            <th><?php echo e(__('finance::finance.address')); ?> </th>
            <th><?php echo e(__('finance::finance.suppliers_types')); ?> </th>
            <th><?php echo e(__('finance::finance.commercial_register_number')); ?> </th>
            <th><?php echo e(__('finance::finance.tax_number')); ?> </th>
            <th><?php echo e(__('finance::finance.actions')); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex',name: 'DT_RowIndex',orderable: false,searchable: false},
                {"data": "code",orderable: false,searchable: true},
                {"data": "name",orderable: false,searchable: true},

                {"data": "phone",orderable: false,searchable: true},
                {"data": "address",orderable: false,searchable: true},
                {"data": "supplier_type_id",orderable: false,searchable: true},

                {"data": "commercial_register_number",orderable: false,searchable: true},
                {"data": "tax_number",orderable: false,searchable: true},
                {"data": "actions",orderable: false,searchable: false},
            ];
            showDataTable("<?php echo e($dataTableRoute); ?>", columns);
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/supplier/index.blade.php ENDPATH**/ ?>