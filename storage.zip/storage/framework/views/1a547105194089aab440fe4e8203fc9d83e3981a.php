<div class="sidebar p-2 py-md-3 @cardClass">
    <div class="container-fluid p-0">

        <div class="title-text d-flex align-items-center mb-4 mt-1">
            <h4 class="sidebar-title mb-0 flex-grow-1"><span class="sm-txt"></span>
                
            </h4>
            <div class="dropdown morphing scale-right">
                <a class="dropdown-toggle more-icon" href="#" role="button" data-bs-toggle="dropdown"><i
                        class="fa fa-ellipsis-h"></i></a>
                <ul class="dropdown-menu shadow border-0 p-2 mt-2" data-bs-popper="none">
                    <li class="fw-bold px-2">روابط سريعة</li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    
                    <li><a class="dropdown-item" href="<?php echo e(route('settings.index')); ?>" aria-current="page">
                            <?php echo e(__('ingaz.settings')); ?></a>
                    </li>
                    
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                </ul>
            </div>
        </div>

        
        
        

        <div class="main-menu flex-grow-1">
            <?php
                $newStatus = \App\Enums\ingaz\ContractStatusEnum::New;
                $msanedStatus = \App\Enums\ingaz\ContractStatusEnum::Msaned;
                $tafwedStatus = \App\Enums\ingaz\ContractStatusEnum::Tafwed;
                $taffezStatus = \App\Enums\ingaz\ContractStatusEnum::Taffez;
                $tazkerStatus = \App\Enums\ingaz\ContractStatusEnum::Tazker;
                $underWarrantyStatus = \App\Enums\ingaz\ContractStatusEnum::UnderWarranty;
                $backStatus = \App\Enums\ingaz\ContractStatusEnum::Back;
                $arrivalStatus = \App\Enums\ingaz\ContractStatusEnum::Arrival;
                $sariStatus = \App\Enums\ingaz\ContractStatusEnum::Sari;
                $closedStatus = \App\Enums\ingaz\ContractStatusEnum::Closed;
                $completedStatus = \App\Enums\ingaz\ContractStatusEnum::Completed;
            ?>
            <ul class="menu-list">
                <!-- Dashboard Section -->
                <li class="divider py-2 lh-sm"><span class="small"><?php echo e(helperTrans('ingaz.dashboard')); ?></span></li>
                <?php if(@AdminGuardHasPerm(\App\PermKeys::DASHBOARD_VIEW)): ?>
                    <li>
                        <a class="m-link <?php echo e((Route::currentRouteName() == 'dashboard.index') ? 'active' : ''); ?>"
                           href="<?php echo e(route('dashboard.index')); ?>">
                            <i class="fa fa-home"></i>
                            <span class="ms-2"><?php echo e(helperTrans('ingaz.home')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>

                <!-- Clients Section -->
                <li>
                    <a class="m-link <?php echo e((Route::currentRouteName() == 'clients.index') ? 'active' : ''); ?>"
                       href="<?php echo e(route('clients.index')); ?>">
                        <i class="fa fa-user"></i>
                        <span class="ms-2"> <?php echo e(helperTrans('ingaz.clients')); ?></span>
                    </a>
                </li>



                <!-- CV Management Section -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#cvManagement" href="#">
                        <i class="fa fa-file-text"></i>
                        <span class="ms-2"><?php echo e(helperTrans('ingaz.cv_management')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['maids.index', 'noneAvailableMaids', 'maids.create'])) ? 'show' : ''); ?>"
                        id="cvManagement">
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::MAIDS_CREATE)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'maids.create') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('maids.create')); ?>">
                                    <i class="fa fa-plus"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.add_cv')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::MAIDS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'maids.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('maids.index')); ?>">
                                    <i class="fa fa-list"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.cvs')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'noneAvailableMaids') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('noneAvailableMaids')); ?>">
                                    <i class="fa fa-times-circle"></i>
                                    <span class="ms-2">عاملات باك اوت</span>
                                </a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </li>

                <!-- Orders Section -->

                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#my_dashboard2" href="#">
                        <i class="fa fa-shopping-cart"></i>
                        <span class="ms-2"><?php echo e(helperTrans('ingaz.orders')); ?>  </span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['orders.current', 'orders.ended'])) ? 'show' : ''); ?>"
                        id="my_dashboard2">
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::ORDERS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e(!request()->input('status') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('orders.index')); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.all orders')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(request()->input('status') === 'current' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('orders.index', ['status' => 'current'])); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.new orders')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(request()->input('status') === 'completed' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('orders.index', ['status' => 'completed'])); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.contracted orders')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::RETURN_REQUEST_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'return_requests.index' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('return_requests.index')); ?>">
                                    <i class="fa fa-times-circle"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.cancelled_orders')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <li>
                            <a class="m-link <?php echo e((Route::currentRouteName() == 'professional_application.index') ? 'active' : ''); ?>"
                               href="<?php echo e(route('professional_application.index')); ?>">
                                <i class="fa fa-envelope"></i>
                                <span class="ms-2">  <?php echo e(helperTrans("ingaz.request_professional_labor")); ?></span>
                            </a>
                        </li>
                        

                        
                        <li>
                            <a class="m-link <?php echo e((Route::currentRouteName() == 'recruitment_requests.index') ? 'active' : ''); ?>"
                               href="<?php echo e(route('recruitment_requests.index')); ?>">
                                <i class="fa fa-envelope"></i>
                                <span class="ms-2"> <?php echo e(helperTrans('ingaz.recruitment_requests')); ?></span>
                            </a>
                        </li>
                        

                        
                        <li>
                            <a class="m-link <?php echo e((Route::currentRouteName() == 'renew-contracts.index') ? 'active' : ''); ?>"
                               href="<?php echo e(route('renew-contracts.index')); ?>">
                                <i class="fa fa-envelope"></i>
                                <span class="ms-2"> <?php echo e(helperTrans('ingaz.renew-contracts')); ?></span>
                            </a>
                        </li>
                        
                    </ul>
                </li>


                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#contracts" href="#">
                        <i class="fa fa-file"></i>
                        <span class="ms-2"> <?php echo e(helperTrans('ingaz.Recruitment contracts')); ?> </span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['RecruitmentContracts.index'])) ? 'show' : ''); ?>"
                        id="contracts">
                        <?php if(@AdminGuardHasPerm(\App\NewPermKeys::REC_CONTRACTS_CREATE)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('RecruitmentContract.create')); ?>">
                                    <i class="icon-star"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.add Recruitment contract')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\NewPermKeys::REC_CONTRACTS_VIEW)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('RecruitmentContract.index')); ?>">
                                    <i class="fa fa-list"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.All Recruitment contracts')); ?></span>&nbsp;&nbsp;
                                    <span class="badge bg-primary ms-2"><?php echo e($contractsCount['all']); ?></span>
                                </a>
                            </li>
                            <?php if(@AdminGuardHasPerm(\App\NewPermKeys::REC_CONTRACTS_CHANGE_TO_MSANED)): ?>
                                <li>
                                    <a class="m-link"
                                       href="<?php echo e(route('RecruitmentContract.index', ['status' => $newStatus->value])); ?>">
                                        <i class="fa fa-plus"></i>
                                        <span class="ms-2"><?php echo e(helperTrans('ingaz.new Recruitment contracts')); ?></span>&nbsp;
                                        <span class="badge bg-primary ms-2"><?php echo e($contractsCount['new']); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <a class="m-link"
                                   href="<?php echo e(route('RecruitmentContract.index', ['status' => 'pending_maid_selection'])); ?>">
                                    <i class="fa fa-clock-o"></i>
                                    <span class="ms-2">بانتظار اختيار العاملة</span>&nbsp;
                                    <span
                                        class="badge bg-warning ms-2"><?php echo e($contractsCount['pending_maid_selection'] ?? 0); ?></span>
                                </a>
                            </li>
                            <?php if(@AdminGuardHasPerm(\App\NewPermKeys::REC_CONTRACTS_CHANGE_TO_TAFWED)): ?>
                                <li>
                                    <a class="m-link"
                                       href="<?php echo e(route('RecruitmentContract.index', ['status' => $msanedStatus->value])); ?>">
                                        <i class="fa fa-plus"></i>
                                        <span class="ms-2"><?php echo e(helperTrans('ingaz.msaned')); ?></span>&nbsp;&nbsp;
                                        <span class="badge bg-primary ms-2"><?php echo e($contractsCount['msaned']); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(@AdminGuardHasPerm(\App\NewPermKeys::REC_CONTRACTS_CHANGE_TO_TAFFEZ)): ?>
                                <li>
                                    <a class="m-link"
                                       href="<?php echo e(route('RecruitmentContract.index', ['status' => $tafwedStatus->value])); ?>">
                                        <i class="fa fa-clock-o"></i>
                                        <span class="ms-2"><?php echo e(helperTrans('ingaz.tafwed')); ?></span>&nbsp;&nbsp;
                                        <span class="badge bg-primary ms-2"><?php echo e($contractsCount['tafwed']); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <a class="m-link"
                                   href="<?php echo e(route('RecruitmentContract.index', ['status' => $taffezStatus->value])); ?>">
                                    <i class="fa fa-clock-o"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.taffez')); ?></span>&nbsp;&nbsp;
                                    <span class="badge bg-primary ms-2"><?php echo e($contractsCount['taffez']); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link"
                                   href="<?php echo e(route('RecruitmentContract.index', ['status' => $tazkerStatus->value])); ?>">
                                    <i class="fa fa-clock-o"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.tazker')); ?></span>&nbsp;&nbsp;
                                    <span class="badge bg-primary"><?php echo e($contractsCount['tazker']); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link"
                                   href="<?php echo e(route('RecruitmentContract.index', ['status' => 'completed', 'warranty_status' => 'active'])); ?>">
                                    <i class="fa fa-shield"></i>
                                    <span class="ms-2"> تحت الضمان</span>&nbsp;&nbsp;
                                    <span class="badge bg-warning"><?php echo e($contractsCount['under_warranty']); ?></span>
                                </a>
                            </li>
                            <?php if(@AdminGuardHasPerm(\App\NewPermKeys::REC_CONTRACTS_VIEW)): ?>
                                <li>
                                    <a class="m-link"
                                       href="<?php echo e(route('RecruitmentContract.index', ['status' => $backStatus->value])); ?>">
                                        <i class="fa fa-undo"></i>
                                        <span class="ms-2"><?php echo e(helperTrans('ingaz.back_contracts')); ?></span>&nbsp;
                                        <span class="badge bg-danger"><?php echo e($contractsCount['back']); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a class="m-link"
                                       href="<?php echo e(route('RecruitmentContract.index', ['status' => 'completed', 'warranty_status' => 'expired,not_applicable'])); ?>">
                                        <i class="fa fa-check-circle"></i>
                                        <span class="ms-2">عقود مكتملة</span>&nbsp;&nbsp;
                                        <span
                                            class="badge bg-primary ms-2"><?php echo e($contractsCount['completed'] - $contractsCount['under_warranty']); ?></span>
                                    </a>
                                </li>

                            <?php endif; ?>
                        <?php endif; ?>

                    </ul>
                </li>

                <!-- Rent Contracts -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#rentcontracts" href="#">
                        <i class="fas fa-handshake"></i>
                        <span class="ms-2"> <?php echo e(helperTrans('ingaz.Rent contracts')); ?> </span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['RentContract.index', 'RentContract.create', 'RentContract.show', 'RentContract.edit'])) ? 'show' : ''); ?>"
                        id="rentcontracts">
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::RENT_CONTRACT_CREATE)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'RentContract.create') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('RentContract.create')); ?>">
                                    <i class="fas fa-plus"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.add Rent contract')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::RENT_CONTRACT_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'rental-orders.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('rental-orders.index')); ?>">
                                    <i class="fas fa-shopping-cart"></i>
                                    <span class="ms-2">طلبات الإيجار</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'RentContract.index' && !request('status')) ? 'active' : ''); ?>"
                                   href="<?php echo e(route('RentContract.index')); ?>">
                                    <i class="fas fa-list"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.All Rent contracts')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'RentContract.index' && request('status') == 'new') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('RentContract.index', ['status' => 'new'])); ?>">
                                    <i class="fas fa-file-plus text-primary"></i>
                                    <span class="ms-2">العقود الجديدة</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'RentContract.index' && request('status') == 'active') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('RentContract.index', ['status' => 'active'])); ?>">
                                    <i class="fas fa-check-circle text-success"></i>
                                    <span class="ms-2">العقود النشطة</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'RentContract.index' && request('status') == 'completed') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('RentContract.index', ['status' => 'completed'])); ?>">
                                    <i class="fas fa-flag-checkered text-info"></i>
                                    <span class="ms-2">العقود المكتملة</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'RentContract.index' && request('status') == 'cancelled') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('RentContract.index', ['status' => 'cancelled'])); ?>">
                                    <i class="fas fa-times-circle text-danger"></i>
                                    <span class="ms-2">العقود الملغية</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::CONTRACT_SETTINGS)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'contract.settings') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('contract.settings')); ?>">
                                    <i class="fas fa-cog"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.contract_settings')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::PACKAGES_VIEW)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('packages.index')); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.packages')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <a class="m-link <?php echo e((in_array(Route::currentRouteName(), ['rent-contract-terms.index', 'rent-contract-terms.create', 'rent-contract-terms.edit'])) ? 'active' : ''); ?>"
                               href="<?php echo e(route('rent-contract-terms.index')); ?>">
                                <i class="fa fa-file-contract"></i>
                                <span class="ms-2">بنود عقد الإيجار</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Shelter Contracts -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#sheltercontracts" href="#">
                        <i class="icon-home"></i>
                        <span class="ms-2"> <?php echo e(__('ingaz.shelter_management')); ?> </span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['ShelterContract.index', 'ShelterContract.availableForTransfer', 'ShelterContract.deportationStage', 'ShelterContract.generalShelter', 'ShelterContract.deported'])) ? 'show' : ''); ?>"
                        id="sheltercontracts">
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::SHELTER_CONTRACT_CONTROL)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('ShelterContract.create')); ?>">
                                    <i class="icon-star"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.add_shelter')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::SHELTER_CONTRACT_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'ShelterContract.index' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('ShelterContract.index')); ?>">
                                    <i class="icon-loop"></i>
                                    <span class="ms-2"> داخل الإيواء</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'ShelterContract.availableForTransfer' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('ShelterContract.availableForTransfer')); ?>">
                                    <i class="fa fa-user"></i>
                                    <span class="ms-2">متاح للنقل</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'ShelterContract.deportationStage' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('ShelterContract.deportationStage')); ?>">
                                    <i class="fa fa-plane"></i>
                                    <span class="ms-2">مرحلة الترحيل</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'ShelterContract.deported' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('ShelterContract.deported')); ?>">
                                    <i class="fa fa-check-circle"></i>
                                    <span class="ms-2">تم الترحيل</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::SHELTER_PLACES_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'shelter-places.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('shelter-places.index')); ?>">
                                    <i class="fa fa-building"></i>
                                    <span class="ms-2"> <?php echo e(helperTrans('ingaz.shelter-places')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <!-- Logistics Services Section -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#logisticsMenu" href="#">
                        <i class="fa fa-truck"></i>
                        <span class="ms-2">الخدمات اللوجستية</span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['DeportationTravel.index', 'DeportationTravel.create', 'travel', 'travel.control'])) ? 'show' : ''); ?>"
                        id="logisticsMenu">
                        <li>
                            <a class="m-link <?php echo e(Route::currentRouteName() == 'DeportationTravel.index' ? 'active' : ''); ?>"
                               href="<?php echo e(route('DeportationTravel.index')); ?>">
                                <i class="fa fa-plane-departure"></i>
                                <span class="ms-2">رحلات الترحيل</span>
                            </a>
                        </li>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::TRAVEL_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'travel' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('travel')); ?>">
                                    <i class="fa fa-plane-arrival"></i>
                                    <span class="ms-2">رحلات الاستقدام</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <!-- Complaints Section -->
                <?php if(@AdminGuardHasPerm(\App\PermKeys::COMPLAINT_VIEW)): ?>
                    <li class="collapsed">
                        <a class="m-link" data-bs-toggle="collapse" data-bs-target="#complaintsMenu" href="#">
                            <i class="fa fa-exclamation-triangle"></i>
                            <span class="ms-2"><?php echo e(helperTrans('ingaz.complaints_management')); ?></span>
                            <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                        </a>
                        <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['complaints.index', 'complaints.create', 'complaint-types.index'])) ? 'show' : ''); ?>"
                            id="complaintsMenu">
                            <li>
                                <a class="m-link <?php echo e(Route::currentRouteName() == 'complaints.index' ? 'active' : ''); ?>"
                                   href="<?php echo e(route('complaints.index')); ?>">
                                    <i class="fa fa-list"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.complaints')); ?></span>
                                    <?php if(isset($unreadComplaintsCount) && $unreadComplaintsCount > 0): ?>
                                        <span class="badge bg-primary"><?php echo e($unreadComplaintsCount); ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <?php if(@AdminGuardHasPerm(\App\PermKeys::COMPLAINT_CREATE)): ?>
                                <li>
                                    <a class="m-link <?php echo e(Route::currentRouteName() == 'complaints.create' ? 'active' : ''); ?>"
                                       href="<?php echo e(route('complaints.create')); ?>">
                                        <i class="fa fa-plus-circle"></i>
                                        <span class="ms-2">إضافة شكوى جديدة</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(@AdminGuardHasPerm(\App\PermKeys::COMPLAINT_TYPE_VIEW)): ?>
                                <li>
                                    <a class="m-link <?php echo e(Route::currentRouteName() == 'complaint-types.index' ? 'active' : ''); ?>"
                                       href="<?php echo e(route('complaint-types.index')); ?>">
                                        <i class="fa fa-tags"></i>
                                        <span class="ms-2"><?php echo e(helperTrans('ingaz.complaint_types')); ?></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- طلبات استرجاع العقود -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#returnRequestsMenu" href="#">
                        <i class="fa fa-undo"></i>
                        <span class="ms-2">طلبات استرجاع العقود</span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['contract-return-requests.index', 'contract-return-requests.show'])) ? 'show' : ''); ?>"
                        id="returnRequestsMenu">
                        <li>
                            <a class="m-link <?php echo e(Route::currentRouteName() == 'contract-return-requests.index' ? 'active' : ''); ?>"
                               href="<?php echo e(route('contract-return-requests.index')); ?>">
                                <i class="fa fa-list"></i>
                                <span class="ms-2">جميع الطلبات</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Additional Services Section -->

                <?php if(@AdminGuardHasPerm(\App\PermKeys::SPONSOR_TRANSFER_VIEW)): ?>
                    <li class="collapsed">
                        <a class="m-link" data-bs-toggle="collapse" data-bs-target="#sponsorshipTransfer" href="#">
                            <i class="icon-directions"></i>
                            <span class="ms-2"><?php echo e(helperTrans('ingaz.sponsorship_transfer')); ?></span>
                            <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                        </a>
                        <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['SponsorshipTransfer.create', 'SponsorshipTransfer.index', 'SponsorshipTransfer.webRequests', 'ShelterContract.availableForTransfer', 'SponsorshipTransfer.trial', 'SponsorshipTransfer.failed', 'SponsorshipTransfer.transferred', 'transfer-contract-terms.index', 'transfer-contract-terms.create', 'transfer-contract-terms.edit'])) ? 'show' : ''); ?>"
                            id="sponsorshipTransfer">
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'SponsorshipTransfer.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('SponsorshipTransfer.index')); ?>">
                                    <i class="fa fa-list"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.sponsorship_transfer_requests')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'SponsorshipTransfer.webRequests') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('SponsorshipTransfer.webRequests')); ?>">
                                    <i class="fa fa-globe"></i>
                                    <span class="ms-2">طلبات الموقع الخارجي</span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'SponsorshipTransfer.create') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('SponsorshipTransfer.create')); ?>">
                                    <i class="fa fa-plus"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.add_transfer_request')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'ShelterContract.availableForTransfer') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('ShelterContract.availableForTransfer')); ?>">
                                    <i class="fa fa-check-circle"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.available_for_transfer')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'SponsorshipTransfer.trial') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('SponsorshipTransfer.trial')); ?>">
                                    <i class="fa fa-clock-o"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.trial_period')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'SponsorshipTransfer.failed') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('SponsorshipTransfer.failed')); ?>">
                                    <i class="fa fa-times-circle"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.trial_failed')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'SponsorshipTransfer.transferred') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('SponsorshipTransfer.transferred')); ?>">
                                    <i class="fa fa-check"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.transferred')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((in_array(Route::currentRouteName(), ['transfer-contract-terms.index', 'transfer-contract-terms.create', 'transfer-contract-terms.edit'])) ? 'active' : ''); ?>"
                                   href="<?php echo e(route('transfer-contract-terms.index')); ?>">
                                    <i class="fa fa-file-text"></i>
                                    <span class="ms-2">بنود عقد نقل الكفالة</span>
                                </a>
                            </li>

                        </ul>
                    </li>
                <?php endif; ?>
                <!-- Settings Section -->
                


                <!-- Maids Settings Section -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#my_dashboard3" href="#">
                        <i class="fa fa-cog"></i>
                        <span class="ms-2"><?php echo e(helperTrans('ingaz.maids_data_management')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['job-titles.index', 'packages.index', 'nationalities.index', 'religions.index', 'countries.index'])) ? 'show' : ''); ?>"
                        id="my_dashboard3">
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::NATIONALITIES_VIEW)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('nationalities.index')); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.nationalities')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::REC_OFFICES_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'recruitment-offices.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('recruitment-offices.index')); ?>">
                                    <i class="fa fa-building"></i>
                                    <span class="ms-2"> <?php echo e(helperTrans('ingaz.recruitment-offices')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::JOB_TITLES_VIEW)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('job-titles.index')); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.job_titles')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>


                        <?php if(@AdminGuardHasPerm(\App\PermKeys::RELIGIONS_VIEW)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('religions.index')); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.religions')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::SKILLS_VIEW)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('skills.index')); ?>">
                                    <i class="fa fa-arrow-left"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.skills')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::USERS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'countries.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('countries.index')); ?>">
                                    <i class="fa fa-globe"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.countries')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'cities.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('cities.index')); ?>">
                                    <i class="fa fa-city"></i>
                                    <span class="ms-2">المدن</span>
                                </a>
                            </li>
                            
                            
                            
                            
                            
                            
                            
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::MAIDS_VIEW)): ?>
                            <li>
                                <a class="m-link" href="<?php echo e(route('social-statuses.index')); ?>" target="_blank">
                                    <i class="fa fa-heart"></i>
                                    <span class="ms-2">الحالات الاجتماعية</span>
                                    <span class="badge bg-success ms-2" style="font-size: 10px;">✅</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <!-- Staff Management Section -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#staffManagement" href="#">
                        <i class="fa fa-users"></i>
                        <span class="ms-2"><?php echo e(helperTrans('ingaz.staff_management')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['admins.index', 'dash.roles.index', 'dash.activity.log'])) ? 'show' : ''); ?>"
                        id="staffManagement">
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::USERS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'admins.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('admins.index')); ?>">
                                    <i class="fa fa-users"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.users')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::ROLES_VIEW)): ?>
                            <li>
                                <a href="<?php echo e(route('dash.roles.index')); ?>"
                                   class="m-link <?php if(Route::currentRouteName() == 'dash.roles.index'): ?> active <?php endif; ?>">
                                    <i class="fa fa-user"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.permissions')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::SETTINGS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'dash.activity.log') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('dash.activity.log')); ?>">
                                    <i class="fa fa-history"></i>
                                    <span class="ms-2"><?php echo e(__('admin.activity_log')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <!-- Content Management Section -->
                

                <!-- Website Management Section -->
                <li class="collapsed">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#websiteManagement" href="#">
                        <i class="fa fa-globe"></i>
                        <span class="ms-2"><?php echo e(helperTrans('ingaz.website_management')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e((in_array(Route::currentRouteName(), ['settings.index', 'about-us.index', 'questions.index', 'dash.settings'])) ? 'show' : ''); ?>"
                        id="websiteManagement">
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::SETTINGS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'settings.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('settings.index')); ?>">
                                    <i class="fa fa-cogs"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.website_settings')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'dash.settings') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('dash.settings')); ?>">
                                    <i class="fa fa-cog"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.additional_settings')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <a class="m-link" href="/admin/sms-templates">
                                <i class="fa fa-sms"></i>
                                <span class="ms-2">قوالب الرسائل النصية</span>
                            </a>
                        </li>
                        <li>
                            <a class="m-link" href="<?php echo e(route('istiqdam.index')); ?>">
                                <i class="fa fa-building"></i>
                                <span class="ms-2">منصة الاستقدام</span>
                            </a>
                        </li>
                        <li>
                            <a class="m-link <?php echo e((Request::is('migration/*') || Request::is('migration.php')) ? 'active' : ''); ?>" href="/migration/new_migration_system.php">
                                <i class="fa fa-exchange"></i>
                                <span class="ms-2">نظام نقل البيانات</span>
                                <span class="badge bg-success ms-2">محدث</span>
                            </a>
                        </li>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::ABOUT_US_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'about-us.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('about-us.index')); ?>">
                                    <i class="fa fa-info"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.about_us')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(@AdminGuardHasPerm(\App\PermKeys::SLIDERS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'sliders.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('sliders.index')); ?>">
                                    <i class="fa fa-image"></i>
                                    <span class="ms-2"> <?php echo e(helperTrans('ingaz.sliders')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(@AdminGuardHasPerm(\App\PermKeys::STATISTICS_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'statistics.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('statistics.index')); ?>">
                                    <i class="fa fa-bar-chart"></i>
                                    <span class="ms-2"> <?php echo e(helperTrans('ingaz.statistics')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <li>
                            <a class="m-link <?php echo e((Route::currentRouteName() == 'select-workers.index') ? 'active' : ''); ?>"
                               href="<?php echo e(route('select-workers.index')); ?>">
                                <i class="fa fa-bar-chart"></i>
                                <span class="ms-2"> <?php echo e(helperTrans('ingaz.select_workers')); ?></span>
                            </a>
                        </li>
                        
                        
                        <li>
                            <a class="m-link <?php echo e((Route::currentRouteName() == 'select-workers-settings.index') ? 'active' : ''); ?>"
                               href="<?php echo e(route('select-workers-settings.index')); ?>">
                                <i class="fa fa-bar-chart"></i>
                                <span class="ms-2"> <?php echo e(helperTrans('ingaz.select_workers_settings')); ?></span>
                            </a>
                        </li>
                        

                        <?php if(@AdminGuardHasPerm(\App\PermKeys::FAQ_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'questions.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('questions.index')); ?>">
                                    <i class="fa fa-question"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.faq')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <li>
                            <a class="m-link <?php echo e((Route::currentRouteName() == 'partenrs.index') ? 'active' : ''); ?>"
                               href="<?php echo e(route('partenrs.index')); ?>">
                                <i class="fa fa-user"></i>
                                <span class="ms-2"> <?php echo e(helperTrans('ingaz.partenrs')); ?></span>
                            </a>
                        </li>

                        <li>
                            <a class="m-link <?php echo e((Route::currentRouteName() == 'requiremens.index') ? 'active' : ''); ?>"
                               href="<?php echo e(route('requiremens.index')); ?>">
                                <i class="fa fa-user"></i>
                                <span class="ms-2"> <?php echo e(helperTrans('ingaz.requiremens')); ?></span>
                            </a>
                        </li>


                        <?php if(@AdminGuardHasPerm(\App\PermKeys::FAQ_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'services.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('services.index')); ?>">
                                    <i class="fa fa-question"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.services')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(@AdminGuardHasPerm(\App\PermKeys::FAQ_VIEW)): ?>
                            <li>
                                <a class="m-link <?php echo e((Route::currentRouteName() == 'features.index') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('features.index')); ?>">
                                    <i class="fa fa-question"></i>
                                    <span class="ms-2"><?php echo e(helperTrans('ingaz.features')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </li>
                
                <li>
                    <a class="m-link <?php echo e((Route::currentRouteName() == 'offices.index') ? 'active' : ''); ?>"
                       href="<?php echo e(route('offices.index')); ?>">
                        <i class="fa fa-envelope"></i>
                        <span class="ms-2"> <?php echo e(helperTrans('ingaz.offices')); ?></span>
                    </a>
                </li>
                
                <?php if(@AdminGuardHasPerm(\App\PermKeys::NOTIFICATIONS_CONTROL)): ?>
                    <li>
                        <a class="m-link <?php echo e((Route::currentRouteName() == 'notifications.index') ? 'active' : ''); ?>"
                           href="<?php echo e(route('notifications.index')); ?>">
                            <i class="fa fa-bell"></i>
                            <span class="ms-2"> <?php echo e(helperTrans('ingaz.notifications')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(@AdminGuardHasPerm(\App\PermKeys::CONTACT_VIEW)): ?>
                    <li>
                        <a class="m-link <?php echo e((Route::currentRouteName() == 'contact.index') ? 'active' : ''); ?>"
                           href="<?php echo e(route('contact.index')); ?>">
                            <i class="fa fa-envelope"></i>
                            <span class="ms-2"> <?php echo e(helperTrans('ingaz.contact_us')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php
                    $isHr = request()->is('hr*');
                ?>
                <li class="<?php echo e($isHr ? '' : 'collapsed'); ?>">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#hr" href="#">
                        <i class="fa fa-file-text"></i>
                        <span class="ms-2"><?php echo e(helperTrans('hr')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e($isHr ? 'show' : ''); ?>" id="hr">
                        <?php echo $__env->make('hr::hr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </li>
                <?php
                    $isFinance = request()->is('finance*');
                ?>
                <li class="<?php echo e($isFinance ? '' : 'collapsed'); ?>">
                    <a class="m-link" data-bs-toggle="collapse" data-bs-target="#finance" href="#">
                        <i class="fa fa-file-text"></i>
                        <span class="ms-2"><?php echo e(helperTrans('finance')); ?></span>
                        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
                    </a>
                    <ul class="sub-menu collapse <?php echo e($isFinance ? 'show' : ''); ?>" id="finance">
                        <?php echo $__env->make('finance::finance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </li>



            </ul>
        </div>

        
        <ul class="menu-list nav navbar-nav flex-row text-center menu-footer-link">
            <li class="nav-item flex-fill p-2">
                <a class="d-inline-block w-100 color-400" href="<?php echo e(route("settings.index")); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="currentColor" viewBox="0 0 16 16">
                        <path
                            d="M14 1a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H4.414A2 2 0 0 0 3 11.586l-2 2V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12.793a.5.5 0 0 0 .854.353l2.853-2.853A1 1 0 0 1 4.414 12H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z"/>
                        <path class="fill-secondary"
                              d="M3 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3 6a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9A.5.5 0 0 1 3 6zm0 2.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                </a>
            </li>
            <li class="nav-item flex-fill p-2">
                <a class="d-inline-block w-100 color-400" href="<?php echo e(route("admin.logout")); ?>" title="sign-out">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M7.5 1v7h1V1h-1z"/>
                        <path class="fill-secondary"
                              d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z"/>
                    </svg>
                </a>
            </li>
        </ul>
        
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // تحسين انتقالات القوائم المنسدلة
        const collapseElements = document.querySelectorAll('.collapse');
        collapseElements.forEach(element => {
            element.addEventListener('show.bs.collapse', function () {
                const arrow = this.previousElementSibling.querySelector('.arrow');
                if (arrow) {
                    arrow.style.transform = 'rotate(0deg)';
                }
            });

            element.addEventListener('hide.bs.collapse', function () {
                const arrow = this.previousElementSibling.querySelector('.arrow');
                if (arrow) {
                    arrow.style.transform = 'rotate(-90deg)';
                }
            });
        });

        // إضافة تأثير نبض للعناصر النشطة
        const activeLinks = document.querySelectorAll('.m-link.active');
        activeLinks.forEach(link => {
            link.style.animation = 'pulse 2s infinite';
        });

        // تحسين التمرير للعنصر النشط
        const activeElement = document.querySelector('.menu-list .m-link.active');
        if (activeElement) {
            setTimeout(() => {
                activeElement.scrollIntoView({behavior: 'smooth', block: 'center'});
            }, 300);
        }
    });

    // إضافة تأثير pulse
    const style = document.createElement('style');
    style.textContent = `
    @keyframes  pulse {
        0% {
            box-shadow: 0 2px 4px rgba(78, 115, 223, 0.25);
        }
        50% {
            box-shadow: 0 2px 8px rgba(78, 115, 223, 0.4);
        }
        100% {
            box-shadow: 0 2px 4px rgba(78, 115, 223, 0.25);
        }
    }
`;
    document.head.appendChild(style);
</script>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/nami/layout/inc/sidebar.blade.php ENDPATH**/ ?>