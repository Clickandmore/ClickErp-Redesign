<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mb-3 align-items-center">
        <div class="col-md-6">
            <label for="branch_admin_id"><?php echo e(__("finance::finance.client-categories")); ?></label>
            <select id="category_id" name="category_id" class="form-control select2">
                <option value=""><?php echo e(__('finance::finance.choose')); ?></option>
                <?php $__currentLoopData = \DB::table('fn_client_categories')->get() ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category_id->id); ?>"><?php echo e($category_id->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6 mt-3">
            <?php echo addButton($createRoute , $addButtonText); ?>

        </div>
    </div>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th><?php echo e(__("finance::finance.code")); ?></th>
            <th><?php echo e(__("finance::finance.name")); ?></th>
            <th><?php echo e(__("finance::finance.phone")); ?></th>
            <th><?php echo e(__("finance::finance.tax_number")); ?></th>
            <th><?php echo e(__("finance::finance.current_balance")); ?></th>
            <th><?php echo e(__("finance::finance.debt_ceiling")); ?></th>
            <th><?php echo e(__("finance::finance.client_category")); ?></th>
            <th><?php echo e(__("finance::finance.status")); ?></th>
            <th><?php echo e(__("finance::finance.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {"data": "code", orderable: false, searchable: false},
                {"data": "name", orderable: true, searchable: true},
                {"data": "phone", orderable: false, searchable: true},
                {"data": "tax_number", orderable: false, searchable: true},
                {"data": "current_balance", orderable: true, searchable: true},
                {"data": "credit_limit", orderable: true, searchable: true},
                {"data": "client_category_id", true: false, searchable: true},
                {"data": "status", orderable: false, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ];
            let table = $("#dataTableObject").DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                ordering: true,
                searching: true,
                iDisplayLength: 10,
                lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
                ajax: {
                    url: "<?php echo e($dataTableRoute); ?>",
                    data: function (response) {
                        response.category_id = $('#category_id').val();
                    }
                },
                columns,
                language: {
                    sProcessing: "<?php echo e(trans('dataTable.sProcessing')); ?>",
                    sLengthMenu: "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                    sZeroRecords: "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                    sInfo: "<?php echo e(trans('dataTable.sInfo')); ?>",
                    sInfoEmpty: "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                    sInfoFiltered: "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                    sSearch: "<?php echo e(trans('dataTable.sSearch')); ?>:",
                    oPaginate: {
                        sFirst: "<?php echo e(trans('dataTable.sFirst')); ?>",
                        sPrevious: "<?php echo e(trans('dataTable.sPrevious')); ?>",
                        sNext: "<?php echo e(trans('dataTable.sNext')); ?>",
                        sLast: "<?php echo e(trans('dataTable.sLast')); ?>"
                    }
                },
                order: [[2, "desc"]]
            });

            $('#category_id').on('change', function () {
                table.ajax.reload();
            });
        });
        $(document).on('click', '.update-status', function (e) {
            var id = $(this).data('id');
            var url = "<?php echo e(route('finance.clients.show', ':id')); ?>";
            url = url.replace(':id', id);
            $.ajax({
                type: 'get',
                url: url,
                success: function (data) {
                    console.log(data)
                    if (data.data.success) {
                        $.toast({
                            heading: 'نجاح',
                            text: 'تم تغيير الحالة بنجاح!',
                            showHideTransition: 'slide',
                            icon: 'success',
                            hideAfter: 2000,
                            position: 'top-right',
                            stack: 1
                        });

                        setTimeout(function () {
                            $('#dataTableObject').DataTable().ajax.reload();
                        }, 1500);
                    } else {
                        alert('فشل في تحديث الحالة.');
                    }
                },
                error: function () {
                    alert('حدث خطأ أثناء التحديث.');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/clients/index.blade.php ENDPATH**/ ?>