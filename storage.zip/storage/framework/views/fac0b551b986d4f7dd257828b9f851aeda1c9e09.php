<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card-header bg-success text-white mb-3">
        <?php echo e(__("finance::finance.stocks")); ?>

    </div>
    <div class="row mb-3">
        <div class="col-md-6 mx-auto">
            <div class="form-group">
                <label class="form-label d-block mb-2 text-center fw-bold">
                    <?php echo e(__("finance::finance.have_cost_center")); ?>

                </label>
                <div class="d-flex justify-content-center gap-4">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="stocks_has_cost_center"
                               id="yesOption_stocks" value="1">
                        <label class="form-check-label" for="yesOption_stocks"><?php echo e(__("finance::finance.yes")); ?></label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="stocks_has_cost_center"
                               id="noOption_stocks" value="0">
                        <label class="form-check-label" for="noOption_stocks"><?php echo e(__("finance::finance.no")); ?></label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <table id="dataTableObject-stocks" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th><?php echo e(__('finance::finance.code')); ?></th>
            <th><?php echo e(__('finance::finance.name')); ?></th>
            <th><?php echo e(__('finance::finance.phone')); ?></th>
            <th><?php echo e(__('finance::finance.address')); ?></th>
            <th><?php echo e(__('finance::finance.stockKeeper')); ?></th>
            <th><?php echo e(__('finance::finance.actions')); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

    <hr>











































<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {"data": "code", orderable: false, searchable: true},
                {"data": "name", orderable: false, searchable: true},
                {"data": "phone", orderable: false, searchable: true},
                {"data": "address", orderable: false, searchable: false},
                {"data": "stockKeeper", orderable: false, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ];
            showDataTable("<?php echo e($dataTableRoute1); ?>", columns, '-stocks', 5);
        });
    </script>















    <script>
        $(document).ready(function () {
            $("input[name='stocks_has_cost_center']").on('change', function () {
                var stocks_has_cost_center = $(this).val();
                var baseUrl = "<?php echo e(route('finance.stocks.index')); ?>";
                var url = baseUrl + "?notification=true&stocks_has_cost_center=" + stocks_has_cost_center;
                $.ajax({
                    url: url,
                    method: "Get",
                    success: function () {
                        $("#dataTableObject-stocks").DataTable().ajax.url(url).load();
                    }
                })
            });
            
            
            
            
            
            
            
            
            
            
            

            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/cost_centers_notifications/index.blade.php ENDPATH**/ ?>