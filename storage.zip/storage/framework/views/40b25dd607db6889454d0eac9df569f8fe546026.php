<script>

    /*$(document).ready(function(){
        $.fn.modal.Constructor.prototype.enforceFocus = function() {};
    });*/
    var loader = `<div class="linear-background">
                            <div class="inter-crop"></div>
                            <div class="inter-right--top"></div>
                            <div class="inter-right--bottom"></div>
                        </div>`;

    function showDataTable(url, columns) {
        //console.log("showDataTable")
        $("#dataTableObject").DataTable({
            // dom: 'Bfrtip',
            responsive: 1,
            // "lengthChange": false,
            "ordering": true,
            "searching": true,
            'iDisplayLength': 10,
            "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
            "processing": true,
            "serverSide": false,
            "sort": true,
            "ajax": url,
            "columns": columns,
            "language": {
                "sProcessing": "<?php echo e(trans('dataTable.sProcessing')); ?>",
                "sLengthMenu": "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                "sZeroRecords": "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                "sInfo": "<?php echo e(trans('dataTable.sInfo')); ?>",
                "sInfoEmpty": "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                "sInfoFiltered": "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                "sInfoPostFix": "",
                "sSearch": "<?php echo e(trans('dataTable.sSearch')); ?>:",
                "sUrl": "",
                "oPaginate": {
                    "sFirst": "<?php echo e(trans('dataTable.sFirst')); ?>",
                    "sPrevious": "<?php echo e(trans('dataTable.sPrevious')); ?>",
                    "sNext": "<?php echo e(trans('dataTable.sNext')); ?>",
                    "sLast": "<?php echo e(trans('dataTable.sLast')); ?>"
                }
            },
            order: [
                [0, "desc"]
            ]
        })
    }

    function handleErrorResponce(errorObj) {
        console.log('handleErrorResponce');
        console.log(errorObj.status);
        if (errorObj.status == 422 || errorObj.status == 400) {
            let errorsObj = $.parseJSON(errorObj.responseText);
            let listObject = errorsObj.data || errorsObj.errors || {};
            let testArr = [];
            $.each(listObject, function (errorKey, errorArr) {
                if (Array.isArray(errorArr)) {
                    $.each(errorArr, function (key, value) {
                        testArr.push(value);
                    });
                } else {
                    testArr.push(errorArr);
                }
            });
            validToster('<?php echo e(__("auth.an error occurred")); ?>', testArr.length > 0 ? testArr : ['حدث خطأ في البيانات المدخلة'])
        } else if (errorObj.status == 500) {
            let message = 'حدث خطأ في الخادم';
            try {
                let errorsObj = $.parseJSON(errorObj.responseText);
                if (errorsObj.message) {
                    message = errorsObj.message;
                }
            } catch(e) {}
            errorToster('<?php echo e(__("auth.an error occurred")); ?>', message);
        } else {
            errorToster('<?php echo e(__("auth.an error occurred")); ?>', "<?php echo e(__("auth.code error")); ?>");
        }
    }

    function handleSuccessResponce(result) {
        //console.log("handleSuccessResponce" + result.code)
        console.log(result)
        if (result.code == 200) {
            successToster('<?php echo e(__("auth.done successfully")); ?>', result.message);
        } else if (result.code == 201) {
            successToster('<?php echo e(__("auth.done successfully")); ?>', result.message);
            // إذا كان هناك URL للتوجيه، استخدمه
            if (result.data && result.data.url) {
                setTimeout(function() {
                    location.href = result.data.url;
                }, 1500);
            } else {
                location.reload();
            }
        } else if (result.code == 401) {
            warningToster('<?php echo e(__("auth.an error occurred")); ?>', result.message)
        } else {
            warningToster('<?php echo e(__("auth.an error occurred")); ?>', result.message)
        }
    }

    function loadOptionsOnAjax() {
        if ($('.select2').length > 0) {
            $('.select2').select2({
                dropdownParent: $('#createModal .modal-body'),
            });
        }
        $.validate({
            ignore: 'input[type=hidden]',
            modules: 'date, security',
            lang: '<?php echo e(\App::currentLocale()); ?>',
            validateOnEvent: true
        });
        if ($('.dropify').length > 0) {
            $('.dropify').dropify();
        }
        if ($('#json_array').length > 0) {
            $('#json_array').multifield();
        }
        if ($('#json_array2').length > 0) {
            $('#json_array2').multifield();
        }
    }

    function reloadDataTable() {
        if ($('#dataTableObject').length > 0) {
            $('#dataTableObject').DataTable().ajax.reload();
        }
    }

    $(document).on('click', '.addButton', function (e) {
        e.preventDefault()
        $('.modal-body').html(loader)
        let buttonObj = $(this);
        let modelRoute = buttonObj.attr("model-route");
        let modelTitle = buttonObj.attr("model-title");
        let modalResult = $("#createModal");
        $(".modal-body", modalResult).html();
        setTimeout(function () {
            $.ajax({
                url: modelRoute,
                type: 'GET',
                beforeSend: function () {
                    // You can add code to handle beforeSend event
                },
                complete: function () {
                    // You can add code to handle complete event
                },
                success: function (result) {
                    $("#exampleModalLgLabel").text(modelTitle);
                    $(".modal-body", modalResult).html(result.data.html);
                    loadOptionsOnAjax();
                },
                error: function (errorObj, errorText, errorThrown) {
                    handleErrorResponce(errorObj);
                }
            });
        }, 500);
    });

    $(document).on('click', '.editButton', function (e) {
        e.preventDefault()
        $('.modal-body').html(loader)
        let buttonObj = $(this);
        let modelRoute = buttonObj.attr("model-route");
        let modelTitle = buttonObj.attr("model-title");
        let modalResult = $("#createModal");
        $(".modal-body", modalResult).html();
        setTimeout(function () {
            $.ajax({
                url: modelRoute,
                type: 'GET',
                beforeSend: function () {
                },
                complete: function () {
                },
                success: function (result) {
                    $("#exampleModalLgLabel").text(modelTitle);
                    $(".modal-body", modalResult).html(result.data.html)
                    loadOptionsOnAjax();
                },
                error: function (errorObj, errorText, errorThrown) {
                    handleErrorResponce(errorObj);
                }
            });
        }, 700);
    });

    $(document).on('click', '.deleteButton', function (e) {
        e.preventDefault()
        let buttonObj = $(this);
        let deleteRoute = buttonObj.attr("delete-route");
        var currentPage = $('#dataTableObject').DataTable().page();
        swal.fire({
            title: "<?php echo e(__('buttons.Are You Sure')); ?>",
            text: "<?php echo e(__('buttons.You Can not to rollback')); ?>",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "<?php echo e(__('buttons.accept')); ?>",
            cancelButtonText: "<?php echo e(__('buttons.cancel')); ?>",
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: deleteRoute,
                    type: 'DELETE',
                    beforeSend: function () {
                        $('#loading-wrapper').fadeIn();
                    },
                    complete: function () {
                        $('#loading-wrapper').fadeOut();
                    },
                    success: function (data) {
                        Swal.fire({
                            icon: 'success',
                            title: "<?php echo e(__('buttons.Deleted successfully')); ?>",
                            confirmButtonText: "<?php echo e(__('buttons.close')); ?>",
                        });
                        reloadDataTable();
                        $('#dataTableObject').DataTable().page(currentPage).draw('page');
                    },
                    error: function (errorObj, errorText, errorThrown) {
                        handleErrorResponce(errorObj);
                    }
                });
            }
        });
    });

    $(document).on('submit', '.from-submit-global', function (e) {
        e.preventDefault();
        let formData = new FormData(this);
        let url = $(this).attr('action');
        let submitButton = $(e.originalEvent.submitter);
        let buttonText = submitButton.text();
        let modalResult = $("#createModal");
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function () {
                $('#loading-wrapper').fadeIn();
                submitButton.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + buttonText)
            },
            complete: function () {
                $('#loading-wrapper').fadeOut();
            },
            success: function (result) {
                console.log(200)
                $('.form-alert').html(result.message);
                handleSuccessResponce(result);
                reloadDataTable();
                submitButton.html(buttonText)
                if (modalResult.is(":visible")) {
                    modalResult.modal('toggle');
                }
                // modalResult.modal('toggle');
                console.log(modalResult.is(':visible'));
            },
            error: function (errorObj, errorText, errorThrown) {
                console.log(500)
                console.log(errorObj)
                handleErrorResponce(errorObj);
            }
        });

    });

    $(document).on('submit', '.from-submit-update-global', function (e) {
        e.preventDefault();
        let formData = new FormData(this);
        let url = $(this).attr('action');
        let submitButton = $(e.originalEvent.submitter);
        let buttonText = submitButton.text();
        let modalResult = $("#createModal");
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function () {
                $('#loading-wrapper').fadeIn();
                submitButton.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + buttonText)
            },
            complete: function () {
                $('#loading-wrapper').fadeOut();
            },
            success: function (result) {
                handleSuccessResponce(result);
                reloadDataTable();
                submitButton.html(buttonText)
                modalResult.modal('toggle');
            },
            error: function (errorObj, errorText, errorThrown) {
                handleErrorResponce(errorObj);
            }
        });

    });


    $(document).on('click', '.remove-tr', function (e) {
        e.preventDefault()
        let obj = $(this)
        let totalTr = $(".remove-tr").length;
        if (totalTr == 1) {
            return false;
        }
        let parentTr = obj.closest("tr");
        parentTr.remove();
    });

</script>


<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/admin/layout/inc/_js_custom.blade.php ENDPATH**/ ?>