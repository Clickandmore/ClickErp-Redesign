<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>"
      enctype="multipart/form-data">



    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__('finance::finance.name')); ?> </label>
        <input type="text" name="name" class="form-control" data-validation="required">
    </div>

    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__('finance::finance.Main Account')); ?></label>
        <select class="form-control  show-tick ms select2" name="parent_id" id="parent_id" data-validation="required">
            <option value=""><?php echo e(trans('finance::finance.Select')); ?> </option>
            <option value="without"><?php echo e(trans('finance::finance.without')); ?></option>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($one->id); ?>" data-status="<?php echo e(@$one->status->value); ?>" <?php echo e(request()->has('parent_id') && request()->parent_id == $one->id ? 'selected' : ''); ?>> <?php echo e($one->name); ?> </option>;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-6">
        <label class="form-label"><?php echo e(__('finance::finance.Nature of account')); ?> </label>
        <select class="form-control" name="status" data-validation="required" id="statusCildSelect">

            <?php echo showSelectElement($accountTypes,"name"); ?>

        </select>
    </div>

    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__('finance::finance.code')); ?> </label>
        <input type="text" name="code"  id="code" value="" class="form-control" data-validation="required"
               readonly="">
    </div>
    <?php if(
        (auth('admin')->user()->admin_type == \App\Enums\AdminTypeisEnum::Developer->value)): ?>

        <div class="col-6">
            <label class="form-label"><?php echo e(__('finance::finance.type')); ?> </label>
            <select class="form-control select2" name="type" id="type">
                <?php echo getEnumData($types); ?>

            </select>
        </div>
        <div class="col-6">
            <label class="form-label"><?php echo e(__('finance::finance.operation_type')); ?> </label>
            <select class="form-control" name="operation_type" id="operation_type">
                <?php echo getEnumData($operationTypes); ?>

            </select>
        </div>
    <?php else: ?>
        <input type="hidden" name="type" value="1" >
        <input type="hidden" name="operation_type" value="3" >
    <?php endif; ?>
    <div class="col-12 modal-footer">
        <?php echo submitButton($storeRoute); ?>

        <?php echo closeButton(); ?>

    </div>

</form>

<script>
    $('#parent_id').on('change', function () {
        let url = '<?php echo e(route("finance.child-code.show",":id")); ?>';
        url = url.replace(':id', $(this).val());
        $.ajax({
            type: "GET",
            url: url,
            data: {
                parent_id: $('#parent_id').val()
            },
            success: function (data) {
                $('#code').val(data);
                let parentStatus = $('#parent_id option:selected').data('status');
                $('#statusCildSelect option').each(function() {
                    // If the option's value matches the parent status
                    if ($(this).val() == parentStatus) {
                        // Select this option
                        $(this).prop('selected', true);
                    }
                });
            }
        });
    });
    <?php if(request()->has('parent_id')): ?>
    $(document).ready(function () {
        let url = '<?php echo e(route("finance.child-code.show",":id")); ?>';
        url = url.replace(':id', '<?php echo e(request()->parent_id); ?>');
        $.ajax({
            type: "GET",
            url: url,
            data: {
                parent_id: '<?php echo e(request()->parent_id); ?>'
            },
            success: function (data) {
                $('#code').val(data);
                let parentStatus = $('#parent_id option:selected').data('status');
                $('#statusCildSelect option').each(function() {
                    // If the option's value matches the parent status
                    if ($(this).val() == parentStatus) {
                        // Select this option
                        $(this).prop('selected', true);
                    }
                });
            }
        });
    });
    <?php endif; ?>
</script>
<?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/account/create.blade.php ENDPATH**/ ?>