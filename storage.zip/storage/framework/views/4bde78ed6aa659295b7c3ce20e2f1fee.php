

<footer class="page-footer px-xl-4 px-sm-2 px-0 py-3">
    <div class="container-fluid d-flex flex-wrap justify-content-center align-items-center">
        <p class=" text-muted d-flex align-items-center gap-1">
            
            <?php echo e($main_setting->copyright_text ?? __('auth.All Rights Reserved.')); ?>

            <a href="<?php echo e($main_setting->copyright_link ?? ''); ?>" target="_blank" title="ROMOZ" class="namiFotter">
                <img src="<?php echo e(showFile($main_setting->footer_logo ?? '')); ?>" width="50px" alt="">
            </a>
            © <?php echo e(date('Y')); ?>

            ❤️
        </p>
    </div>
</footer>
<?php /**PATH /mnt/Data/test/resources/views/nami/layout/inc/footer.blade.php ENDPATH**/ ?>