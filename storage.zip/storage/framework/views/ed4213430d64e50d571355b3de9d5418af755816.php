<?php $__env->startSection("style"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.employeeAttendances')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance.clients")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


















































<div class="row">
    <div class="col-3 my-3">
        <label><?php echo e(__("hr::hr.department")); ?></label>
        <select name="department_id" id="department_id" class="form-control select2">
            <option value=""><?php echo e(__("hr::hr.Select department")); ?></option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-2 my-3">
        <label><?php echo e(__("hr::hr.date")); ?></label>
        <input type="date" id="date" data-validation="required" class="form-control">
    </div>
    <div class="col-2 my-3">
        <label><?php echo e(__("hr::hr.time attendance")); ?></label>
        <input type="time" id="attendance_time" data-validation="required"
               class="form-control">
    </div>
    <div class="col-2 my-3">
        <label><?php echo e(__("hr::hr.Check-out time")); ?></label>
        <input type="time" id="leave_time" data-validation="required"
               class="form-control">
    </div>
</div>



<div class="row">
    <div class="col-12">
        <form class="row g-3 from-submit-global" method="post" action="<?php echo e(route("mluti-employee.store")); ?>"
              enctype="multipart/form-data">
            <table id="myDataTable_no_filter" class="table align-middle card-table">
                <thead>
                <tr>
                    <th><?php echo e(__("hr::hr.Employee")); ?></th>

                    <th>  <?php echo e(__("hr::hr.date")); ?></th>
                    <th>  <?php echo e(__("hr::hr.time attendance")); ?></th>
                    <th>  <?php echo e(__("hr::hr.Check-out time")); ?></th>
                    <th><?php echo e(__("hr::hr.actions")); ?></th>
                </tr>
                </thead>
                <tbody id="json_array1" class="content"
                       data-mfield-options='{"section": ".y-group","btnAdd":"#btnAdd-2","btnRemove":".btnRemove"}'>
                <?php if($employees->count() > 0): ?>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="y-group">
                            <td>
                                <select class="form-control show-tick ms" name="employee_id[]"
                                        data-validation="required">
                                    <option value=""> <?php echo e(__("hr::hr.Choose")); ?> </option>
                                    <?php $__currentLoopData = $allEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allEmployee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($allEmployee->id); ?>" <?php echo e($allEmployee->id == $item->id ? "selected" : ""); ?>><?php echo e($allEmployee->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>




                            <td>
                                <input type="date" name="date[]" data-validation="required" class="form-control">
                            </td>
                            <td>
                                <input type="time" name="attendance_time[]" data-validation="required"
                                       class="form-control">
                            </td>
                            <td>
                                <input type="time" name="leave_time[]" data-validation="required"
                                       class="form-control">
                            </td>
                            <td>
                                <i class="fa fa-plus-circle" id="btnAdd-2"></i>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align: center">
                            لا يوجد بيانات
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>

            <div class="col-12 modal-footer">
                <?php echo submitButton( route("mluti-employee.store") ); ?>


            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $('#json_array1').multifield();


  $(document).ready(function () {
      $('#department_id').on('change', function (event) {
          event.preventDefault();
          var department_id = $('#department_id').val();
          $.ajax({
              url: '<?php echo e(route("mluti-employee.index")); ?>',
              type: 'GET',
              data: {department_id: department_id},
              beforeSend: function () {
                  $('#json_array1').html('');
              },
              success: function (response) {
                  $('#json_array1').html(response.table);
              },
              error: function (xhr, status, error) {
                  alert('حدث خطأ: ' + error);
              }
          });
      });
  });

  $(document).ready(function () {
      $('#date').on('change', function () {
          var newDate = $(this).val();
          $('input[name="date[]"]').val(newDate);
      });

      $('#attendance_time').on('change', function () {
          var newAttendanceTime = $(this).val();
          $('input[name="attendance_time[]"]').val(newAttendanceTime);
      });

      $('#leave_time').on('change', function () {
          var newLeaveTime = $(this).val();
          $('input[name="leave_time[]"]').val(newLeaveTime);
      });
  });
  $.validate({
            ignore: 'input[type=hidden]',
            modules: 'date, security',
            lang: '<?php echo e(\App::currentLocale()); ?>',
            validateOnEvent: true
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employeeAttendances/attendance_multi.blade.php ENDPATH**/ ?>