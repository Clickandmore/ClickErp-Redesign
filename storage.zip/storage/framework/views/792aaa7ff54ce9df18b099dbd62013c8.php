<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/jquerysteps.min.css">
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/css/luno-style.css">
    <style>
        .hide {
            display: none;
        }

        .fs-10 {
            font-size: 9px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.employees')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-12 mt-5">
        <h6 class="card-title"><?php echo e(__("buttons.add button")); ?> <?php echo e(__('hr::hr.employees')); ?></h6>
        <div class="card">
            <form class="card-body step-app h-wizard-demo4 from-submit-global" method="POST"
                  action="<?php echo e(route("employees.store")); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <ul class="step-steps">
                    <li data-step-target="step1"><span
                            class="fa fa-credit-card"></span> <?php echo e(__("hr::hr.basic information")); ?></li>
                    <li data-step-target="step2"><span class="fa fa-credit-card"></span> <?php echo e(__("hr::hr.Functional data")); ?>

                    </li>
                    <li data-step-target="step3"><span class="fa fa-user"></span> <?php echo e(__("hr::hr.Employee papers")); ?></li>
                    <li data-step-target="step4"><span class="fa fa-share-alt"></span> <?php echo e(__("hr::hr.Salary details")); ?>

                    </li>
                </ul>
                <div class="step-content">
                    <div class="step-tab-panel" data-step="step1">
                        <?php echo $__env->make('hr::hr.employees.create.step1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="step-tab-panel" data-step="step2">
                        <?php echo $__env->make('hr::hr.employees.create.step2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="step-tab-panel" data-step="step3">
                        <?php echo $__env->make('hr::hr.employees.create.step3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="step-tab-panel" data-step="step4">
                        <?php echo $__env->make('hr::hr.employees.create.step4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div class="step-footer d-flex">
                    <button class="btn step-btn" data-step-action="prev" id="prev_btn"><?php echo e(__("hr::hr.previous")); ?></button>
                    <button class="btn step-btn" id="nextt" data-step-action="next"
                            disabled><?php echo e(__("hr.next")); ?></button>
                    <button type="submit" class="btn step-btn" id="save-btn"><?php echo e(__("hr::hr.save")); ?></button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('hr::hr.employees.inc._js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function checkOther() {
            var parentPanel = $('.step-tab-panel.active');
            var allFilled = true;
            // Loop through each input, select, and textarea with data-validation="required"
            parentPanel.find('[data-validation*="required"]').each(function () {
                if (!$(this).val()) {
                    allFilled = false;
                } else {
                    $(this).closest('div').find('i.fa-asterisk').remove();
                }
            });
            var currentStep = parentPanel.data('step');
            if (allFilled) {
                $('#nextt').prop('disabled', false);
                $('#save-btn').prop('disabled', false);
            } else {
                $('#save-btn').prop('disabled', true);
                if (currentStep !== 'step4') {
                    $('#nextt').prop('disabled', true);
                }
            }
        }
    </script>
    <script>
        $(document).ready(function () {
            var saveBtn = $('#save-btn');

            $('.step-footer').on('click', '.step-btn', function () {
                var currentStep = $('.step-tab-panel.active').data('step');
                if (currentStep === 'step4') {
                    saveBtn.removeClass('hide');
                    if (!$('#salary').val()) {
                        saveBtn.prop('disabled', true);
                        $('#nextt').prop('disabled', false);
                    }
                } else {
                    saveBtn.addClass('hide');
                }
            });

            $('.step-footer').on('click', '#nextt', function () {
                var currentStep = $('.step-tab-panel.active').data('step');
                if (currentStep !== 'step4') {
                    var parentPanel = $('.step-tab-panel.active');

                    var allFilled = true;
                    // Loop through each input, select, and textarea with data-validation="required"
                    parentPanel.find('[data-validation*="required"]').each(function () {
                        if (!$(this).val()) {
                            allFilled = false;
                        }
                    });
                    if (allFilled) {
                        $('#nextt').prop('disabled', false);
                    } else {
                        $('#nextt').prop('disabled', true);
                    }
                } else {
                    $('#nextt').prop('disabled', false);
                }
            });

            $('.step-content').on('show.bs.tab', function (e) {
                var targetStep = $(e.target).data('step');
                console.log('Target step:', targetStep);
                if (targetStep === 'step4') {
                    saveBtn.removeClass('hide');
                } else {
                    saveBtn.addClass('hide');
                }
            });

            $('#prev_btn').on('click', function () {
                $('#nextt').prop('disabled', false);
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employees/create.blade.php ENDPATH**/ ?>