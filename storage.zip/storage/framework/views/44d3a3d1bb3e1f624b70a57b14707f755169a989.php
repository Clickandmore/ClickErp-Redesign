<?php if($data->count() > 0): ?>
    <?php
        $colspan = ($show_other_account == "yes") ? 6 : 5;
        $width   = ($show_other_account == "yes") ? 35 : 25;
    ?>
    <table class="table table-hover table-bordered table-striped" id="simpleTable4" style="width:100%">
        <thead>
        <tr class="header">
            <th style="width: 5%" scope="col">#</th>
            <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.Transaction Date")); ?></th>
            <th style="width: 5%" scope="col"><?php echo e(__("finance::finance.Transaction Number")); ?></th>
            <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.Transaction Type")); ?></th>
            <?php if($show_other_account == "yes"): ?>
                <th style="width: 10%" scope="col"><?php echo e(__('finance::finance.Counter Account')); ?></th>
            <?php endif; ?>
            <th style="width: <?php echo e($width); ?>%" scope="col"><?php echo e(__('finance::finance.statement')); ?></th>
            <th style="width: 5%" scope="col" class="currency-egp"><?php echo e(__("finance::finance.debtor")); ?></th>
            <th style="width: 5%" scope="col" class="currency-egp"><?php echo e(__("finance::finance.creditor")); ?></th>
            <th style="width: 5%" scope="col" class="currency-egp"><?php echo e(__('finance::finance.Balance')); ?></th>
            <th style="width: 5%" scope="col"><?php echo e(__('finance::finance.user')); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php
            $balance = 0;
            $sumCreditorValue = $sumDebtorValue = 0;
        ?>
        <!--------------------- $firstBalance ------------------------------------------>
        <?php if(isset($firstBalance->sum_debtor_value)): ?>
            <?php
                $balance += ($firstBalance->status == "debtor")? ($firstBalance->sum_debtor_value - $firstBalance->sum_creditor_value):($firstBalance->sum_creditor_value - $firstBalance->sum_debtor_value);
                $sumDebtorValue += $firstBalance->sum_debtor_value ;
                $sumCreditorValue += $firstBalance->sum_creditor_value ;
            // $trClass = ( $firstBalance->sum_debtor_value  == 0  &&  $firstBalance->sum_creditor_value == 0 )? "currency-usd":"currency-egp";
            ?>
        <tr style="background-color: papayawhip;">
            <td colspan="<?php echo e($colspan); ?>" class="text-center">رصيد اول مدة </td>
            <td class="currency-egp"><?php echo e($firstBalance->sum_debtor_value); ?></td>
            <td class="currency-egp"><?php echo e($firstBalance->sum_creditor_value); ?></td>
            <td class="currency-egp"><?php echo e(($balance)); ?></td>
            <td></td>
        </tr>
        <?php endif; ?>
        <!--------------------- $firstBalance ------------------------------------------>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                  //$balance += ($row->status == "debtor") ? (double)($row->debtor_value - $row->creditor_value) : (double)($row->creditor_value - $row->debtor_value);
                  $rowDebtor_value = round($row->debtor_value,2) ;
                  $rowCreditor_value = round($row->creditor_value,2) ;

                  $rowBalance = ($row->status == "debtor") ? ($rowDebtor_value - $rowCreditor_value) : ($rowCreditor_value - $rowDebtor_value);

                  /***********************************************/
                    $rowBalance = round($rowBalance, 2);
                    if (abs($rowBalance) < 0.01) {
                        $rowBalance = 0;
                    }

                    $balance += $rowBalance;

                    // Also clean the cumulative balance
                    $balance = round($balance, 2);
                    if (abs($balance) < 0.01) {
                        $balance = 0;
                    }
                   /***********************************************/
                  $sumDebtorValue += $row->debtor_value;
                  $sumCreditorValue += $row->creditor_value;
                  $trClass = ($row->debtor_value == 0 && $row->creditor_value == 0) ? "currency-usd" : "currency-egp";
            ?>
            <tr class="<?php echo e($trClass); ?>">
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($row->date); ?></td>
                <td><?php echo e($row->constraint_id); ?></td>
                <td><?php echo e(getEnumValue('constraint_types', $row->constraints_type)); ?></td>
                <?php if($show_other_account == "yes"): ?>
                    <td>
                        <?php $__currentLoopData = $otherAccount[$row->constraint_id]["accounts"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><?php echo e($oneAccount->name); ?></span><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                <?php endif; ?>
                <td><?php echo e($row->statement); ?></td>
                <td class="currency-egp"><?php echo e($row->debtor_value); ?></td>
                <td class="currency-egp"><?php echo e($row->creditor_value); ?></td>
                <td class="currency-egp">  <?php echo e($balance); ?>  </td>
                <td><?php echo e($row->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="<?php echo e($colspan); ?>" class="text-center"><?php echo e(__('finance::finance.Balance')); ?></td>
            <td class="currency-egp"><?php echo e($sumDebtorValue); ?></td>
            <td class="currency-egp"><?php echo e($sumCreditorValue); ?></td>
            <td class="currency-egp" style="background-color: yellow"><?php echo e($balance); ?></td>
            <td></td>
        </tr>
        </tbody>
    </table>
<?php else: ?>


<?php endif; ?>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/account_statement/result.blade.php ENDPATH**/ ?>