<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>"
    enctype="multipart/form-data">

    <div class="col-3">
        <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.date")); ?> </label>
        <input type="date" name="date" class="form-control" value="<?php echo e(date("Y-m-d")); ?>" data-validation="required">
    </div>

    <div class="col-3">
        <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.From Account")); ?> : </label>
        <label for="TextInput" class="form-label"> <?php echo e(__('finance::finance.Directory account')); ?>

            <?php echo addUpButton(route('finance.accounts.create'),'credit_account_id' ,false, 'name'); ?></label>
        <select class="form-control show-tick ms select2" id="credit_account_id" name="credit_account_id" data-validation="required" onchange="updateOptions('#credit_account_id', '#debit_account_id')">
            <?php echo showSelectElement($accounts, 'name'); ?>

        </select>
    </div>
    <div class="col-3">
        <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.To Account")); ?> : </label>
        <label for="TextInput" class="form-label"> <?php echo e(__('finance::finance.Directory account')); ?>

            <?php echo addUpButton(route('finance.accounts.create'),'debit_account_id' ,false, 'name'); ?></label>
        <select class="form-control show-tick ms select2" id="debit_account_id" name="debit_account_id" data-validation="required" onchange="updateOptions('#debit_account_id', '#credit_account_id')">
            <?php echo showSelectElement($accounts, 'name'); ?>

        </select>
    </div>
    <div class="col-3">
        <label for="TextInput" class="form-label"><?php echo e(__("finance::finance.fn-cost-centers")); ?> : </label>
        <label for="TextInput" class="form-label">
            <?php echo addUpButton(route('finance.cost-centers.create'),'cost_center_id' ,false, 'title'); ?></label>
        <select class="form-control show-tick ms select2" name="cost_center_id" id="cost_center_id">
            <?php echo showSelectElement($costCenters, "title"); ?>

        </select>
    </div>
    <div class="col-3">
        <label for="TextInput" class="form-label"><?php echo e(__("finance::finance.value")); ?> </label>
        <input type="number" min="0.01" step="any" name="value" value="1" class="form-control" data-validation="required,min_value">
    </div>

    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__("finance::finance.statement")); ?> </label>
        <textarea type="text" name="statement" class="form-control form-control-lg mb-1" id="bs_maxlength_textarea"
                  rows="5"></textarea>
    </div>


    <h4><?php echo e(__('finance::finance.attachments')); ?></h4>
    <div class="col-12">
        <div class="work_samples_grid">
            <label class="img_upload">
                <input type="file" accept="image/*" multiple name="file[]"
                       id="img-upload" onchange="handleFileSelect(event)">
                <div class="img justify-content-center">
                    <img loading="lazy"
                         src="<?php echo e(asset('admin')); ?>/assets/img/plus.svg"
                         alt="plus"
                         style="width: 50px; height: 50px;">
                </div>
            </label>
        </div>
    </div>


    <div class="col-12 modal-footer">
        <?php echo submitButton($storeRoute); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/account_transfer/create.blade.php ENDPATH**/ ?>