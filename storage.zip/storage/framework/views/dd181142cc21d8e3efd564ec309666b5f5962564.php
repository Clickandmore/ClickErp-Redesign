
<script>
    $(document).ajaxComplete(function(){
        $('#payment_method').change(function(){
            var selectedValue = $(this).val();
            if(selectedValue === "monthly_installment"){
                $('#field').show();
                $('#table').hide();
            } else if(selectedValue === "debt_payments"){
                $('#field').hide();
                $('#table').show();
            } else {
                $('#field').hide();
                $('#table').hide();
            }
        });
        var selectedValue = $('#payment_method').val();
        if(selectedValue === "monthly_installment"){
            $('#field').show();
            $('#table').hide();
        } else if(selectedValue === "debt_payments"){
            $('#field').hide();
            $('#table').show();
        } else {
            $('#field').hide();
            $('#table').hide();
        }
    });
</script>

<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employees/advances/_js_allowance.blade.php ENDPATH**/ ?>