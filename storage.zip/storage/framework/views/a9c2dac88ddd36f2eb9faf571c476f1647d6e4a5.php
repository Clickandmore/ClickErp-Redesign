<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>" enctype="multipart/form-data">
    <?php if(!$checkYear): ?>
        <?php if(url()->previous() != $storeRoute): ?>
        <h5 style="color:red;"><?php echo e(trans('finance::finance.the year is not active')); ?></h5>
        <?php endif; ?>
        <input type="hidden" name="status" value="1">
    <?php endif; ?>
    <div class="col-12">
        <label for="title" class="form-label"><?php echo e(__('finance::finance.title')); ?> </label>
        <input type="text" name="title" id="title" class="form-control" data-validation="required">
    </div>

    <div class="col-12">
        <label for="from_date" class="form-label"><?php echo e(__('finance::finance.from_date')); ?></label>
        <input type="date" name="from_date" id="from_date" class="form-control" data-validation="required">
    </div>

    <div class="col-12">
        <label for="to_date" class="form-label"><?php echo e(__('finance::finance.to_date')); ?></label>
        <input type="date" name="to_date" id="to_date" class="form-control" data-validation="required">
    </div>

    <div class="col-12 modal-footer">
         <?php echo submitButton( $storeRoute ); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/years/create.blade.php ENDPATH**/ ?>