<!-- Favicon and Apple Touch Icon -->
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('site')); ?>/assets/images/fav.svg"/>
<link rel="icon" type="image/svg+xml" href="<?php echo e(asset('site')); ?>/assets/images/fav.svg"/>

<!-- Stylesheets -->
<!-- Swiper -->
<link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/swiper-bundle.min.css"/>
<link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/animate.min.css"/>
<?php if(app()->getLocale() == 'ar'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/bootstrap.rtl.min.css"/>
<?php else: ?>
    <link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/bootstrap.min.css"/>
<?php endif; ?>
<link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/main.css"/>
<link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/style.css?v=-<?php echo e(time()); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/bs-stepper.css?v=-<?php echo e(time()); ?>"/>

<link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/vendor/toster/css/jquery.toast.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<link rel="stylesheet" href="<?php echo e(asset('site')); ?>/assets/css/back_style.css?v=-<?php echo e(time()); ?>"/>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/site/includes/css.blade.php ENDPATH**/ ?>