<div class="row mx-2">
    <div class="col-12">
        <ul class="nav nav-tabs tab-card mb-4 border-top-0 border-start-0 border-end-0 border border-primary rounded-4 bg-white" role="tablist">


                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'departments.index' ? 'active' : ''); ?>" href="<?php echo e(route('departments.index')); ?>">
                            <?php echo e(__('hr.departments')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'jobs.index' ? 'active' : ''); ?>" href="<?php echo e(route('jobs.index')); ?>">
                            <?php echo e(__('hr.jobs')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'allowances.index' ? 'active' : ''); ?>" href="<?php echo e(route('allowances.index')); ?>">
                            <?php echo e(__('hr.allowances')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'sanctions.index' ? 'active' : ''); ?>" href="<?php echo e(route('sanctions.index')); ?>">
                            <?php echo e(__('hr.sanctions')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'vacation-year.index' ? 'active' : ''); ?>" href="<?php echo e(route('vacation-year.index')); ?>">
                            <?php echo e(__('hr.year_id_vacation')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'vacations.index' ? 'active' : ''); ?>" href="<?php echo e(route('vacations.index')); ?>">
                            <?php echo e(__('hr.vacations')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'permissionsSettings.index' ? 'active' : ''); ?>" href="<?php echo e(route('permissionsSettings.index')); ?>">
                            <?php echo e(__('hr.permissionsSettings')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'permissions.index' ? 'active' : ''); ?>" href="<?php echo e(route('permissions.index')); ?>">
                            <?php echo e(__('hr.permissions')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'insurances.index' ? 'active' : ''); ?>" href="<?php echo e(route('insurances.index')); ?>">
                            <?php echo e(__('hr.insurances')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'tax.index' ? 'active' : ''); ?>" href="<?php echo e(route('tax.index')); ?>">
                            <?php echo e(__('hr.tax')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'rewards.index' ? 'active' : ''); ?>" href="<?php echo e(route('rewards.index')); ?>">
                            <?php echo e(__('hr.rewards')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'shifts.index' ? 'active' : ''); ?>" href="<?php echo e(route('shifts.index')); ?>">
                            <?php echo e(__('hr.shifts')); ?>

                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="py-3 mx-1 nav-link <?php echo e(Route::currentRouteName() == 'officialVacations.index' ? 'active' : ''); ?>" href="<?php echo e(route('officialVacations.index')); ?>">
                            <?php echo e(__('hr.officialVacations')); ?>

                        </a>
                    </li>


        </ul>
    </div>
</div>


<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/_nav_tabs.blade.php ENDPATH**/ ?>