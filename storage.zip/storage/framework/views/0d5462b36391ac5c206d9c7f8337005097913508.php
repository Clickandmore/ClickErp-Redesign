<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="keyword" content="">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="icon" href="<?php echo e(asset('admin')); ?>/assets/img/favicon.ico" type="image/x-icon">
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/admin/layout/inc/_meta.blade.php ENDPATH**/ ?>