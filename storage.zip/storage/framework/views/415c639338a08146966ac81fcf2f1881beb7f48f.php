<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>" enctype="multipart/form-data">
    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__('finance::finance.name')); ?> </label>
        <input type="text" name="name" class="form-control" data-validation="required">
    </div>

    <div class="col-6">
        <label class="form-label"><?php echo e(__('finance::finance.account')); ?></label>
        <select name="account_id[]" class="form-control select2" data-validation="required" multiple>
            <?php echo showSelectElement($accounts ,'name'); ?>

        </select>
    </div>

    <div class="col-12 modal-footer">
         <?php echo submitButton(  $storeRoute  ); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/double_accounts/create.blade.php ENDPATH**/ ?>