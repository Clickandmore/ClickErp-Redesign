<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/cssbundle/dataTables.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/cssbundle/dropify.min.css">

    <style>
        .custom-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .custom-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
        }

        input:checked + .slider {
            background-color: #2196F3;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
            transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
            border-radius: 34px;
        }

        .slider.round:before {
            border-radius: 50%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-static'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-check form-switch">
        <label class="form-check-label" id="switchFilterLabel"
               for="switchFilter"><?php echo e(__('finance::finance.advanced_search')); ?></label>
        <input class="form-check-input" type="checkbox" role="switch" id="switchFilter">
    </div>
    <div class="row mb-3 filter_data" style="display: none">
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.from_date")); ?></label>
                <input class="form-control" name="from_date" id="from_date" type="date">
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.to_date")); ?></label>
                <input class="form-control" name="to_date" id="to_date" type="date">
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.cost_center")); ?></label>
                <select name="cost_center_id" id="cost_center_id" class="form-control select2">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $cost_centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost_center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cost_center->id); ?>"><?php echo e($cost_center->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.Payee")); ?></label>
                <select name="debit_account_id" id="debit_account_id" class="form-control select2">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.Cash/Drawer/Bank")); ?></label>
                <select name="credit_account_id" id="credit_account_id" class="form-control select2">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $banks_boxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banks_box): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($banks_box->id); ?>"><?php echo e($banks_box->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.payment_type")); ?></label>
                <select name="payment_type" id="payment_type_filter" class="form-control select2">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                                value="<?php echo e($payment_type->value); ?>"><?php echo e(\Nami\Finance\Enums\BondPaymentTypes::tryFrom($payment_type->value)->lang()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>

    <?php echo addButton($createRoute, $addButtonText); ?>

    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th><?php echo e(__("finance::finance.Voucher Number")); ?></th>
            <th><?php echo e(__("finance::finance.Voucher Date")); ?></th>
            <th><?php echo e(__("finance::finance.Payee")); ?></th>
            <th><?php echo e(__("finance::finance.Cash/Drawer/Bank")); ?></th>
            <th><?php echo e(__("finance::finance.Amount")); ?></th>
            <th><?php echo e(__("finance::finance.Payment Method")); ?></th>
            <th><?php echo e(__('finance::finance.actions')); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('admin')); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/assets/js/bundle/dropify.bundle.js"></script>

    <script>
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    </script>
    <script>
        $(document).ready(function () {
            let table = $("#dataTableObject").DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                ordering: true,
                searching: true,
                iDisplayLength: 10,
                lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
                ajax: {
                    url: "<?php echo e($dataTableRoute); ?>",
                    data: function (response) {
                        response.from_date = $('#from_date').val();
                        response.to_date = $('#to_date').val();
                        response.cost_center_id = $('#cost_center_id').val();
                        response.debit_account_id = $('#debit_account_id').val();
                        response.credit_account_id = $('#credit_account_id').val();
                        response.payment_type = $('#payment_type').val();
                    }
                },
                columns: [
                    {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                    {"data": "bond_num", orderable: false, searchable: true},
                    {"data": "date", orderable: false, searchable: true},
                    {"data": "account_text", orderable: false, searchable: true},
                    {"data": "credit_account", orderable: false, searchable: true},
                    {"data": "value", orderable: false, searchable: true},
                    {"data": "payment_type_name", orderable: false, searchable: true},
                    {"data": "actions", orderable: false, searchable: false}
                ],
                language: {
                    sProcessing: "<?php echo e(trans('dataTable.sProcessing')); ?>",
                    sLengthMenu: "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                    sZeroRecords: "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                    sInfo: "<?php echo e(trans('dataTable.sInfo')); ?>",
                    sInfoEmpty: "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                    sInfoFiltered: "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                    sSearch: "<?php echo e(trans('dataTable.sSearch')); ?>:",
                    oPaginate: {
                        sFirst: "<?php echo e(trans('dataTable.sFirst')); ?>",
                        sPrevious: "<?php echo e(trans('dataTable.sPrevious')); ?>",
                        sNext: "<?php echo e(trans('dataTable.sNext')); ?>",
                        sLast: "<?php echo e(trans('dataTable.sLast')); ?>"
                    }
                },
                order: [[2, "desc"]]
            });
            $('#from_date, #to_date , #cost_center_id,#debit_account_id,#credit_account_id,#payment_type').change(function () {
                table.ajax.reload();
            });
        })
    </script>
    <?php echo $__env->make("finance::finance.general_bond._js_bond", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/general_bond/sarf/index.blade.php ENDPATH**/ ?>