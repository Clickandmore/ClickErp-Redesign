<?php $__env->startSection('title'); ?>
    <?php echo e(__("ingaz.home")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- main slider -->
    <section class="mainSlider">
        <div class="swiper">
            <div class="swiper-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="swiper-slide" style="background-image: url(<?php echo e(showFile($slider->image)); ?>)">
                        <div class="info">
                            <h4 class="hint">
                                <?php echo e($slider->title); ?>

                            </h4>
                            <h1 class="sliderTitle">
                                <?php echo e($slider->description); ?>

                            </h1>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- swiper-slide -->
                    <div class="swiper-slide" style="background-image: url(<?php echo e(asset('site')); ?>/assets/images/s1.webp)">

                        <div class="info">
                            <h4 class="hint">
                                بلاتينيوم الشرقية للاستقدام
                            </h4>
                            <h1 class="sliderTitle">
                                أكثر من 20 سنة من تقديم خدمات الاستقدام باحترافية عالية
                            </h1>
                        </div>
                    </div>
                    <!-- swiper-slide -->
                    <div class="swiper-slide" style="background-image: url(<?php echo e(asset('site')); ?>/assets/images/s2.webp)">
                        <div class="info">
                            <h4 class="hint"> سهولة الاستخدام</h4>
                            <h1 class="sliderTitle">
                                ابدأ حجزك واتمم دفعك من خلال الموقع الالكتروني او التواصل معنا
                                بوقت وجيز وبخطوات مختصرة
                            </h1>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- services -->
    <section class="hero-services" data-aos="fade-up">
        <!-- <div class="expertise">
            <?php echo e(__('ingaz.experience more than')); ?>

            <span> <?php echo e(isset($settings->years) ? $settings->years : ''); ?> <small> <?php echo e(__('ingaz.years')); ?> </small> </span>
        </div> -->
          <div class="expertise">
          <img src="<?php echo e(asset('site')); ?>/assets/images/experience.jpg"
          alt="" />

        </div>
        <a href="<?php echo e(route('site.all-workers.index')); ?>?type=estqdam" class="service">
            <div class="icon">
                <i class="fa-duotone fa-user-plus fa-2x mb-2"></i>
            </div>
            <div class="text">
                <h4 class="title"><?php echo e(__('ingaz.recruitment_request_title')); ?></h4>
                <p class="description"><?php echo e(__('ingaz.recruitment_request_text')); ?></p>
            </div>
        </a>
        <a href="<?php echo e(route('site.all-workers.index')); ?>?type=transfer" class="service">
            <div class="icon">
                <i class="fa-duotone fa-business-time"></i>
            </div>
            <div class="text">
                <h4 class="title"><?php echo e(__('ingaz.monthly_rental')); ?></h4>
                <p class="description"><?php echo e(__('ingaz.Labor_transfer_text')); ?></p>
            </div>
        </a>
        <a href="<?php echo e(route('site.all-workers.index')); ?>?type=egar" class="service">
            <div class="icon">
                <i class="fa-duotone fa-people-arrows fa-2x mb-2"></i>
            </div>
            <div class="text">
                  <h4 class="title"><?php echo e(__('ingaz.transfer_services')); ?></h4>
        <p class="description"><?php echo e(__('ingaz.transfer_service_text')); ?></p>
            </div>
        </a>

        <div class="warning">
            <?php echo e(__('ingaz.warning')); ?> :
            <?php if(isset($settings)): ?>
                <?php echo e(app()->getLocale() == 'ar' ? $settings->note_ar : $settings->note_en); ?>

            <?php else: ?>
                <?php echo e(__('ingaz.warning_text')); ?>

            <?php endif; ?>
        </div>
    </section>
    <!-- about sec  -->
<section class="about-section" id="about">
  <div class="container">
    <!-- About Content -->
    <div class="about-content">
      <div class="about-text">
        <h2>
              <?php echo e(__('ingaz.about-us')); ?>

        </h2>
        <p>
              <?php echo e(__('ingaz.about_description')); ?>

        </p>
      </div>

      <div class="about-image">
        <img src="<?php echo e(asset('site/assets/images/about.webp')); ?>" alt="<?php echo e(__('ingaz.about_us')); ?>" />
      </div>
    </div>
    <!-- About Cards -->
    <div class="about-cards">
      <?php $__empty_1 = true; $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="service">
          <i class="<?php echo e($feature->image); ?>"></i>
          <div>
            <h4><?php echo e($feature->title); ?></h4>
            <p><?php echo e($feature->description ?? ''); ?></p>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="service">
          <i class="fa-solid fa-headset"></i>
          <div>
            <h4><?php echo e(__('ingaz.customer_service_title')); ?></h4>
            <p><?php echo e(__('ingaz.customer_service_text')); ?></p>
          </div>
        </div>

        <div class="service">
          <i class="fa-solid fa-id-card"></i>
          <div>
            <h4><?php echo e(__('ingaz.hr_license_title')); ?></h4>
            <p><?php echo e(__('ingaz.hr_license_text')); ?></p>
          </div>
        </div>

        <div class="service">
          <i class="fa-solid fa-shield-check"></i>
          <div>
            <h4><?php echo e(__('ingaz.musaned_title')); ?></h4>
            <p><?php echo e(__('ingaz.musaned_text')); ?></p>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

    <!-- ============= countries =============  -->
<section class="countries" data-aos="fade-up">
    <div class="container">
        <!-- Section Title -->
        <div class="headTitle text-start" data-aos="fade-up" data-aos-delay="100">
            <h2><?php echo e(__('ingaz.Recruitment countries')); ?></h2>
            <p><?php echo e(__('ingaz.countries_desc')); ?></p>
        </div>

        <div class="allCountries">
            <div class="row justify-content-center">

                <?php $__empty_1 = true; $__currentLoopData = $nationalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in" data-aos-delay="100">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(showfile($nationality->logo)); ?>" alt="<?php echo e($nationality->title); ?>" width="100px">
                            </div>

                            <div class="country-content">
                                <h3><?php echo e($nationality->title); ?></h3>

                                <ul class="country-costs">
                                    <?php if($nationality->price): ?>
                                        <li>
                                            <span><?php echo e(__('ingaz.recruitment_cost')); ?></span>
                                            <strong><?php echo e(number_format($nationality->price, 0)); ?> <?php echo e(__('ingaz.currency_sar')); ?></strong>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($nationality->rental_cost): ?>
                                        <li>
                                            <span><?php echo e(__('ingaz.rental_cost')); ?></span>
                                            <strong><?php echo e(number_format($nationality->rental_cost, 0)); ?> <?php echo e(__('ingaz.currency_sar')); ?></strong>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($nationality->service_transportation_cost): ?>
                                        <li>
                                            <span><?php echo e(__('ingaz.service_transportation_cost')); ?></span>
                                            <strong><?php echo e(number_format($nationality->service_transportation_cost, 0)); ?> <?php echo e(__('ingaz.currency_sar')); ?></strong>
                                        </li>
                                    <?php endif; ?>

                                    <?php if($nationality->monthly_salary): ?>
                                        <li>
                                            <span><?php echo e(__('ingaz.monthly_salary')); ?></span>
                                            <strong><?php echo e(number_format($nationality->monthly_salary, 0)); ?> <?php echo e(__('ingaz.currency_sar')); ?></strong>
                                        </li>
                                    <?php endif; ?>
                                </ul>

                                <?php if($nationality->description): ?>
                                    <div class="country-description center">
                                        <?php echo $nationality->description; ?>

                                    </div>
                                <?php endif; ?>

                                <a href="<?php echo e(route('site.all-workers.index')); ?>?nationality_id=<?php echo e($nationality->id); ?>" class="animatedLink">
                                    <?php echo e(__('ingaz.request now')); ?>

                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- Default Countries Section -->
                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(asset('site/assets/images/countries/1.png')); ?>" alt="">
                            </div>
                            <div class="country-content">
                                <h3>أوغندا</h3>
                                <span class="country-subtitle">مدة الاستقدام خلال 60 يوم</span>
                                <div class="country-description">
                                    <p>خدمات استقدام متكاملة من أوغندا مع متابعة شاملة لكافة إجراءات العمل.</p>
                                </div>
                                <ul class="country-costs">
                                    <li><span><?php echo e(__('ingaz.recruitment_cost')); ?></span><strong>8,500 <?php echo e(__('ingaz.currency_sar')); ?></strong></li>
                                    <li><span><?php echo e(__('ingaz.rental_cost')); ?></span><strong>2,000 <?php echo e(__('ingaz.currency_sar')); ?></strong></li>

                                </ul>
                                <a href="#" class="animatedLink">
                                   تصفح السير الذاتية
                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(asset('site/assets/images/countries/2.png')); ?>" alt="">
                            </div>
                            <div class="country-content">
                                <h3>كينيا</h3>
                                <span class="country-subtitle">مدة الاستقدام خلال 60 يوم</span>
                                <a href="#" class="animatedLink">
                                   تصفح السير الذاتية
                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(asset('site/assets/images/countries/3.jpeg')); ?>" alt="">
                            </div>
                            <div class="country-content">
                                <h3>بنغلادش</h3>
                                <span class="country-subtitle">مدة الاستقدام خلال 60 يوم</span>
                                <a href="#" class="animatedLink">
                                   تصفح السير الذاتية
                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(asset('site/assets/images/countries/4.jpeg')); ?>" alt="">
                            </div>
                            <div class="country-content">
                                <h3>الفلبين</h3>
                                <span class="country-subtitle">مدة الاستقدام خلال 60 يوم</span>
                                <a href="#" class="animatedLink">
                                   تصفح السير الذاتية
                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(asset('site/assets/images/countries/5.png')); ?>" alt="">
                            </div>
                            <div class="country-content">
                                <h3>الهند</h3>
                                <span class="country-subtitle">مدة الاستقدام خلال 60 يوم</span>
                                <a href="#" class="animatedLink">
                                   تصفح السير الذاتية
                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(asset('site/assets/images/countries/6.png')); ?>" alt="">
                            </div>
                            <div class="country-content">
                                <h3>موريتانيا</h3>
                                <span class="country-subtitle">مدة الاستقدام خلال 60 يوم</span>
                                <a href="#" class="animatedLink">
                                   تصفح السير الذاتية
                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3 p-2" data-aos="zoom-in">
                        <div class="country-card">
                            <div class="flag-container">
                                <img src="<?php echo e(asset('site/assets/images/countries/7.png')); ?>" alt="">
                            </div>
                            <div class="country-content">
                                <h3>جيبوتي</h3>
                                <span class="country-subtitle">مدة الاستقدام خلال 60 يوم</span>
                                <a href="#" class="animatedLink">
                                   تصفح السير الذاتية
                                    <i class="fa-regular fa-left-long ms-2"><span></span></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>


   <!-- ================ services ================= -->
    <section class="services-sec" id="services">
        <div class="container">
          <div class="headTitle" data-aos="fade-up">
            <h2><?php echo e(__('ingaz.our_services')); ?></h2>
            <p><?php echo e(__('ingaz.our_services_desc')); ?></p>
        </div>

        <!-- السلايدر -->
        <div class="services-slider swiper" data-aos="fade-up">
            <div class="swiper-wrapper">
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="swiper-slide">
                        <a href="#"

                         class="service d-flex flex-column justify-content-center"
                           style="background: url('<?php echo e(showFile($service->image)); ?>') no-repeat center/cover;">
                            <i class="fa-solid fa-passport"></i>
                            <h3 class="serviceTitle"><?php echo e($service->title); ?></h3>
                            <h6 class="serviceP">
                                <?php echo e(Str::limit($service->description, 100)); ?>

                            </h6>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="swiper-slide">
                        <a href="#"
                           class="service d-flex flex-column justify-content-center"
                           style="background: url('<?php echo e(asset('site/assets/images/passport-bg.webp')); ?>') no-repeat center/cover;">
                            <i class="fa-solid fa-passport"></i>
                            <h3 class="serviceTitle">إصدار التأشيرة</h3>
                            <h6 class="serviceP">
                                طلب اصدار تاشيرة العمالة المنزلية الخاصة بك في برنامج مساند
                            </h6>
                        </a>
                    </div>

                    <div class="swiper-slide">
                        <a href="#"
                           class="service d-flex flex-column justify-content-center"
                           style="background: url('<?php echo e(asset('site/assets/images/files.webp')); ?>') no-repeat center/cover;">
                            <i class="fa-solid fa-users-gear"></i>
                            <h3 class="serviceTitle">اختيار العمالة</h3>
                            <h6 class="serviceP">
                                اختيار السيره الذاتيه للعماله المنزليه عبر البحث في برنامج مساند
                            </h6>
                        </a>
                    </div>

                    <div class="swiper-slide">
                        <a href="#"
                           class="service d-flex flex-column justify-content-center"
                           style="background: url('<?php echo e(asset('site/assets/images/bg-plane.webp')); ?>') no-repeat center/cover;">
                            <i class="fa-solid fa-plane-arrival"></i>
                            <h3 class="serviceTitle">وصول العمالة</h3>
                            <h6 class="serviceP">
                                وصول العمالة المنزلية من المطار المحلي الى المكتب
                            </h6>
                        </a>
                    </div>

                    <div class="swiper-slide">
                        <a href="#"
                           class="service d-flex flex-column justify-content-center"
                           style="background: url('<?php echo e(asset('site/assets/images/hands.webp')); ?>') no-repeat center/cover;">
                            <i class="fa-solid fa-file-contract"></i>
                            <h3 class="serviceTitle">تجديد عقد عاملة</h3>
                            <h6 class="serviceP">
                                خدمة تجديد عقد العاملة المنزلية بشكل إلكتروني عبر منصة مساند
                            </h6>
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!--  nav btns -->
            <div class="swiper-button-next custom-swiper-btn"></div>
            <div class="swiper-button-prev custom-swiper-btn"></div>
        </div>

        <!--  last card  -->
        <div class="wide-card mt-4" data-aos="fade-up">
            <a href="#"
               class="service d-flex flex-column justify-content-center"
               style="background: url('<?php echo e(asset('site/assets/images/f3.webp')); ?>') no-repeat center/cover;">
                <i class="fa-solid fa-users-gear"></i>
                <h3 class="serviceTitle">طلب العمالة المهنية</h3>
                <h6 class="serviceP">
                    نحن قادرون على جلب أفضل أنواع العمالة المهنية من مختلف التخصصات
                    لتلبية احتياجاتك بأعلى جودة وكفاءة
                </h6>
            </a>
        </div>
    </div>
</section>

    <!-- statistics sec  -->
   <section class="statistics" id="statistics">
    <div class="container">
        <div class="section-header" data-aos="fade-up" data-aos-duration="1000">
            <h1 class="title"><?php echo e(__('ingaz.Statistics')); ?></h1>
            <h6 class="hint"><?php echo e(__('ingaz.Statistics_text')); ?></h6>
        </div>

        
        <div class="stats-container">
            <?php $__empty_1 = true; $__currentLoopData = $statics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $static): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="stat-card" data-aos="zoom-in" data-aos-delay="100">
                    <div class="icon-wrapper">
                        <i class="fa-solid fa-<?php echo e($static->image); ?>"></i>
                    </div>
                    <span class="counter" data-target="<?php echo e($static->counter_num); ?>">0</span>
                    <h6><?php echo e($static->title); ?></h6>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="stat-card" data-aos="zoom-in" data-aos-delay="100">
                    <div class="icon-wrapper">
                        <i class="fa-solid fa-users"></i>
                    </div>
                    <span class="counter" data-target="794">0</span>
                    <h6>عملاؤنا</h6>
                </div>

                <div class="stat-card" data-aos="zoom-in" data-aos-delay="200">
                    <div class="icon-wrapper">
                        <i class="fa-solid fa-building"></i>
                    </div>
                    <span class="counter" data-target="812">0</span>
                    <h6>زوارنا</h6>
                </div>

                <div class="stat-card" data-aos="zoom-in" data-aos-delay="300">
                    <div class="icon-wrapper">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <span class="counter" data-target="793">0</span>
                    <h6>خدمة العملاء</h6>
                </div>

                <div class="stat-card" data-aos="zoom-in" data-aos-delay="400">
                    <div class="icon-wrapper">
                        <i class="fa-solid fa-briefcase"></i>
                    </div>
                    <span class="counter" data-target="710">0</span>
                    <h6>عامل وعاملة</h6>
                </div>
            <?php endif; ?>
        </div>

        
     <div class="extra-stats" data-aos="fade-up" data-aos-delay="500">
  <div class="extra-item">
    <div class="title-row">
      <i class="fa-solid fa-star"></i>
      <h5>نسبة رضا العملاء:</h5>
    </div>
    <p><span>94%</span> من عملاؤنا راضيين عن الخدمة</p>
  </div>

  <div class="extra-item">
    <div class="title-row">
      <i class="fa-solid fa-stopwatch"></i>
      <h5>إنجاز الطلبات في الوقت المحدد:</h5>
    </div>
    <p><span>98%</span> من الطلبات نُفذت في الفترة المحددة</p>
  </div>

  <div class="extra-item">
    <div class="title-row">
      <i class="fa-solid fa-user-shield"></i>
      <h5>دعم ما بعد الوصول:</h5>
    </div>
    <p><span>100%</span> نسبة المتابعة والدعم بعد الوصول</p>
  </div>
</div>
    </div>
</section>


    <!-- steps sec  -->
    <section class="steps" id="steps">
        <div class="container">
            <!-- Section Title -->
            <div class="SectionTitle">
                <h2 class="title" data-aos="fade-up"><?php echo e(__('ingaz.Recruitment steps')); ?></h2>
                <h6 class="hint" data-aos="fade-up" data-aos-delay="100">
                    <?php echo e(__('ingaz.Recruitment steps hint')); ?>

                </h6>
            </div>

            <!-- steps -->
            <div class="allSteps">
                <?php $__empty_1 = true; $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="step" data-aos="fade-up" data-aos-delay="100">
                        <div class="icon">
                            <i class="fa-thin fa-<?php echo e($step->icon); ?>"></i>
                        </div>
                        <p>
                            <?php echo e($step->title); ?>

                        </p>
                        <?php if($key == 0): ?>
                            <div class="images">
                                <img src="<?php echo e(asset('site')); ?>/assets/images/mc.webp" data-aos="zoom-in"
                                     data-aos-delay="200">
                                <img src="<?php echo e(asset('site')); ?>/assets/images/visa.webp" data-aos="zoom-in"
                                     data-aos-delay="300">
                                <img src="<?php echo e(asset('site')); ?>/assets/images/mada.webp" data-aos="zoom-in"
                                     data-aos-delay="400">
                                      <img src="<?php echo e(asset('site')); ?>/assets/images/tabby.png" data-aos="zoom-in"
                                     data-aos-delay="400">
                                      <img src="<?php echo e(asset('site')); ?>/assets/images/tamara.webp" data-aos="zoom-in"
                                     data-aos-delay="400">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="step" data-aos="fade-up" data-aos-delay="100">
                        <div class="icon">
                            <i class="fa-thin fa-wallet"></i>
                        </div>
                        <p>
                            سداد رسوم تاشيرة العمالة المنزلية الخاصة بك عبر الخدمات الحكومية
                            في البنك او عن طريق القنوات التالية
                        </p>
                        <div class="images">
                            <img src="<?php echo e(asset('site')); ?>/assets/images/mc.webp" data-aos="zoom-in" data-aos-delay="200">
                            <img src="<?php echo e(asset('site')); ?>/assets/images/visa.webp" data-aos="zoom-in"
                                 data-aos-delay="300">
                            <img src="<?php echo e(asset('site')); ?>/assets/images/mada.webp" data-aos="zoom-in"
                                 data-aos-delay="400">
                                  <img src="<?php echo e(asset('site')); ?>/assets/images/tabby.png" data-aos="zoom-in"
                                     data-aos-delay="400">
                                      <img src="<?php echo e(asset('site')); ?>/assets/images/tamara.webp" data-aos="zoom-in"
                                     data-aos-delay="400">
                        </div>
                    </div>
                    <div class="step" data-aos="fade-up" data-aos-delay="200">
                        <div class="icon">
                            <i class="fa-thin fa-passport"></i>
                        </div>
                        <p>طلب اصدار تاشيرة العمالة المنزلية الخاصة بك في برنامج مساند</p>
                    </div>
                    <div class="step" data-aos="fade-up" data-aos-delay="300">
                        <div class="icon">
                            <i class="fa-thin fa-id-card"></i>
                        </div>
                        <p>
                            اختيار السيرة الذاتية للعمالة المنزلية عبر البحث في برنامج مساند
                            عن طريق المهنة/ الجنسية
                        </p>
                    </div>
                    <div class="step" data-aos="fade-up" data-aos-delay="400">
                        <div class="icon">
                            <i class="fa-thin fa-wallet"></i>
                        </div>
                        <p>
                            دفع مبلغ اختياري وتوثيق طلب استقدام العمالة المنزلية المحددة بعد
                            اختيار السيرة الذاتية
                        </p>
                    </div>
                    <div class="step" data-aos="fade-up" data-aos-delay="500">
                        <div class="icon">
                            <i class="fa-thin fa-plane"></i>
                        </div>
                        <p>وصول العمالة المنزلية من المطار المحلي الى المكتب</p>
                    </div>
                    <div class="step" data-aos="fade-up" data-aos-delay="600">
                        <div class="icon">
                            <i class="fa-thin fa-handshake"></i>
                        </div>
                        <p>يتم استلام العمالة الخاصة بك في المكتب</p>
                    </div>
                    <div class="step" data-aos="fade-up" data-aos-delay="700">
                        <div class="icon">
                            <i class="fa-thin fa-shield-check"></i>
                        </div>
                        <p>نضمن لك العمالة لمدة 3 شهور</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- ================ requirements ================= -->
    <section class="requirements">
        <div class="container">
            <div class="headTitle">
                <h2 data-aos="fade-up"><?php echo e(__('ingaz.Recruitment_requirements')); ?> </h2>
                <p data-aos="fade-up">
                    <?php echo e(__('ingaz.requirements_you_need')); ?>

                </p>
            </div>
            <div class="row">
                <div class="col-md-6 p-2">
                    <div class="requirement">
                        <div class="head" data-aos="fade-up">
                            <h4><?php echo e(__('ingaz.Documents_domestic')); ?></h4>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $Domestic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domestic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <ul>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="<?php echo e($domestic->image); ?>"></i>
                                    </div>
                                    <p> <?php echo e($domestic->title); ?></p>
                                </li>
                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <ul>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-address-card"></i>
                                    </div>
                                    <p> صورة الهوية الوطنية او الاقامة للمقيمين </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-headset"></i>
                                    </div>
                                    <p> خدمة عملاء متميزة </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-building-columns"></i>
                                    </div>
                                    <p> تعريف بالراتب من جهة العمل أو كشف حساب البنك </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-passport"></i>
                                    </div>
                                    <p> التأشيرة الأصل </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-calendar-lines-pen"></i>
                                    </div>
                                    <p> توقيع عقد إستقدام </p>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-6 p-2">
                    <div class="requirement">
                        <div class="head" data-aos="fade-up">
                            <h4><?php echo e(__('ingaz.Documents_visa')); ?> </h4>
                            <p>
                                <?php echo e(__('ingaz.Please_visit_the_Domestic_Workers_Program_Support_website')); ?>

                                <a href="<?php echo e(route('site.musaned.index')); ?>"> من هنا </a>
                            </p>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $Visa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <ul>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="<?php echo e($visa->image); ?>"></i>
                                    </div>
                                    <p> <?php echo e($visa->title); ?> </p>
                                </li>
                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <ul>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-address-card"></i>
                                    </div>
                                    <p> صورة الهوية الوطنية او الاقامة للمقيمين </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-headset"></i>
                                    </div>
                                    <p> خدمة عملاء متميزة </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-building-columns"></i>
                                    </div>
                                    <p> تعريف بالراتب من جهة العمل أو كشف حساب البنك </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-passport"></i>
                                    </div>
                                    <p> التأشيرة الأصل </p>
                                </li>
                                <li data-aos="fade-up">
                                    <div class="icon">
                                        <i class="fa-regular fa-calendar-lines-pen"></i>
                                    </div>
                                    <p> توقيع عقد إستقدام </p>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- ================ musaned-platform ================= -->
<section class="video-section" id="promo-video">
  <div class="container">
    <h2 class="video-title" data-aos="fade-up" data-aos-duration="800">
      <?php echo e(__('ingaz.video_title')); ?>

    </h2>

    <div class="video-wrapper" data-aos="zoom-in" data-aos-duration="1000">
      <iframe
        src="<?php echo e(__('ingaz.video_link')); ?>"
        title="<?php echo e(__('ingaz.video_description')); ?>"
        frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        referrerpolicy="strict-origin-when-cross-origin"
        allowfullscreen
      ></iframe>
    </div>
  </div>
</section>



    <!-- ================ references ================= -->
    <section class="references" data-aos="fade-up">
        <div class="container">
            <div class="swiper referencesSlider">
                <div class="swiper-wrapper">
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="swiper-slide" data-aos="zoom-in">
                            <div class="referenceLogo">
                                <img src="<?php echo showfile($client->image); ?>" alt="">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="swiper-slide" data-aos="zoom-in">
                            <div class="referenceLogo">
                                <img src="<?php echo e(asset('site')); ?>/assets/images/Ministry-of-Foreign-Affairs-01.svg" alt="">
                            </div>
                        </div>
                        <div class="swiper-slide" data-aos="zoom-in">
                            <div class="referenceLogo">
                                <img src="<?php echo e(asset('site')); ?>/assets/images/Ministry-of-Interior-01.svg" alt="">
                            </div>
                        </div>
                        <div class="swiper-slide" data-aos="zoom-in">
                            <div class="referenceLogo">
                                <img src="<?php echo e(asset('site')); ?>/assets/images/Ministry-of-Labor-and-Social-Development.svg"
                                     alt="">
                            </div>
                        </div>
                        <div class="swiper-slide" data-aos="zoom-in">
                            <div class="referenceLogo">
                                <img src="<?php echo e(asset('site')); ?>/assets/images/musand.svg" alt="">
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>

    <!-- ================ contact Form ================= -->







































































<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY"></script>
    <script>
        let map, marker;

        function initMap() {
            const defaultLocation = {
                lat: 30.0444,
                lng: 31.2357
            }; // القاهرة كمثال

            map = new google.maps.Map(document.getElementById("map"), {
                zoom: 10,
                center: defaultLocation,
            });

            marker = new google.maps.Marker({
                position: defaultLocation,
                map: map,
                draggable: true
            });

            // عند تحريك العلامة (Marker)
            google.maps.event.addListener(marker, 'dragend', function (event) {
                document.getElementById("latitude").value = event.latLng.lat();
                document.getElementById("longitude").value = event.latLng.lng();
            });
        }

        // تحميل الخريطة عند فتح الصفحة
        window.onload = initMap;
    </script>

    <script>
        $(document).ready(function () {
            $('#contact-form').on('submit', function (e) {
                e.preventDefault();

                $.ajax({
                    url: "<?php echo e(route('site.contact-us.store')); ?>",
                    method: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        name: $('#name').val(),
                        phone: $('#phone').val(),
                        subject: $('#subject').val(),
                        message: $('#message').val(),
                        latitude: $('#latitude').val(),
                        longitude: $('#longitude').val(),
                        'g-recaptcha-response': grecaptcha.getResponse()

                    },
                    success: function (response) {

                        $('#contact-form')[0].reset();
                        Swal.fire({
                            icon: 'success',
                            title: '<?php echo e(__("ingaz.success")); ?>',
                            text: '<?php echo e(__("ingaz.success")); ?>',
                            confirmButtonText: '<?php echo e(__("ingaz.ok")); ?>'
                        });
                    },
                    error: function (xhr) {
                        console.error("خطأ في الطلب:", xhr);
                    }
                });


            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/site/pages/home.blade.php ENDPATH**/ ?>