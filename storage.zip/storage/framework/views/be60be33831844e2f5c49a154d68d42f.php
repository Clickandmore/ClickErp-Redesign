<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/tree_collapse/tree-co.css')); ?>">
    <style>
        .my-swal {
            background-color: #f8d7da !important; /* Example background color */
        }
        .price {
            border: 0 !important;
            font-weight: bold;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $totalDebtorBalance = $totalCreditorBalance = 0;

        function addButtonTree($route, $fullText = '')
        {
            return '<button type="button" class="btn btn-success addButton ms-1" data-bs-toggle="modal" data-bs-target="#createModal"
                            model-route="' . $route . '" model-title="' . $fullText . '">
                        <i class="fa fa-plus-circle"></i>
                    </button>';
        }

        function createTreeView($accounts, $createRoute, $constraints)
        {
            foreach ($accounts as $account) {
                $sumDebtor = $sumCreditor = $finalBalance = 0;

                // Calculate sum for all children
                foreach ($account->all_children_ids as $childId) {
                    if (isset($constraints[$childId])) {
                        $sumDebtor += $constraints[$childId]['debtor_value'] ?? 0;
                        $sumCreditor += $constraints[$childId]['creditor_value'] ?? 0;
                    }
                }

                // Calculate final balance based on account type
                if ($account->status->value === 'debtor') {
                    $finalBalance = $sumDebtor - $sumCreditor;
                } elseif ($account->status->value === 'creditor') {
                    $finalBalance = $sumCreditor - $sumDebtor;
                }

                // Generate action buttons
                $buttons = '';
                if ($account->operation_type != 2) {
                    $buttons .= addButtonTree($createRoute . '?parent_id=' . $account->id);
                    if (($account->operation_type == 3 || auth('admin')->user()->admin_type == \App\Enums\AdminTypeisEnum::Developer->value) && $account->constraintDetails->isEmpty()) {
                        $buttons .= editButton(route('finance.accounts.edit', $account->id), $account->name);
                        if ($account->operation_type == 3 && $account->constraintDetails->isEmpty()) {
                            $buttons .= deleteButton(route('finance.accounts.destroy', $account->id, $account->children->isNotEmpty() ? 1 : 0));
                        }
                    }
                }

                // Render account tree structure
                $isParent = $account->childrenRecursive->isNotEmpty();
                $balance = $finalBalance ?: (isset($constraints[$account->id]) ?
                            ($account->status->value === 'debtor' ?
                            $constraints[$account->id]['debtor_value'] - $constraints[$account->id]['creditor_value'] :
                            $constraints[$account->id]['creditor_value'] - $constraints[$account->id]['debtor_value']) : 0);

                $status = $account->status->value === 'debtor' ? '<b style="color: red"> (مدين) </b>' : '<b style="color: blue"> (دائن) </b>';
                $price = "<span class='price'>رصيد {$balance}</span>";

                echo '<li>';
                if ($isParent) {
                    echo '<span>
                            <a data-bs-toggle="collapse" href="#Page-' . $account->id . '" aria-expanded="true" aria-controls="Page-' . $account->id . '">
                                <i class="collapsed">  <i class="fa fa-folder"></i></i>
                                <i class="expanded"> '.$account->level.'  <i class="fa fa-folder-open"></i></i> ' . $account->code . ' / <i class="fa fa-book"></i> ' . $account->name . '
                            </a>
                            ' . $status . $price . $buttons . '
                          </span>
                          <ul>
                            <div id="Page-' . $account->id . '" class="collapse in show">';
                    createTreeView($account->childrenRecursive, $createRoute, $constraints);
                    echo '   </div>
                          </ul>';
                } else {
                    echo '<span> '.$account->level.' <i class="fa fa-database"></i> ' . $account->code . ' / <i class="fa fa-book"></i> ' . $account->name . ' ' . $status . $price . $buttons . '</span>';
                }
                echo '</li>';
            }
        }
    ?>

    <?php echo addButton($createRoute, $addButtonText); ?>


    <div class="col-md-12" id="option_search">
        <div class="col-md-4 col-md-offset-4 col-sm-6 col-xs-12">
            <input type="text" class="form-control" id="filterUl" style="height: 40px;" placeholder="بحــــث"/>
        </div>
        <div class="clearfix"></div>
        <div class="tree searchTree">
            <ul>
                <li>
                    <span>
                        <a data-bs-toggle="collapse" href="#Web" aria-expanded="true" aria-controls="Web">
                            <i class="collapsed"><i class="fa fa-folder"></i></i>
                            <i class="expanded"><i class="fa fa-folder-open"></i></i> <?php echo e($bladeTitle); ?>

                        </a>
                    </span>
                    <div id="Web" class="collapse in show">
                        <ul>
                            <?php createTreeView($accountTree, $createRoute, $constraints); ?>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#filterUl').keyup(function () {
            const filter = $(this).val().toLowerCase();
            $('.searchTree li').each(function () {
                const text = $(this).text().toLowerCase();
                $(this).toggle(text.includes(filter));
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/account/index.blade.php ENDPATH**/ ?>