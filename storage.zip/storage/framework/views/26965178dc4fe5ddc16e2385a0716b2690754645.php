<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make("nami.layout.inc._meta", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('page-title'); ?></title>


    <?php echo $__env->make("nami.layout.inc._css", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent("style"); ?>


</head>
<body class="layout-1  <?php if(app()->getLocale() == 'ar'): ?> rtl_mode <?php endif; ?> " data-luno="theme-blue"> <!-- h-menu  -->

<?php echo $__env->make("nami.layout.inc.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="wrapper">

    <?php echo $__env->make("nami.layout.inc.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     
    <?php echo $__env->make('nami.layout.inc.page_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('up-card'); ?>


    <?php echo $__env->make("nami.layout.inc.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make("nami.layout.inc.global_modals", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("nami.layout.inc.siderbar_models", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make("nami.layout.inc._js", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("nami.layout.inc._js_custom", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
     $("input[type=search]").on("input", function() {
            var searchTerm = $(this).val().toLowerCase().trim();
            if (searchTerm.length > 0) {
                $(".nav-sidebar li").each(function() {
                    var listItemText = $(this).text().toLowerCase();
                    if (listItemText.indexOf(searchTerm) === -1) {
                        $(this).hide();
                    } else {
                        $(this).show();
                    }
                });
            } else {
                $(".nav-sidebar li").show();
            }
        });
</script>
<?php echo $__env->yieldContent("js"); ?>
</body>
</html>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/nami/layout/indexs/index.blade.php ENDPATH**/ ?>