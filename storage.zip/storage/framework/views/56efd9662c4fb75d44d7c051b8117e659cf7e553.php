<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>" enctype="multipart/form-data">
   <div class="col-md-3">
       <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.employees")); ?>  </label>
       <select class="form-control show-tick ms" name="employee_id" data-validation="required">
           <option value=""> <?php echo e(__("hr::hr.Choose")); ?></option>
           <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>
   </div>
    <div class="col-md-3">
        <label for="total_amount" class="form-label"> <?php echo e(__("hr::hr.installment_value")); ?>  </label>
        <input type="text"  name="value" class="form-control " id="total_amount" data-validation="required">
    </div>

    <div class="col-md-3">
        <label for="date" class="form-label"> <?php echo e(__("hr::hr.payment_sol_date")); ?>  </label>
        <input type="date" id="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-md-6">
        <label for="notes" class="form-label"> <?php echo e(__("hr::hr.notes")); ?>  </label>
        <textarea name="notes" id="notes" class="form-control" cols="15" rows="3"></textarea>
    </div>

    <div class="col-md-6">
        <label for="payment_method" class="form-label"> <?php echo e(__("hr::hr.payment method")); ?> </label>
        <select class="form-control show-tick ms" name="payment_method"
                data-validation="required" id="payment_method" >
                <?php echo getEnumData($advance_method , "advance_method"); ?>

        </select>
    </div>
    <div class="col-md-6">
        <label for="delivery_method" class="form-label"> <?php echo e(__("hr::hr.delivery_method")); ?> </label>
        <select class="form-control show-tick ms" name="delivery_method"
                data-validation="required" id="delivery_method" >
            <?php echo getEnumData($delivery_methods , "delivery_methods"); ?>


        </select>
    </div>

    <div class="col-md-12 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.file")); ?></label>
        <input type="file"  name="file" class="dropify">
    </div>

    <div id="table" class="col-12" style="display: none;">
        <table id="myDataTable_no_filter" class="table align-middle card-table my-2">
            <thead>
            <tr>
                <th><?php echo e(__("hr::hr.date")); ?></th>
                <th><?php echo e(__("hr::hr.installment")); ?> </th>
                <th><?php echo e(__("hr::hr.actions")); ?></th>
            </tr>
            </thead>
            <tbody id="json_array" class="content" data-mfield-options='{"section": ".y-group","btnAdd":"#btnAdd-2","btnRemove":".btnRemove"}'>
                <tr class="y-group">
                    <td>
                        <input type="date" min="<?php echo e(date('Y-m-d', strtotime('+1 day'))); ?>" name="date_value[]" class="form-control">
                    </td>
                    <td>
                        <input type="number"  name="amount_value[]" oninput="" class="form-control amount "  >
                    </td>
                    <td>
                        <i class="fa fa-plus-circle" id="btnAdd-2"></i>
                        <i class="fa fa-trash btnRemove"></i>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="col-12 mb-2" id="field" style="display: none;">
        <div class="row">
            <div class="col-md-4">
                <label for="TextInput"  class="form-label"> <?php echo e(__("hr::hr.from_date")); ?>  </label>
                <input type="month" min="<?php echo e(date('Y-m')); ?>" oninput="calculateOneValue()" name="from_date" id="from_date" class="form-control" data-validation="required">
            </div>

            <div class="col-md-4">
                <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.to_date")); ?>  </label>
                <input type="month" min="<?php echo e(date('Y-m')); ?>" oninput="calculateOneValue()" name="to_date"  id="to_date" class="form-control" data-validation="required">
            </div>

            <div class="col-md-4">
                <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.installment")); ?>  </label>
                <input type="text" name="amount" id="amount" class="form-control" data-validation="required">
            </div>
        </div>
    </div>

    <div class="col-12 modal-footer">
        <?php echo submitButton( $storeRoute); ?>

        <?php echo closeButton(); ?>


    </div>

</form>


<script>
    function calculateSum() {
        let sum = 0;
        $('.amount').each(function () {
            let val = parseFloat($(this).val());
            if (!isNaN(val)) {
                sum += val;
            }
        });
        $('#total_amount').val(sum);
    }
    function calculateOneValue() {
        const fromDate = document.getElementById('from_date').value;
        const toDate = document.getElementById('to_date').value;
        const total = document.getElementById('total_amount').value;
        const amount = document.getElementById('amount');

        if (fromDate && toDate) {
            const from = new Date(fromDate);
            const to = new Date(toDate);

            let months;
            months = (to.getFullYear() - from.getFullYear()) * 12;
            months -= from.getMonth();
            months += to.getMonth();
            // alert(months);
            ++months;

            // Ensure that the difference is not negative
            if (months < 0) {
                months = 0;
            }

            amount.value = Math.round((total / months) * 100) / 100 ;
        } else {
            amount.value = total;
        }
    }
</script>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employeeAdvances/create.blade.php ENDPATH**/ ?>