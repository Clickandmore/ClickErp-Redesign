<script>
    // $(document).ajaxComplete(function() {
    //     function setTaxRate() {
    //         var selectedOption = $('#tax_setting_id option:selected');
    //         var dataValue = selectedOption.data('value');
    //         var accountId = selectedOption.data('account-id');
    //         $('#tax_account_id').val(accountId);
    //         $('#tax_rate').val(dataValue);
    //         calculateTax();
    //     }

    //     $('#tax_setting_id').on('change', function() {
    //         setTaxRate();
    //     });
    //     setTaxRate();
    // });
        function getPaymentTypeHtml(type) {
            let obj = $("#payment_type");
            let paymentTypeValue = obj.find(":selected").val();
            let url = '<?php echo e(route('finance.bonds-payment.show', ':id')); ?>';
            url = url.replace(':id', paymentTypeValue);
            url += "?type=" + type;
            $.ajax({
                url: url,
                type: 'GET',
                beforeSend: function () {
                    $("#content-div").html("");
                },
                complete: function () {
                },
                success: function (result) {
                    $("#content-div").html(result.data.html);
                },
                error: function (errorObj, errorText, errorThrown) {
                    handleErrorResponce(errorObj);
                }
            });
        }


    function toggleTaxFields() {
        var yesRadio = document.getElementById('is_tax_yes');
        var taxFields = document.getElementById('tax-fields');

        if (yesRadio.checked) {
            taxFields.style.display = 'block';
        } else {
            taxFields.style.display = 'none';
        }
        calculateTax();
    }

    function calculateTax() {
        var isTaxChecked = document.getElementById('is_tax_yes').checked;
        var value = parseFloat(document.getElementById('value').value) || 0;
        var taxRate = parseFloat(document.getElementById('tax_rate').value) || 0;
        var taxAmount = 0;
        var net = value;

        if (isTaxChecked) {
            taxAmount = value - ((value * 100) / (taxRate + 100));
            net = (value * 100) / (taxRate + 100);
        }

        document.getElementById('tax_amount').value = taxAmount.toFixed(2);
        document.getElementById('net').value = net.toFixed(2);
    }


    $(document).on('click', '.confirmButton', function (e) {
        e.preventDefault()
        let buttonObj = $(this);
        let confirmRoute = buttonObj.attr("confirm-route");
        let bondId = buttonObj.attr("confirm-id");
        let postData = {"bond_id": bondId};
        swal.fire({
            title: "<?php echo e(__('buttons.Are You Sure')); ?>",
            text: "<?php echo e(__('buttons.You Can not to rollback')); ?>",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "<?php echo e(__('buttons.accept')); ?>",
            cancelButtonText: "<?php echo e(__('buttons.cancel')); ?>",
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: confirmRoute,
                    data: postData,
                    type: 'POST',
                    beforeSend: function () {
                    },
                    complete: function () {
                    },
                    success: function (data) {
                        Swal.fire({
                            icon: 'success',
                            title: "<?php echo e(__('buttons.Confirm successfully')); ?>",
                            confirmButtonText: "<?php echo e(__('buttons.close')); ?>",
                        });
                        reloadDataTable();
                    },
                    error: function (errorObj, errorText, errorThrown) {
                        handleErrorResponce(errorObj);
                    }
                });
            }
        });
    });

    $(document).ready(function () {
        let table = $("#dataTableObject").DataTable({
            responsive: true,
            processing: true,
            serverSide: false,
            ordering: true,
            searching: true,
            iDisplayLength: 10,
            lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
            ajax: {
                url: "<?php echo e($dataTableRoute); ?>",
                data: function (response) {
                    response.from_date = $('#from_date').val();
                    response.to_date = $('#to_date').val();
                    response.cost_center_id = $('#cost_center_id').val();
                    response.debit_account_id = $('#debit_account_id').val();
                    response.credit_account_id = $('#credit_account_id').val();
                    response.payment_type = $('#payment_type_filter').val();
                }
            },
            columns: [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {"data": "bond_num", orderable: false, searchable: true},
                {"data": "date", orderable: false, searchable: true},
                {"data": "debit_account", orderable: false, searchable: true},
                {"data": "credit_account", orderable: false, searchable: true},
                {"data": "value", orderable: false, searchable: true},
                {"data": "payment_type_name", orderable: false, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ],
            language: {
                sProcessing: "<?php echo e(trans('dataTable.sProcessing')); ?>",
                sLengthMenu: "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                sZeroRecords: "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                sInfo: "<?php echo e(trans('dataTable.sInfo')); ?>",
                sInfoEmpty: "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                sInfoFiltered: "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                sSearch: "<?php echo e(trans('dataTable.sSearch')); ?>:",
                oPaginate: {
                    sFirst: "<?php echo e(trans('dataTable.sFirst')); ?>",
                    sPrevious: "<?php echo e(trans('dataTable.sPrevious')); ?>",
                    sNext: "<?php echo e(trans('dataTable.sNext')); ?>",
                    sLast: "<?php echo e(trans('dataTable.sLast')); ?>"
                }
            },
            order: [[2, "desc"]]
        });
        $('#from_date, #to_date , #cost_center_id,#debit_account_id,#credit_account_id,#payment_type_filter').change(function () {
            table.ajax.reload();
        });
    })

</script>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/bond/_js_bond.blade.php ENDPATH**/ ?>