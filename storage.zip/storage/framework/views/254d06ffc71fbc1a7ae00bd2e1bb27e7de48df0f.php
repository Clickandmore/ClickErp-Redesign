<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.employees')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance.clients")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row mb-2">
        <div class="col-3">
            <div class="form-group">
                <label for="department_id" class="form-label"><?php echo e(__('hr::hr.department')); ?></label>
                <select class="form-select select2" id="department_id" name="department_id">
                    <?php echo showSelectElement($departments, 'title'); ?>

                </select>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label for="job_id" class="form-label"><?php echo e(__('hr::hr.job')); ?></label>
                <select class="form-select select2" id="job_id" name="job_id">
                    <?php echo showSelectElement($jobs, 'title'); ?>

                </select>
            </div>
        </div>
        <div class="col-3">

        </div>
        <div class="col-3">
            <br>
            <?php echo addEmplyeeButton($createRoute , $addButtonText); ?>

        </div>
    </div>

    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('hr::hr.SL')); ?></th>
            <th><?php echo e(__("hr::hr.image")); ?></th>
            <th><?php echo e(__("hr::hr.name")); ?></th>
            <th><?php echo e(__("hr::hr.Employee ID number")); ?></th>
            <th><?php echo e(__("hr::hr.Date of hiring")); ?></th>
            <th><?php echo e(__("hr::hr.job")); ?></th>
            <th><?php echo e(__("hr::hr.department")); ?></th>
            <th><?php echo e(__("hr::hr.Status")); ?></th>
            <th><?php echo e(__("hr::hr.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/datatable.buttons.min.js"></script>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/buttons.print.min.js"></script>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/jszip.min.js"></script>

    <script>
        $(document).ready(function () {
            let table = $("#dataTableObject").DataTable({
                responsive: 1,
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "searching": true,
                'iDisplayLength': 10,
                "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
                "ajax": {
                    "url": "<?php echo e(route('employees.index')); ?>",
                    "data": function (d) {
                        d.department_id = $('#department_id').val();
                        d.job_id = $('#job_id').val();
                    }
                },
                "columns": [
                    {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                    {"data": "image", orderable: false, searchable: false},
                    {"data": "name", orderable: false, searchable: true},
                    {"data": "national_num", orderable: false, searchable: true},
                    {"data": "hired_date", orderable: false, searchable: true},
                    {"data": "job_id", orderable: false, searchable: true},
                    {"data": "deparment_id", orderable: false, searchable: true},
                    {"data": "status", orderable: false, searchable: false},
                    {"data": "actions", orderable: false, searchable: false}
                ],
                "language": {
                    "sProcessing": "<?php echo e(trans('dataTable.sProcessing')); ?>",
                    "sLengthMenu": "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                    "sZeroRecords": "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                    "sInfo": "<?php echo e(trans('dataTable.sInfo')); ?>",
                    "sInfoEmpty": "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                    "sInfoFiltered": "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                    "sSearch": "<?php echo e(trans('dataTable.sSearch')); ?>:",
                    "oPaginate": {
                        "sFirst": "<?php echo e(trans('dataTable.sFirst')); ?>",
                        "sPrevious": "<?php echo e(trans('dataTable.sPrevious')); ?>",
                        "sNext": "<?php echo e(trans('dataTable.sNext')); ?>",
                        "sLast": "<?php echo e(trans('dataTable.sLast')); ?>"
                    }
                },
                order: [[2, "desc"]],
                dom: 'Bflrtip', // Add the Buttons extension to the DataTable
                buttons: [
                    {
                        extend: 'excel',
                        className: 'btn btn-outline-success mb-2',
                        text: '<?php echo e(trans('dataTable.ex_excel')); ?>',
                    }
                ]
            });

            $('#department_id, #job_id').change(function () {
                table.draw();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employees/index.blade.php ENDPATH**/ ?>