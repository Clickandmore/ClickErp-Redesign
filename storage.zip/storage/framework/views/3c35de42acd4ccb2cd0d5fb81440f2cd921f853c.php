
<?php if($data->count() > 0): ?>
    <?php
        $months  = [];
        $totals['debtor']  = 0;
        $totals['creditor']  = 0;
        $totalDebtorValue = 0.0;
        $totalCreditorValue = 0.0;
        $totalSumDebtorValue = 0;
        $totalSumCreditorValue = 0;
    ?>
    <div class="table-responsive">
        <table id="myTable" class="table table-bordered table-striped dataTable no-footer">
            <thead>
            <tr>
                <th>#</th>
                <th><?php echo e(__('finance.account')); ?></th>
                <?php if($firstBalance): ?>
                    <th colspan="2"><?php echo e(__('finance::finance.First Balance')); ?></th>
                <?php endif; ?>
                <?php $__currentLoopData = $months_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th colspan="2"><?php echo e(getMonthName($month)); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th colspan="2"><?php echo e(__('finance::finance.totals')); ?></th>
                <th colspan="2"><?php echo e(__('finance::finance.balances')); ?></th>
            </tr>
            <tr>
                <th></th>
                <th></th>
                <?php if($firstBalance): ?>
                    <th><?php echo e(__('finance::finance.debtor')); ?></th>
                    <th><?php echo e(__('finance::finance.creditor')); ?></th>
                <?php endif; ?>
                <?php $__currentLoopData = $months_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $months[$month]['sum_debtor_value'] = 0;
                        $months[$month]['sum_creditor_value'] = 0;
                    ?>
                    <th><?php echo e(__('finance::finance.debtor')); ?></th>
                    <th><?php echo e(__('finance::finance.creditor')); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e(__('finance::finance.debtor')); ?></th>
                <th><?php echo e(__('finance::finance.creditor')); ?></th>
                <th><?php echo e(__('finance::finance.debtor')); ?></th>
                <th><?php echo e(__('finance::finance.creditor')); ?></th>
            </tr>
            </thead>
            <tbody id="option_table">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account_key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $rowDebtorTotal = 0.0;
                    $rowCreditorTotal = 0.0;
                    if($firstBalance){

                        $totalSumDebtorValue += $firstBalance[$account_key]->sum_debtor_value??0  ;
                        $totalSumCreditorValue += $firstBalance[$account_key]->sum_creditor_value??0  ;
                    }

                ?>
                <tr>
                    <td><?php echo e(++$loop->index); ?></td>
                    <td><?php echo e($row['account_name']); ?></td>
                    <?php if($firstBalance): ?>
                        <td class="col-y"><?php echo e($firstBalance[$account_key]->sum_debtor_value ?? 0); ?></td>
                        <td><?php echo e($firstBalance[$account_key]->sum_creditor_value ?? 0); ?></td>
                    <?php endif; ?>
                    <?php $__currentLoopData = $months_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $debtorValue = $row['months'][$month]['sum_debtor_value'] ?? 0.0;
                            $creditorValue = $row['months'][$month]['sum_creditor_value'] ?? 0.0;

                            $months[$month]['sum_debtor_value'] += $debtorValue;
                            $months[$month]['sum_creditor_value'] += $creditorValue;

                            $totalDebtorValue += $debtorValue;
                            $totalCreditorValue += $creditorValue;

                            $rowDebtorTotal += $debtorValue;
                            $rowCreditorTotal += $creditorValue;
                        ?>
                        <td class="col-y"><?php echo e($debtorValue); ?></td>
                        <td><?php echo e($creditorValue); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <td class="col-y"><?php echo e($rowDebtorTotal); ?></td>
                    <td><?php echo e($rowCreditorTotal); ?></td>

                    <?php
                        $totals['debtor'] += ($row['type'] == 'debtor') ? $rowDebtorTotal - $rowCreditorTotal : 0;
                        $totals['creditor'] += ($row['type'] == 'creditor') ? $rowCreditorTotal - $rowDebtorTotal : 0;
                    ?>
                    <td><?php echo e(($row['type'] == 'debtor') ? $rowDebtorTotal - $rowCreditorTotal : 0); ?></td>
                    <td><?php echo e(($row['type'] == 'creditor') ? $rowCreditorTotal - $rowDebtorTotal : 0); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr style="background-color: #48b849">
                <td colspan="2"><?php echo e(__('finance::finance.total')); ?></td>
                <?php if($firstBalance): ?>
                    <td><?php echo e($totalSumDebtorValue); ?></td>
                    <td><?php echo e($totalSumCreditorValue); ?></td>
                <?php endif; ?>
                <?php $__currentLoopData = $months_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($months[$key]['sum_debtor_value']); ?></th>
                    <th><?php echo e($months[$key]['sum_creditor_value']); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($totalDebtorValue); ?></td>
                <td><?php echo e($totalCreditorValue); ?></td>
                <td><?php echo e($totals['debtor']); ?></td>
                <td><?php echo e($totals['creditor']); ?></td>
            </tr>
            </tbody>
        </table>
    </div>

<?php else: ?>
    <div role="alert" class="alert alert-danger text-center"> <?php echo e(__('finance::finance.no_data_found')); ?></div>
<?php endif; ?>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/audit_budget_monthly/result.blade.php ENDPATH**/ ?>