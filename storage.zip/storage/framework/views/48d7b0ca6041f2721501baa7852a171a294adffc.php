<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>" enctype="multipart/form-data">
    <div class="col-6">
        <label for="title" class="form-label"><?php echo e(__('finance::finance.cost_center_name')); ?> </label>
        <input type="text" name="title" id="title" class="form-control" required data-validation="required">
    </div>

    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__('finance::finance.main-fn-cost-centers')); ?></label>
        <select class="form-control"  name="parent_id" id="parent_id">
            <option value=""><?php echo e(trans('finance::finance.Select')); ?> </option>
            <option value=""><?php echo e(trans('finance::finance.without')); ?></option>
            <?php $__currentLoopData = $cost_centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($one->id); ?>" <?php echo e(($one->id == @$parent_id) ? 'selected' : ''); ?> > <?php echo e($one->title); ?> / <?php echo e($one->code); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-6">
        <label for="code" class="form-label"><?php echo e(__('finance::finance.code')); ?> </label>
        <input type="text" name="code" id="code" class="form-control" required data-validation="required">
    </div>

    <?php if(isset($request['table_name']) && $request['table_name'] == 'stocks'): ?>
        <input type="hidden" name="table_name" value="stocks">
        <input type="hidden" name="table_related_id" value="<?php echo e($request['table_related_id']); ?>">
    <?php elseif(isset($request['table_name']) && $request['table_name'] == 'employees'): ?>
        <input type="hidden" name="table_name" value="employees">
        <input type="hidden" name="table_related_id" value="<?php echo e($request['table_related_id']); ?>">
    <?php else: ?>
        <div class="col-6">
            <label for="type" class="form-label"><?php echo e(__('finance::finance.cost_center_associated_with')); ?> </label>
            <span class="text-danger">*</span>
            <select class="form-control" name="table_name" id="table_name" data-validation="required">
                <?php echo getEnumData($types); ?>

            </select>
        </div>

        <div class="col-12" id="stocks_menu"  style="display: none;">
            <label for="TextInput" class="form-label"><?php echo e(__('finance::finance.stock')); ?></label>
            <select id="stock_id" name="table_related_id" class="form-control" data-validation="required">
                <?php echo showSelectElement($stocks,'name'); ?>

            </select>
        </div>







    <?php endif; ?>


    <div class="col-12 modal-footer">
         <?php echo submitButton(   $storeRoute  ); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<script>
    $(document).ready(function () {

        $('#table_name').on('change', function () {
            var selectedValue = $(this).val();
            if (selectedValue === 'stocks') {
                $('#stocks_menu').show();
                $('#employee_menu').hide();
                $('#stock_id').prop('disabled', false);
                $('#employee_id').prop('disabled', true);
            } else if (selectedValue === 'employees') {
                $('#employee_menu').show();
                $('#stocks_menu').hide();
                $('#employee_id').prop('disabled', false);
                $('#stock_id').prop('disabled', true);
            } else {
                $('#stocks_menu').hide();
                $('#employee_menu').hide();
                $('#stock_id').prop('disabled', true);
                $('#employee_id').prop('disabled', true);
            }
        });
    });
</script>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/cost_centers/create.blade.php ENDPATH**/ ?>