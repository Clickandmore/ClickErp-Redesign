<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>"
    enctype="multipart/form-data">

        <div class="col-12">
            <label for="name" class="form-label"><?php echo e(__('finance::finance.tax_name')); ?></label>
            <input type="text" name="name" id="name" class="form-control"data-validation="required">
        </div>


    <!-- First Modal -->
    <!-- Second Modal -->
    <div class="col-12">


        <label for="account_id" class="form-label"> <?php echo e(__('finance::finance.Directory account')); ?>  <?php echo addUpButton(route('finance.accounts.create'),'account_id' ,false, 'name'); ?></label>
        <select class="form-control required show-tick ms select2" name="account_id" id="account_id" data-validation="required">
            <?php echo showSelectElement($accounts, 'name', request()->account_id); ?>

        </select>
    </div>

    <div class="col-12">
        <label for="value" class="form-label"><?php echo e(__('finance::finance.percentage')); ?></label>
        <fieldset class="form-icon-group right-icon position-relative">
            <div class="form-icon position-absolute">
                <i class="fa fa-percentage"></i>
            </div>
            <input type="number" name="value" class="form-control" min="1" max="100" id="value" data-validation="required,number">
        </fieldset>
    </div>


    <div class="col-12 modal-footer">
        <?php echo submitButton($storeRoute); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/tax_setting/create.blade.php ENDPATH**/ ?>