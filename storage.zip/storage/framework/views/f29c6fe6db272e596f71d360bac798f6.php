<?php
$permissions = ['printSettings.create', 'letters.index', 'officialVacations.index',
    'departments.index', 'rewards.index', 'permissionsSettings.index'
    , 'tax.index', 'jobs.index', 'allowances.index', 'permissions.index'
    , 'sanctions.index', 'vacation-year.index'
    , 'vacations.index', 'insurances.index', 'shifts.index'];
?>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.home.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('finance.home.index')); ?>">
        <i class="fa fa-home"></i>
        <span class="ms-2"> <?php echo e(__('finance::finance.dashboard')); ?></span>
    </a>
</li>

<li class="collapsed">
    <a class="m-link
            <?php echo e(in_array(Route::currentRouteName(), [
                'finance.confirm-settings.index',
                'finance.tax-setting.index',
                'finance.years.index',
            ]) &&
            (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                ? 'active'
                : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#settings1" href="#">
        <i class="fa fa-gears"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.settings')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
            <?php echo e(in_array(Route::currentRouteName(), [
                'finance.confirm-settings.index',
                'finance.tax-setting.index',
                'finance.years.index',
            ]) &&
            (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                ? 'show'
                : ''); ?>"
        id="settings1">
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.confirm-settings.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.confirm-settings.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.Account settings')); ?> </span>

            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.tax-setting.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.tax-setting.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.taxSettings')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.years.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.years.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.fn-years')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link" href="#!">
                <span class="ms-2"> <?php echo e(__('finance::finance.Closing the fiscal year')); ?></span>
            </a>
        </li>
        
    </ul>
</li>



<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.opening-balance.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('finance.opening-balance.index')); ?>">
        <i class="fa fa-balance-scale me-2"></i>
        <span class="ms-2"> <?php echo e(trans('finance::finance.opening-balance')); ?> </span>
    </a>
</li>
































































<li class="collapsed">
    <a class="m-link
                <?php echo e(in_array(Route::currentRouteName(), [
                    'finance.boxes.index',
                    'finance.accounting-guide-management.index',
                    'finance.accounts.index',
                    // 'finance.cost-center-management.index',
                    // 'finance.cost-center-notification.index',
                    // 'finance.cost-centers.index',
                    'finance.banks.index',
                    'finance.bank_accounts.index',
//                    'finance.suppliers.index',
                ]) &&
                (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                    ? 'active'
                    : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#accounts_section" href="#">
        <i class="fa fa-fingerprint"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.accounts_section')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
                <?php echo e(in_array(Route::currentRouteName(), [
                    'finance.boxes.index',
                    'finance.accounting-guide-management.index',
                    'finance.accounts.index',
                    // 'finance.cost-center-management.index',
                    // 'finance.cost-center-notification.index',
                    // 'finance.cost-centers.index',
                    'finance.banks.index',
                    'finance.bank_accounts.index',
//                    'finance.suppliers.index',
                ]) &&
                (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                    ? 'show'
                    : ''); ?>"
        id="accounts_section">

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.accounting-guide-management.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.accounting-guide-management.index')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.Accounting guide management')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.accounts.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.accounts.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.accounts')); ?> </span>
            </a>
        </li>
        



        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.banks.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.banks.index')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.banks')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.bank_accounts.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.bank_accounts.index')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.banksAccounts')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.boxes.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.boxes.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.boxs_sidebar')); ?> </span>
            </a>
        </li>
        
        
        
        
        
        
        
        
        
    </ul>
</li>

<li class="collapsed">
    <a class="m-link
                <?php echo e(in_array(Route::currentRouteName(), [
                    'finance.suppliers_types.index',
                    'finance.suppliers.index',
                ])
                    ? 'active'
                    : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#suppliers" href="#">
        <i class="fa fa-truck"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.suppliers')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
            <?php echo e(in_array(Route::currentRouteName(), [
                 'finance.suppliers_types.index',
                 'finance.suppliers.index',
            ])
                ? 'show'
                : ''); ?>"
        id="suppliers">

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.suppliers_types.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.suppliers_types.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.suppliers_types')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.suppliers.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.suppliers.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.suppliers')); ?> </span>
            </a>
        </li>
        

    </ul>
</li>

<li class="collapsed">
    <a class="m-link
                <?php echo e(in_array(Route::currentRouteName(), [
                    'finance.client-categories.index',
                    'finance.clients.index',
                ]) &&
                (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                    ? 'active'
                    : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#clients" href="#">
        <i class="fa fa-users"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.clients')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
            <?php echo e(in_array(Route::currentRouteName(), [
                 'finance.client-categories.index',
                    'finance.clients.index',
            ]) &&
            (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                ? 'show'
                : ''); ?>"
        id="clients">

        
        <li>
            
            
            
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.client-categories.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.client-categories.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.client-categories')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.clients.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.clients.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.clients')); ?> </span>
            </a>
        </li>
        

    </ul>
</li>


<li class="collapsed">
    <a class="m-link
                <?php echo e(in_array(Route::currentRouteName(), [
                        'finance.principles.index',
                        'finance.principles.show',
                        'finance.transfer-principle.index',
                        'finance.manual-depreciations.index',
                        'finance.group-depreciation.index',
                        'finance.principle-sales.index',
                        'finance.principle-report.index',
                        'finance.principle-websites.index'
                     ])
                     ? 'active'
                     : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#principles" href="#">
        <i class="fa fa-users"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.principles')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
            <?php echo e(in_array(Route::currentRouteName(), [
                    'finance.principles.index',
                    'finance.principles.show',
                    'finance.transfer-principle.index',
                    'finance.manual-depreciations.index',
                    'finance.group-depreciation.index',
                    'finance.principle-sales.index',
                    'finance.principle-report.index',
                    'finance.principle-websites.index'
                  ])
                  ? 'show'
                  : ''); ?>"
        id="principles">
        <!-- رابط لقائمة principle websites -->
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.principle-websites.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.principle-websites.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.principle-websites')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.principles.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.principles.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.principles')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.transfer-principle.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.transfer-principle.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.transfer-principle')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.manual-depreciations.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.manual-depreciations.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.manual-depreciations')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.principle-report.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.principle-report.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.principle-report')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.group-depreciation.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.group-depreciation.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.group-depreciation')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.principle-sales.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.principle-sales.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.principle-sales')); ?> </span>
            </a>
        </li>
        
    </ul>
</li>


<li class="collapsed">
    <a class="m-link
            <?php echo e(in_array(Route::currentRouteName(), [
                'finance.cost-center-management.index',
                'finance.cost-center-notification.index',
                'finance.cost-centers.index',
            ]) &&
            (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                ? 'active'
                : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#cost_center" href="#">
        <i class="fa fa-money-bill"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.cost_center')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
            <?php echo e(in_array(Route::currentRouteName(), [
                'finance.cost-center-management.index',
                'finance.cost-center-notification.index',
                'finance.cost-centers.index',
            ]) &&
            (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                ? 'show'
                : ''); ?>"
        id="cost_center">
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.cost-center-management.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.cost-center-management.index')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.Cost center management')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.cost-center-notification.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.cost-center-notification.index')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.cost_centers_notifications')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.cost-centers.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.cost-centers.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.Cost Center Operations')); ?> </span>
            </a>
        </li>
        
    </ul>
</li>


<li class="collapsed">
    <a class="m-link
    <?php echo e(in_array(Route::currentRouteName(), [
        'finance.add-constraint.create',
        'finance.constraints.index',
    ]) &&
    (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
        ? 'active'
        : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#constraint_section" href="#">
        <i class="fa fa-file-invoice-dollar"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.constraint_section')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>

    <ul class="sub-menu collapse
            <?php echo e(in_array(Route::currentRouteName(), [
                'finance.add-constraint.create',
                'finance.constraints.index',
            ]) &&
            (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                ? 'show'
                : ''); ?>"
        id="constraint_section">

        
        
        
        
        
        
        
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.constraints.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.constraints.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.Managing daily constraints')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.add-constraint.create' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.add-constraint.create')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.Add daily constraint')); ?></span>
            </a>
        </li>
        

    </ul>
</li>

<li class="collapsed">
    <a class="m-link
                                <?php echo e(in_array(Route::currentRouteName(), [
                                    'finance.bonds-sarf.index',
                                    'finance.bonds-qabd.index',
                                    'finance.account-transfer.index',
                                    'finance.general-bonds-sarf.index',
                                    'finance.general-bonds-qabd.index',
                                ]) &&
                                (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                    ? 'active'
                                    : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#bonds" href="#">
        <i class="bi bi-files"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.bonds')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
                                     <?php echo e(in_array(Route::currentRouteName(), [
                                         'finance.bonds-sarf.index',
                                         'finance.bonds-qabd.index',
                                         'finance.account-transfer.index',
                                         'finance.general-bonds-sarf.index',
                                         'finance.general-bonds-qabd.index',
                                     ]) &&
                                     (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                         ? 'show'
                                         : ''); ?>"
        id="bonds">

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.bonds-sarf.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.bonds-sarf.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.sarf_bonds')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.general-bonds-sarf.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.general-bonds-sarf.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.General Bond Sarf')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.bonds-qabd.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.bonds-qabd.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.qabd_bonds')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.general-bonds-qabd.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.general-bonds-qabd.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.General Bond Qabd')); ?> </span>
            </a>
        </li>
        

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.account-transfer.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.account-transfer.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.account_transfers')); ?> </span>
            </a>
        </li>
        
    </ul>
</li>

<li class="collapsed">
    <a class="m-link
    <?php echo e(in_array(Route::currentRouteName(), [
        'finance.exchange-checks.index',
        'finance.catch-checks.index',
        'finance.exchange-checks-data.index',
        'finance.catch-checks-data.index',
    ]) &&
    (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
        ? 'active'
        : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#check_section" href="#">
        <i class="fa fa-money-check"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.checks')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>

    <ul class="sub-menu collapse
                                     <?php echo e(in_array(Route::currentRouteName(), [
                                         'finance.exchange-checks.index',
                                         'finance.catch-checks.index',
                                         'finance.exchange-checks-data.index',
                                         'finance.catch-checks-data.index',
                                     ]) &&
                                     (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                         ? 'show'
                                         : ''); ?>"
        id="check_section">
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.exchange-checks.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.exchange-checks.index')); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.exchange-checks')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.catch-checks.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.catch-checks.index')); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.catch-checks')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.exchange-checks-data.index' && request()->query('status') == 'collected' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.exchange-checks-data.index', ['status' => 'collected'])); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.collected_exchange_checks')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.exchange-checks-data.index' && request()->query('status') == 'refused' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.exchange-checks-data.index', ['status' => 'refused'])); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.refused_exchange_checks')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.catch-checks-data.index' && request()->query('status') == 'collected' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.catch-checks-data.index', ['status' => 'collected'])); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.collected_catch_checks')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.catch-checks-data.index' && request()->query('status') == 'refused' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.catch-checks-data.index', ['status' => 'refused'])); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.refused_catch_checks')); ?></span>
            </a>
        </li>
        
    </ul>
</li>

<li class="collapsed">
    <a class="m-link
                                <?php echo e(in_array(Route::currentRouteName(), [
                                    'finance.accounts-balances.index',
                                    'finance.clients-balances.index',
                                    'finance.suppliers-balances.index',
                                    'finance.treasury-and-banks-balances.index',
                                ]) &&
                                (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                    ? 'active'
                                    : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#balances_section" href="#">
        <i class="fa fa-scale-balanced"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.balances')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
                                     <?php echo e(in_array(Route::currentRouteName(), [
                                         'finance.accounts-balances.index',
                                         'finance.clients-balances.index',
                                         'finance.suppliers-balances.index',
                                         'finance.treasury-and-banks-balances.index',
                                     ]) &&
                                     (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                         ? 'show'
                                         : ''); ?>"
        id="balances_section">

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.accounts-balances.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.accounts-balances.index')); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.accounts_balances')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.clients-balances.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.clients-balances.index')); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.clients_balances')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.suppliers-balances.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.suppliers-balances.index')); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.suppliers_balances')); ?></span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.treasury-and-banks-balances.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.treasury-and-banks-balances.index')); ?>">
                <span class="ms-2"><?php echo e(trans('finance::finance.treasury_and_banks_balances')); ?></span>
            </a>
        </li>
        
    </ul>
</li>

<li class="collapsed">
    <a class="m-link
    <?php echo e(in_array(Route::currentRouteName(), [
        'finance.account-cost-centers.index',
        'finance.cash-movements.index',
        'finance.account-statement.index',
        'finance.debtor-accounts.index',
        'finance.creditor-accounts.index',
        'finance.account-statement-clients.index',
        'finance.account-statement-suppliers.index',
        'finance.bank-account-statement.index',
        'finance.arithmetic-transactions.index',
        'finance.account-balance-differed-normal.index',
    ]) &&
    (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
        ? 'active'
        : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#reports" href="#">
        <i class="fa fa-chart-bar"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.reports')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>

    <ul class="sub-menu collapse
                                     <?php echo e(in_array(Route::currentRouteName(), [
                                         'finance.account-cost-centers.index',
                                         'finance.cash-movements.index',
                                         'finance.account-statement.index',
                                           'finance.debtor-accounts.index',
                                    'finance.creditor-accounts.index',
                                         'finance.account-statement-clients.index',
                                         'finance.account-statement-suppliers.index',
                                         'finance.bank-account-statement.index',
                                         'finance.arithmetic-transactions.index',
//                                         'finance.accounts-debtor-report.index',
//                                        'finance.accounts-creditor-report.index',
                                        'finance.account-balance-differed-normal.index',
//                                        'finance.unusual-accounts.index'
                                     ]) &&
                                     (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                         ? 'show'
                                         : ''); ?>"
        id="reports">

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.account-statement.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.account-statement.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.account-statment')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.account-statement-clients.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.account-statement-clients.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.account-statement-clients')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.account-statement-suppliers.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.account-statement-suppliers.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.account-statement-suppliers')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.account-cost-centers.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.account-cost-centers.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.accounts-cost-centers')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.cash-movements.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.cash-movements.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.cash-movement')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.bank-account-statement.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.bank-account-statement.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.bank-account-statement')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.creditor-accounts.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.creditor-accounts.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.creditor-accounts')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.debtor-accounts.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.debtor-accounts.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.debtor-accounts')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.account-balance-differed-normal.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.account-balance-differed-normal.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.account-balance-differed-normal')); ?> </span>
            </a>
        </li>
        
        

    </ul>
</li>
<li class="collapsed">
    <a class="m-link
    <?php echo e(in_array(Route::currentRouteName(), [
        'finance.income-list.index',
        'finance.audit-budget-supplier.index',
        'finance.trail-balance.index',
        'finance.audit-budget-monthly.index',
    ]) &&
    (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
        ? 'active'
        : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#Financial-Lists" href="#">
        <i class="fa fa-chart-line"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.Financial Lists')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>

    <ul class="sub-menu collapse
                                     <?php echo e(in_array(Route::currentRouteName(), [
                                        'finance.income-list.index',
                                         'finance.audit-budget-supplier.index',
                                         'finance.trail-balance.index',
                                         'finance.audit-budget-monthly.index',
                                     ]) &&
                                     (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                         ? 'show'
                                         : ''); ?>"
        id="Financial-Lists">

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.income-list.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.income-list.index')); ?>">
                <span class="ms-2"> <?php echo e(helperTrans('finance::finance.incomeList')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.trail-balance.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.trail-balance.index')); ?>">
                <span class="ms-2"> <?php echo e(helperTrans('finance::finance.trail-balance')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.audit-budget-supplier.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.audit-budget-supplier.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.audit-budget-supplier')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.audit-budget-monthly.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.audit-budget-monthly.index')); ?>">
                <span class="ms-2"> <?php echo e(trans('finance::finance.audit-budget-monthly')); ?> </span>
            </a>
        </li>
        
    </ul>
</li>
<li class="collapsed">
    <a class="m-link
                                <?php echo e(in_array(Route::currentRouteName(), [
                                    'finance.sales-analysis.index',
                                    'finance.purchases-analysis.index',
                                    'finance.tax-declaration.index',
                                ]) &&
                                (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                    ? 'active'
                                    : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#tax_reports" href="#">
        <i class="fa fa-chart-bar"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.tax_reports')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>
    <ul class="sub-menu collapse
                                     <?php echo e(in_array(Route::currentRouteName(), [
                                        'finance.sales-analysis.index',
                                        'finance.purchases-analysis.index',
                                        'finance.tax-declaration.index',
                                     ]) &&
                                     (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                         ? 'show'
                                         : ''); ?>"
        id="tax_reports">

        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.sales-analysis.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.sales-analysis.index')); ?>">
                <span class="ms-2"> <?php echo e(helperTrans('finance::finance.sales-analysis')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.purchases-analysis.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.purchases-analysis.index')); ?>">
                <span class="ms-2"> <?php echo e(helperTrans('finance::finance.purchases-analysis')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.tax-declaration.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.tax-declaration.index')); ?>">
                <span class="ms-2"> <?php echo e(helperTrans('finance::finance.tax-declaration')); ?> </span>
            </a>
        </li>
        
    </ul>
</li>
<li class="collapsed">
    <a class="m-link
    <?php echo e(in_array(Route::currentRouteName(), [
        'finance.double-account.index',
        'finance.double-account-statement.index',
    ]) &&
    (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
        ? 'active'
        : ''); ?>"
       data-bs-toggle="collapse" data-bs-target="#double-account-statement" href="#">
        <i class="fa fa-link"></i>
        <span class="ms-2"><?php echo e(__('finance::finance.double_accounts')); ?></span>
        <span class="arrow fa fa-angle-left ms-auto text-end"></span>
    </a>

    <ul class="sub-menu collapse
                                     <?php echo e(in_array(Route::currentRouteName(), [
                                         'finance.double-account.index',
                                         'finance.double-account-statement.index',
                                     ]) &&
                                     (request()->query('status') == null || in_array(request()->query('status'), ['collected', 'refused']))
                                         ? 'show'
                                         : ''); ?>"
        id="double-account-statement">
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.double-account.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.double-account.index')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.double_accounts')); ?> </span>
            </a>
        </li>
        
        
        <li>
            <a class="m-link <?php echo e(Route::currentRouteName() == 'finance.double-account-statement.index' ? 'active' : ''); ?>"
               href="<?php echo e(route('finance.double-account-statement.index')); ?>">
                <span class="ms-2"> <?php echo e(__('finance::finance.double-account-statement')); ?> </span>
            </a>
        </li>
        

    </ul>
</li>
<?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance.blade.php ENDPATH**/ ?>