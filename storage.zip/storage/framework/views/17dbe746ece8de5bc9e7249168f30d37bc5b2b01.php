<form class="row g-3 from-submit-global" method="post" action="<?php echo e(route("employeePermissions.store")); ?>" enctype="multipart/form-data">

    <div class="col-6">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Employee")); ?></label>
        <select class="form-control show-tick ms select2" name="employee_id" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-6">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Permission")); ?> </label>
        <?php echo addUpButton(route('permissions.create'),'permission_id','' ,'title',false); ?>

        <select class="form-control show-tick ms" name="permission_id" id="permission_id" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>


    <div class="col-6">
        <label for="date" class="form-label"><?php echo e(__("hr::hr.permission_date")); ?> </label>
        <input type="date" name="date" class="form-control" data-validation="required" onchange="updateDays()">
    </div>

    <div class="col-6">
        <label for="from_time" class="form-label"><?php echo e(__("hr::hr.permission_from_time")); ?> </label>
        <input type="time" name="from_time" class="form-control" id="from_time" data-validation="required">
    </div>
    <div class="col-6">
        <label for="to_time" class="form-label"><?php echo e(__("hr::hr.permission_to_time")); ?> </label>
        <input type="time" name="to_time" class="form-control" id="to_time" data-validation="required">
    </div>

    <div class="col-6">
        <label for="time" class="form-label"><?php echo e(__("hr::hr.Duration of permission in minutes")); ?></label>
        <input type="number" readonly id="time" name="time" class="form-control" data-validation="required">
    </div>


    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.comments")); ?> </label>
        <textarea name="reason" class="form-control" data-validation="required" rows="4"></textarea>
    </div>

    <div class="col-md-6">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.attached")); ?></label>
        <input type="file"  name="file" class="dropify">
    </div>

    <div class="col-12 modal-footer">
        <?php echo submitButton( route("employeePermissions.store") ); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employeePermissions/create.blade.php ENDPATH**/ ?>