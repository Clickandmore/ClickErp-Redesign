<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__("finance::finance.refused_catch_checks")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance::finance.refused_catch_checks")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="clearfix"></div>
    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            
            <th><?php echo e(__("finance::finance.check_num")); ?></th>
            <th><?php echo e(__("finance::finance.check_value")); ?></th>
            <th><?php echo e(__("finance::finance.check_date")); ?></th>
            <th><?php echo e(__("finance::finance.it_is_from")); ?></th>
            <th><?php echo e(__("finance::finance.bank")); ?></th>
            
            <th><?php echo e(__("finance::finance.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                // {"data": "created_by_id", orderable: false, searchable: false},
                {"data": "check_num", orderable: false, searchable: false},
                {"data": "check_value", orderable: false, searchable: false},
                {"data": "check_date", orderable: false, searchable: false},
                {"data": "debit_account_id", orderable: false, searchable: false},
                {"data": "credit_account_id", orderable: false, searchable: false},
                // {"data": "statement", orderable: false, searchable: false},
                {"data": "actions", orderable: false, searchable: false}
            ];
            <?php
                $bondType = \Nami\Finance\Enums\BondTypes::Qabd->value;
                $status = \Nami\Finance\Enums\BondCheckStatusEnum::RefuseQabd->value;
                $routeUrl = route('finance.catch-checks-data.index', [
                     'bond_type' => $bondType,
                     'status' => $status
                ]);
            ?>
            console.log("Route URL:", <?php echo json_encode($routeUrl); ?>);
            showDataTable("<?php echo $routeUrl; ?>", columns);
        });
    </script>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/refused-catch-checks/index.blade.php ENDPATH**/ ?>