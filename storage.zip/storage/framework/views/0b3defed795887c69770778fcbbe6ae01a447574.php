<script src="<?php echo e(asset('site')); ?>/assets/js/swiper-bundle.min.js"></script>
<script src="<?php echo e(asset('site')); ?>/assets/js/main.js"></script>
<script src="<?php echo e(asset('site')); ?>/assets/js/app.js?v=<?php echo e(time()); ?>"></script>

<script src="<?php echo e(asset('site')); ?>/assets/js/filepond.min.js"></script>
<script>
    $(document).ready(function () {
        $('.supportBtn').click(function () {
            $('.links').slideToggle(300);
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/vendor/toster/js/jquery.toast.js"></script>
<script src="<?php echo e(asset('admin')); ?>/assets/js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script src="<?php echo e(asset('site')); ?>/assets/js/bs-stepper.js?v=<?php echo e(time()); ?>"></script>

<script>
    $(document).ready(function () {
        $('.supportBtn').click(function () {
            $('.links').slideToggle(300);
        });
    });

    document.getElementById('close-ad').onclick = function () {
        document.getElementById('ad-popup').style.display = 'none';
    };

</script>
<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/site/includes/js.blade.php ENDPATH**/ ?>