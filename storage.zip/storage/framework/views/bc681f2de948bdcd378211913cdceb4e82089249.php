<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="branch_admin_id"><?php echo e(__('finance::finance.main account')); ?></label>
            <select id="main_account" name="main_account" class="form-control select2">
                <option value=""><?php echo e(__('finance::finance.choose')); ?></option>
                <?php $__currentLoopData = $main_accounts ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $main_account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($main_account->id); ?>"><?php echo e($main_account->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php echo addButton($createRoute , $addButtonText); ?>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th><?php echo e(__("finance::finance.name")); ?></th>
            <th><?php echo e(__("finance::finance.code")); ?></th>
            <th><?php echo e(__("finance::finance.type")); ?></th>
            <th><?php echo e(__("finance::finance.status")); ?></th>
            <th><?php echo e(__("finance::finance.level")); ?></th>
            <th><?php echo e(__("finance::finance.main account")); ?></th>
            <th><?php echo e(__("finance::finance.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                {"data": "name", orderable: true, searchable: true},
                {"data": "code", orderable: true, searchable: true},
                {"data": "type", orderable: true, searchable: true},
                {"data": "status", orderable: false, searchable: false},
                {"data": "level", orderable: false, searchable: false},
                {"data": "parent_id", orderable: true, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ];

            <?php if(! (auth('admin')->user()->admin_type == \App\Enums\AdminTypeisEnum::Developer->value)): ?>
            columns[3].visible = false;
            <?php endif; ?>







            let table = $("#dataTableObject").DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                ordering: true,
                searching: true,
                iDisplayLength: 10,
                lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
                ajax: {
                    url: "<?php echo e($dataTableRoute); ?>",
                    data: function (response) {
                        response.main_account = $('#main_account').val();
                    }
                },
                columns,
                language: {
                    sProcessing: "<?php echo e(trans('dataTable.sProcessing')); ?>",
                    sLengthMenu: "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                    sZeroRecords: "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                    sInfo: "<?php echo e(trans('dataTable.sInfo')); ?>",
                    sInfoEmpty: "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                    sInfoFiltered: "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                    sSearch: "<?php echo e(trans('dataTable.sSearch')); ?>:",
                    oPaginate: {
                        sFirst: "<?php echo e(trans('dataTable.sFirst')); ?>",
                        sPrevious: "<?php echo e(trans('dataTable.sPrevious')); ?>",
                        sNext: "<?php echo e(trans('dataTable.sNext')); ?>",
                        sLast: "<?php echo e(trans('dataTable.sLast')); ?>"
                    }
                },
                order: [[2, "desc"]]
            });

            $('#main_account').on('change', function () {
                table.ajax.reload();
            });


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/accounting_management/index.blade.php ENDPATH**/ ?>