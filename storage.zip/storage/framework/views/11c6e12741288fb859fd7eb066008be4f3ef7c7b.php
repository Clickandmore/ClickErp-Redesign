<nav class="navbar mainNav navbar-expand-lg">
        <div class="container-fluid">
    <!-- Logo -->
    <a class="navbar-brand" href="<?php echo e(route('site.home.index')); ?>">
        <?php if(isset($settings)): ?>
            <img class="logo" src="<?php echo e(showFile($settings->logo_header)); ?>" alt="Logo"/>
        <?php else: ?>
            <img class="logo" src="<?php echo e(asset('site')); ?>/assets/images/logo.png" alt="Logo"/>
        <?php endif; ?>
    </a>

    <!-- Toggle Btn (Mobile) -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navContent"
            aria-controls="navContent"
            aria-expanded="false"
            aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Nav Items -->
    <div class="collapse navbar-collapse" id="navContent">
          <ul class="navbar-nav align-items-lg-center">
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(route('site.home.index')); ?>"><?php echo e(__("ingaz.home")); ?></a>
            </li>
            <!-- خدماتنا -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"><?php echo e(__("ingaz.our_services")); ?></a>
                <ul class="dropdown-menu">
                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.all-workers.index')); ?>?type=estqdam"> <?php echo e(__("ingaz.recruitment_request_title")); ?>

                        </a>
                    </li>
                     <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.all-workers.index')); ?>?type=estqdam"> <?php echo e(__("ingaz.Labor_transfer_services")); ?>

                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.all-workers.index')); ?>?type=egar"><?php echo e(__("ingaz.labor_rental_request")); ?>

                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.all-workers.index')); ?>?type=transfer"><?php echo e(__("ingaz.Labor_transfer_request")); ?>

                        </a>
                    </li>

                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.daily-lebor-demand.index')); ?>"> <?php echo e(__("ingaz.request_professional_labor")); ?>

                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.renew-contract.index')); ?>"><?php echo e(__("ingaz.renewing_employment_contract")); ?>

                        </a>
                    </li>

                </ul>
            </li>
            <!--سياسات الاستقدام -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#"
                   data-bs-toggle="dropdown"><?php echo e(__("ingaz.recruitment_policies")); ?></a>
                <ul class="dropdown-menu">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('site.visa.index')); ?>">
                            <?php echo e(__("ingaz.visa_issuance")); ?>

                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.select-worker.index')); ?>">
                            <?php echo e(__("ingaz.selection_of_workers")); ?>

                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.all-workers.index')); ?>">
                            <?php echo e(__("ingaz.recruitment_contract")); ?>

                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.arrival-worker.index')); ?>">
                            <?php echo e(__("ingaz.employment_rules_and_regulations")); ?>

                        </a>
                    </li>
                </ul>
            </li>
            <!--عن الاستقدام -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#"
                   data-bs-toggle="dropdown">  <?php echo e(__("ingaz.about_Recruitment")); ?>

                </a>
                <ul class="dropdown-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('site.musaned.index')); ?>"><?php echo e(__("ingaz.musaned_initiative")); ?>

                            <span></span>
                        </a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('site.policies.index')); ?>">
                            <?php echo e(__("ingaz.Policies and laws")); ?>

                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="<?php echo e(route('site.anti-traficking.index')); ?>">
                            <?php echo e(__("ingaz.Avoid_human")); ?><span></span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('site.all-workers.index')); ?>">
                    <?php echo e(__("ingaz.recruitment_request")); ?>

                    <span></span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#"
                   data-bs-toggle="dropdown"><?php echo e(__("ingaz.contact_us")); ?></a>
                <ul class="dropdown-menu">
                    <li class="nav-item">
                        <a class="dropdown-item"
                           href="<?php echo e(route('site.contact-us.index')); ?>">  <?php echo e(__("ingaz.contact_us")); ?></a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('site.support.index')); ?>"><?php echo e(__("ingaz.support")); ?></a>
                    </li>
                </ul>
            </li>

            <?php if(\Illuminate\Support\Facades\Auth::guard('web')->check()): ?>
                <!-- Account -->
                <li class="nav-item dropdown userMenu">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <img class="userImg me-2" src="<?php echo e(asset('site')); ?>/assets/images/avatar.webp" alt="User"/>
                        <?php echo e(__("ingaz.my_account")); ?>

                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('site.profile.index')); ?>"><i
                                    class="fa-solid fa-user me-1"></i>
                                <?php echo e(__("ingaz.recruitment_requests")); ?>

                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('site.notifications.index')); ?>"><i
                                    class="fas fa-bell me-1"></i>
                                <?php echo e(__("ingaz.notifications")); ?>

                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('site.logout.index')); ?>"><i
                                    class="fas fa-power-off me-1"></i> <?php echo e(__("ingaz.logout")); ?>

                            </a>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
            <!-- Language -->
            <li class="nav-item dropdown language">
                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                    <i class="fa-solid fa-globe me-2"></i>
                </a>
                <ul class="dropdown-menu">
                    <?php if(app()->getLocale() === 'ar'): ?>
                        
                        <li>
                            <a class="dropdown-item"
                               href="<?php echo e(LaravelLocalization::getLocalizedURL('en', null, [], true)); ?>">
                                <img src="https://flagcdn.com/w40/us.png" alt=""> English
                            </a>
                        </li>
                    <?php else: ?>
                        
                        <li>
                            <a class="dropdown-item"
                               href="<?php echo e(LaravelLocalization::getLocalizedURL('ar', null, [], true)); ?>">
                                <img src="https://flagcdn.com/w40/sa.png" alt=""> عربي
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
           <li class="nav-item">
              <a class="nav-link" href="complaint.html" title="إضافة شكوى">
                <i class="fa-solid fa-comment-dots me-3 fs-5"></i>
              </a>
            </li>

            <?php if(!\Illuminate\Support\Facades\Auth::guard('web')->check()): ?>
                <!-- Login Btn -->
                <li class="nav-item d-lg-block">
                    <a class="login-btn" href="<?php echo e(route('site.login.index')); ?>"><?php echo e(__("ingaz.login")); ?><span></span></a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
    </div>
</nav>
<div class="news-ticker">
    <marquee id="news-marquee">
        <i class="fa-solid fa-bell mx-2"></i>
        <?php echo e(__("ingaz.last_news")); ?>

        <?php $__empty_1 = true; $__currentLoopData = $fastnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fastnew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <span>|</span>
            <?php echo e($fastnew->title); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            : إطلاق باقات جديدة لاستقدام العمالة المنزلية
            <span>|</span> وصول دفعات جديدة من العمالة الماهرة من الفلبين والهند
            <span>|</span> عروض خاصة للعملاء الجدد بمناسبة افتتاح الفرع الجديد
            <span>|</span> توفير كوادر طبية وتمريضية مؤهلة بعقود ميسّرة
            <span>|</span> استقدام سائقين مهنيين بخبرة عالية لجميع أنحاء المملكة
            <span>|</span> بدء برنامج متابعة وضمان ما بعد الاستقدام
            <span>|</span> توفير عاملات منزليات مدرّبات وفق أعلى المعايير
            <span>|</span> توقيع اتفاقيات جديدة مع مكاتب استقدام خارجية معتمدة
            <span>|</span> دعم خاص للعائلات في شهر رمضان بخدمات استقدام سريعة
        <?php endif; ?>

    </marquee>
</div>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/site/layouts/header.blade.php ENDPATH**/ ?>