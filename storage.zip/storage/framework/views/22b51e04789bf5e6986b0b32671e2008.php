<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php echo addButton($createRoute , $addButtonText, 'btn-success',false); ?>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead class="thead-inverse">
        <tr>
            <th><?php echo e(__('hr::hr.SL')); ?></th>
            <th><?php echo e(__("hr::hr.Employee")); ?></th>
            <th><?php echo e(__("hr::hr.payment method")); ?></th>
            <th><?php echo e(__("hr::hr.value")); ?> </th>
            <th> <?php echo e(__("hr::hr.date")); ?></th>
            <th> <?php echo e(__("hr::hr.file")); ?></th>
            <th class="notPrintable"> <?php echo e(__("hr::hr.Installments and payments")); ?></th>
            <th class="notPrintable"><?php echo e(__("hr::hr.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>

    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <?php echo $__env->make("hr::hr.employees.advances._js_allowance", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {"data": "employee_id", orderable: false, searchable: false},
                {"data": "payment_method", orderable: false, searchable: true},
                {"data": "value", orderable: false, searchable: true},
                {"data": "date", orderable: false, searchable: true},
                {"data": "file", orderable: false, searchable: true},
                {"data": "payments", orderable: false, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ];
            showDataTable("<?php echo e($dataTableRoute); ?>", columns);


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employeeAdvances/index.blade.php ENDPATH**/ ?>