<!-- Required meta tags -->
<meta charset="utf-8" />
<meta
    name="viewport"
    content="width=device-width, initial-scale=1, user-scalable=no, shrink-to-fit=no"/>
<meta name="theme-color" content="#000000" />

<!-- SEO: Description, Keywords, Author, and Robots -->
<meta
    name="description"
    content="بلاتينيوم الشرقية للاستقدام تقدم خدمات استقدام العمالة المنزلية والمهنية من مختلف الجنسيات، مع ضمان الجودة والالتزام بالمعايير."/>
<meta
    name="keywords"
    content="بلاتينيوم الشرقية, استقدام, استقدام عمالة, استقدام العمالة المنزلية, استقدام مهني, شركة استقدام, مكتب استقدام"/>
<meta name="author" content="شركة بلاتينيوم الشرقية للاستقدام" />
<meta name="robots" content="index, follow" />

<!-- Open Graph Data for Social Media -->
<meta property="og:title" content="بلاتينيوم الشرقية للاستقدام" />
<meta
    property="og:description"
    content="شركة رائدة في مجال استقدام العمالة المنزلية والمهنية، بخدمات موثوقة تلبي احتياجات الأفراد والأعمال."/>
<meta property="og:image" content="assets/images/fav.svg" />
<meta property="og:url" content="https://platinum-esharqiya.com" />
<meta property="og:type" content="website" />

<!-- Twitter Card Data -->
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="بلاتينيوم الشرقية للاستقدام" />
<meta
    name="twitter:description"
    content="نوفّر خدمات استقدام العمالة المنزلية والمهنية بأعلى معايير الجودة والموثوقية."/>
<meta name="twitter:image" content="assets/images/fav.svg" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/site/includes/meta.blade.php ENDPATH**/ ?>