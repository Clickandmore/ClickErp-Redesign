<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.employeeAttendances')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance.clients")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-3 my-2">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Employee")); ?> </label>
        <select class="form-control show-tick ms select2" name="employee_id" id="employeeId" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?> <?php echo e(__("hr::hr.Employee")); ?></option>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-3 my-2">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.type")); ?> </label>
        <select class="form-control show-tick ms select2" name="type" id="type" data-validation="required">
            <?php echo getEnumData($employee_attendances_type_full); ?>

        </select>
    </div>
    <div class="col-2 my-2">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.date")); ?> </label>
        <input class="form-control" type="date" name="date" id="date">
    </div>
    <div class="col-2 my-2">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Choose the month")); ?> </label>
        <input class="form-control" type="month" name="month" id="month">
    </div>
</div>

<?php echo addButton(route("employeeAttendances.create") , __('hr::hr.employeeAttendances')); ?>



    <div class="col-12">
        <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('hr::hr.SL')); ?></th>
            <th><?php echo e(__("hr::hr.Employee")); ?></th>
            <th>  <?php echo e(__("hr::hr.date")); ?></th>
            <th> <?php echo e(__("hr::hr.time attendance")); ?></th>
            <th> <?php echo e(__("hr::hr.Check-out time")); ?></th>
            <th> <?php echo e(__("hr::hr.Month and year")); ?></th>
            <th> <?php echo e(__("hr::hr.type")); ?></th>
            <th> <?php echo e(__("hr::hr.created_by_id")); ?></th>
            <th><?php echo e(__("hr::hr.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            var table = $('#dataTableObject').DataTable({
                "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "الكل"] ],
                "processing": true,
                "serverSide": true,
                "sort": false,
                "ajax": {
                    "url": "<?php echo e(route('employeeAttendances.index')); ?>",
                    "type": "GET",
                    "data": function (d) {
                        d.employee_id = $('#employeeId').val();
                        d.type = $('#type').val();
                        d.date = $('#date').val();
                        d.month_year = $('#month').val();
                    }
                },
                "columns": [
                    {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                    {"data": "employee_id", orderable: false, searchable: true},
                    {"data": "date", orderable: false, searchable: true},
                    {"data": "attendance_time", orderable: false, searchable: false},
                    {"data": "leave_time", orderable: false, searchable: false},
                    {"data": "month_year", orderable: false, searchable: false},
                    {"data": "type", orderable: false, searchable: true},
                    {"data": "created_by_id", orderable: false, searchable: true},
                    {"data": "actions", orderable: false, searchable: false}
                ],
            });

            $('#filter').click(function() {
                table.draw();
            });

            $('#employeeId, #type').on('keyup change', function () {
                table.column(1).search($('#employeeId').val()).draw();
                table.column(6).search($('#type').val()).draw();
            });
            $('#date').on('change', function () {
                var searchValue = $(this).val();
                table.column(2).search(searchValue).draw();
            });
            $('#month').on('change', function () {
                var searchValue = $(this).val();
                table.column(2).search(searchValue).draw();
            });
        });
    </script>
    <script>
        function showFields() {
            var attendanceType = document.getElementById("attendance-type").value;
            if (attendanceType == 1) {
                document.getElementById("attendance-time").style.display = "block";
                document.getElementById("departure-time").style.display = "block";
            } else if (attendanceType == 2) {
                document.getElementById("attendance-time").style.display = "block";
                document.getElementById("departure-time").style.display = "none";
            } else {
                document.getElementById("attendance-time").style.display = "none";
                document.getElementById("departure-time").style.display = "none";
            }
        }

        function convertToMonthYear(dateValue) {
            var date = new Date(dateValue);
            var monthYear = (date.getMonth() + 1).toString().padStart(2, '0') + "-" + date.getFullYear();
            document.getElementsByName("month_year")[0].value = monthYear;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employeeAttendances/index.blade.php ENDPATH**/ ?>