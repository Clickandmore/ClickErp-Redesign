<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="form-check form-switch">
        <label class="form-check-label" id="switchFilterLabel"
               for="switchFilter"><?php echo e(__('finance::finance.advanced_search')); ?></label>
        <input class="form-check-input" type="checkbox" role="switch" id="switchFilter">
    </div>
    <div class="row mb-3 filter_data" style="display: none">
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.from_date")); ?></label>
                <input class="form-control" name="from_date" id="from_date" type="date">
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.to_date")); ?></label>
                <input class="form-control" name="to_date" id="to_date" type="date">
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.cost_center")); ?></label>
                <select name="cost_center_id" id="cost_center_id" class="form-control select2">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $cost_centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost_center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cost_center->id); ?>"><?php echo e($cost_center->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.it_is_for")); ?></label>
                <select name="credit_account_id" id="credit_account_id" class="form-control select2">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 mt-2">
            <div class="form-group">
                <label><?php echo e(__("finance::finance.bank")); ?></label>
                <select name="debit_account_id" id="debit_account_id" class="form-control select2">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            
            <th><?php echo e(__("finance::finance.Voucher Number")); ?></th>
            <th><?php echo e(__("finance::finance.Voucher Date")); ?></th>
            <th><?php echo e(__("finance::finance.check_num")); ?></th>
            <th><?php echo e(__("finance::finance.check_value")); ?></th>
            <th><?php echo e(__("finance::finance.check_date")); ?></th>
            <th><?php echo e(__("finance::finance.it_is_from")); ?></th>
            <th><?php echo e(__("finance::finance.bank")); ?></th>
            
            <th><?php echo e(__("finance::finance.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let table = $("#dataTableObject").DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                ordering: true,
                searching: true,
                iDisplayLength: 10,
                lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
                ajax: {
                    url: "<?php echo e($dataTableRoute); ?>",
                    data: function (response) {
                        response.from_date = $('#from_date').val();
                        response.to_date = $('#to_date').val();
                        response.cost_center_id = $('#cost_center_id').val();
                        response.debit_account_id = $('#debit_account_id').val();
                        response.credit_account_id = $('#credit_account_id').val();
                    }
                },
                columns: [
                    {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                    // {"data": "created_by_id", orderable: false, searchable: false},
                    {"data": "con_number", orderable: false, searchable: true},
                    {"data": "con_date", orderable: false, searchable: true},
                    {"data": "check_num", orderable: false, searchable: true},
                    {"data": "check_value", orderable: false, searchable: true},
                    {"data": "check_date", orderable: false, searchable: true},
                    {"data": "debit_account_id", orderable: false, searchable: true},
                    {"data": "credit_account_id", orderable: false, searchable: true},
                    // {"data": "statement", orderable: false, searchable: false},
                    {"data": "actions", orderable: false, searchable: false}
                ],
                language: {
                    sProcessing: "<?php echo e(trans('dataTable.sProcessing')); ?>",
                    sLengthMenu: "<?php echo e(trans('dataTable.sLengthMenu')); ?>",
                    sZeroRecords: "<?php echo e(trans('dataTable.sZeroRecords')); ?>",
                    sInfo: "<?php echo e(trans('dataTable.sInfo')); ?>",
                    sInfoEmpty: "<?php echo e(trans('dataTable.sInfoEmpty')); ?>",
                    sInfoFiltered: "<?php echo e(trans('dataTable.sInfoFiltered')); ?>",
                    sSearch: "<?php echo e(trans('dataTable.sSearch')); ?>:",
                    oPaginate: {
                        sFirst: "<?php echo e(trans('dataTable.sFirst')); ?>",
                        sPrevious: "<?php echo e(trans('dataTable.sPrevious')); ?>",
                        sNext: "<?php echo e(trans('dataTable.sNext')); ?>",
                        sLast: "<?php echo e(trans('dataTable.sLast')); ?>"
                    }
                },
                order: [[2, "desc"]]
            });
            $('#from_date, #to_date , #cost_center_id,#debit_account_id,#credit_account_id').change(function () {
                table.ajax.reload();
            });
        });
    </script>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/finance/src/../resources/views/finance/catch-checks/index.blade.php ENDPATH**/ ?>