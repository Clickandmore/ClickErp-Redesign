
<div class="modal fade" data-bs-backdrop="static" id="createModal" tabindex="-1" aria-labelledby="exampleModalLgLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-scrollable <?php echo e((isset($modalType))? $modalType:"modal-xl"); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4" id="exampleModalLgLabel"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body custom_scroll"></div>
            
        </div>
    </div>
</div>


<div class="modal fade" data-bs-backdrop="static" id="upCreateModal" tabindex="-1" aria-labelledby="exampleModalLgLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-scrollable <?php echo e((isset($modalType))? $modalType:"modal-xl"); ?>">
        <div class="modal-content" style="height: auto;">
            <div class="modal-header">
                <h5 class="modal-title h4" id="exampleModalLgLabel"></h5>
                <input type="hidden" name="popup_id" id="popup_id" value="">
                <input type="hidden" name="up_id" id="item_add_id" value="">
                <input type="hidden" name="up_name_id" id="item_add_name_id" value="">
                <button type="button" class="btn-close upCreateModalClose" ></button>
            </div>
            <div class="modal-body custom_scroll"></div>
            
        </div>
    </div>
</div>


 <!-- Modal for Image Cropping -->
 
<?php /**PATH /mnt/Data/test/resources/views/nami/layout/inc/global_modals.blade.php ENDPATH**/ ?>