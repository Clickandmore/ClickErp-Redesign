<div class="row g-2">
    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.name")); ?>   <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <input type="text" name="name" class="form-control" data-validation="required" onchange="checkOther()">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.Employee Code")); ?>   <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <input type="text" name="code" class="form-control" data-validation="required" onchange="checkOther()">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.the address")); ?>   <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <input type="text" name="address" class="form-control" data-validation="required" onchange="checkOther()">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.phone")); ?>   <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <input type="number" name="phone" class="form-control" data-validation="required,number" onchange="checkOther()">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.date of birth")); ?>   <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <input type="date" name="birthday" class="form-control" data-validation="required" onchange="checkOther()">
    </div>


    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.ID Number")); ?>  <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <input type="number" name="national_num" class="form-control" data-validation="required,number" onchange="checkOther()">
    </div>


    <div class="col-md-6 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.nationality")); ?>   <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <select class="form-control show-tick ms select2" name="country_id" data-validation="required" onchange="checkOther()">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?> <?php echo e(__("hr::hr.nationality")); ?></option>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-6 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Email")); ?>   <i class="fa fa-asterisk text-danger fs-10"></i> </label>
        <input type="text" name="email" class="form-control" data-validation="required" onchange="checkOther()">
    </div>

    <div class="col-md-6 col-12 mt-5">
        <label class="form-check-label">
            <input type="checkbox" id="createAdminToggle" class="form-check-input">
            <?php echo e(__("hr::hr.Create admin account")); ?>

            <input type="hidden" name="create_admin_account" id="createAdminAccountInput" value="0">
        </label>
    </div>

    <div class="col-md-6 col-12" id="passwordField" style="display: none;">
        <label for="TextInput" class="form-label"> <?php echo e(__("crm.password")); ?> </label>
        <input type="password" name="password" class="form-control">
    </div>


    <div class="col-md-12 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.image")); ?></label>
        <input type="file"  name="image" class="dropify">
    </div>

</div>

<?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employees/create/step1.blade.php ENDPATH**/ ?>