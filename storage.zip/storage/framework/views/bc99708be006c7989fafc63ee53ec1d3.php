<div class="row g-2">
    <div class="col-12">
        <table id="myDataTable_no_filter" class="table align-middle card-table my-2">
            <thead>
            <tr>
                <th></th>
                    <th><?php echo e(__("hr::hr.name")); ?></th>
                    <th><?php echo e(__("hr::hr.Options")); ?> </th>
                <th><?php echo e(__("hr::hr.actions")); ?></th>
            </tr>
            </thead>
            <tbody id="json_array" class="content" data-mfield-options='{"section": ".y-group","btnAdd":"#btnAdd-2","btnRemove":".btnRemove"}'>
                <?php if(count($obj->files) > 0): ?>
                    <?php $__currentLoopData = $obj->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="y-group">
                            <td> </td>
                                <td>
                                    <input type="text" name="title[]" value="<?php echo e($files->title); ?>" class="form-control">
                                    <input type="hidden" name="attachment_id[]" value="<?php echo e($files->id); ?>" class="form-control">
                                </td>
                                <td>
                                    <input type="file" name="file[]" class="dropify" data-allowed-file-extensions="jpg jpeg png gif"
                                        data-max-file-size="2M" data-show-remove="true" data-default-file="<?php echo e(showFile($files->file)); ?>">
                                </td>
                            <td>
                                <i class="fa fa-plus-circle" id="btnAdd-2"></i>
                                
                                    <i class="fa fa-trash-o btnRemove"></i>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr class="y-group">
                        <td> </td>
                            <td>
                                <input type="text" name="title[]" class="form-control">
                                <input type="hidden" name="attachment_id[]" class="form-control">
                            </td>
                            <td>
                                <input type="file" name="file[]" class="dropify" data-allowed-file-extensions="jpg jpeg png gif"
                                    data-max-file-size="2M" data-show-remove="true">
                            </td>
                        <td>
                            <i class="fa fa-plus-circle" id="btnAdd-2"></i>
                            <i class="fa fa-trash-o btnRemove"></i>
                        </td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employees/edit/step3.blade.php ENDPATH**/ ?>