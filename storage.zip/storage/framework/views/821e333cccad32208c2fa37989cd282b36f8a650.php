<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>"
      enctype="multipart/form-data">
    <div class="col-md-2">
        <label for="code" class="form-label"> <?php echo e(__("finance::finance.Voucher Number")); ?> </label>
        <input type="text" value="<?php echo e($lastId); ?>" name="code" class="form-control" data-validation="required" readonly>
    </div>
    <div class="col-md-3">
        <label for="date" class="form-label"><?php echo e(__("finance::finance.Voucher Date")); ?> </label>
        <input type="date" id="date" name="date" class="form-control" value="<?php echo e(date("Y-m-d")); ?>" data-validation="required">
    </div>

    <div class="col-md-2">
        <label for="bond_book_num" class="form-label"><?php echo e(__("finance::finance.Bookkeeping Number")); ?></label>
        <input type="text" id="bond_book_num" name="bond_book_num" class="form-control">
    </div>

    <div class="col-md-2">
        <label for="value" class="form-label"> <?php echo e(__("finance::finance.Amount")); ?> </label>
        <input type="number" min="0.01" step="any" name="value" id="value" value="1" class="form-control" data-validation="required" oninput="calculateTax()">
    </div>
    <!-- New Tax Fields -->
    <div class="col-md-3">
        <label for="is_tax" class="form-label"><?php echo e(__("finance::finance.Is there a tax?")); ?>:</label>
        <div>
            <input type="radio" id="is_tax_yes" value="1" name="is_tax" onchange="toggleTaxFields()"> <?php echo e(__("finance::finance.Yes")); ?>

            <input type="radio" id="is_tax_no" value="0" name="is_tax" onchange="toggleTaxFields()" checked> <?php echo e(__("finance::finance.No")); ?>

        </div>
    </div>
    <div id="tax-fields" style="display: none;" class="col-12">
        <div class="row">
            <div class="col-md-4">
                <label for="tax_setting_id" class="form-label"><?php echo e(__("finance::finance.Tax Account")); ?>:</label>
                <?php echo addUpButton(route('finance.tax-setting.create'),'tax_rate_revenue' ,false, 'name'); ?>

                <select name="tax_setting_id" id="tax_setting_id" class="form-control">
                    <option value=""><?php echo e(__("finance::finance.choose")); ?></option>
                    <?php $__currentLoopData = $tax_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" data-account-id="<?php echo e($item->account_id); ?>" data-value="<?php echo e($item->value); ?>" <?php echo e(isset($tax_rate_revenue) && $tax_rate_revenue->value == $item->id ? "selected" : ""); ?>>
                            <?php echo e($item->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="hidden" id="tax_account_id" name="tax_account_id" value="">
            </div>
            <div class="col-md-4">
                <label for="tax_rate" class="form-label"><?php echo e(__("finance::finance.Tax rate")); ?>:</label>
                <input type="number" name="tax_rate" value="" id="tax_rate" class="form-control" oninput="calculateTax()">
            </div>

            <div class="col-md-4">
                <label for="tax_amount" class="form-label"><?php echo e(__("finance::finance.Tax amount")); ?>:</label>
                <input type="number" name="tax_amount" id="tax_amount" class="form-control" readonly>
            </div>
            <div class="col-md-4">
                
                <input type="hidden" name="net" id="net" class="form-control" readonly>
            </div>
        </div>
    </div>

    <div class="col-4">
        <label for="credit_account_id" class="form-label"><?php echo e(__("finance::finance.From Account")); ?> : </label>
        <label for="TextInput" class="form-label"> <?php echo e(__('finance::finance.Directory account')); ?>

            <?php echo addUpButton(route('finance.accounts.create'),'credit_account_id' ,false, 'name'); ?></label>
        <select class="form-control show-tick ms select2" id="credit_account_id" name="credit_account_id" data-validation="required">
            <?php echo showSelectElement($accounts,"name"); ?>

        </select>
    </div>

    <div class="col-4">
        <label for="TextInput" class="form-label"> <?php echo e(__("finance::finance.fn-cost-centers")); ?> : </label>
        <label for="TextInput" class="form-label">
            <?php echo addUpButton(route('finance.cost-centers.create'),'cost_center_id' ,false, 'title'); ?></label>
        <select class="form-control show-tick ms select2" name="cost_center_id" id="cost_center_id"
        <?php if(isset($cost_center_required) && $cost_center_required->value == "on"): ?>
            data-validation="required"
        <?php endif; ?>>
            <?php echo showSelectElement($costCenters,"title"); ?>

        </select>
        <input type="hidden" name="cost_center_required" value="<?php echo e((isset($cost_center_required) && $cost_center_required->value == "on") ? "on" : "off"); ?>">

    </div>

    <div class="col-4">
        <label for="payment_type" class="form-label"> <?php echo e(__("finance::finance.Payment Method")); ?> </label>
        <select class="form-control" name="payment_type" id="payment_type" onchange="getPaymentTypeHtml('qabd');"
                data-validation="required">
            <?php echo getEnumData($bond_payment_type , "bond_payment_type"); ?>

        </select>

    </div>

    <div class="col-12  row g-3" id="content-div">

    </div>

    <div class="col-6">
        <label for="bs_maxlength_textarea" class="form-label"><?php echo e(__("finance::finance.statement")); ?> </label>
        <textarea type="text" name="statement" data-validation="required" class="form-control form-control-lg mb-1" id="bs_maxlength_textarea"
                  rows="5"></textarea>
    </div>

    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__("finance::finance.Document Image")); ?></label>
        <input type="file" name="file" class="dropify">
    </div>


    <div class="col-12 modal-footer">
        <?php echo submitButton($storeRoute); ?>

        <?php echo closeButton(); ?>

    </div>

</form>

<script>
    $(document).ready(function() {
        function setTaxRate() {
            var selectedOption = $('#tax_setting_id option:selected');
            var dataValue = selectedOption.data('value');
            var accountId = selectedOption.data('account-id');
            $('#tax_account_id').val(accountId);
            $('#tax_rate').val(dataValue);
            calculateTax();
        }

        $('#tax_setting_id').on('change', function() {
            setTaxRate();
        });
        setTaxRate();
    });
</script>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/bond/qabd/create.blade.php ENDPATH**/ ?>