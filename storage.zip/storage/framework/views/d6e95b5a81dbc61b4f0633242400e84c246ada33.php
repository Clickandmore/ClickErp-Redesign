<?php if($result->count() > 0 ): ?>
    <div class="col d-flex justify-content-end no-print" id="print_excel">
        <button onclick="handlePrint()" class="btn btn-success ml-2"><i class="fa fa-print"></i></button>
        <button id="toExcel" class="btn btn-warning"><i class="fa fa-file-excel-o"></i></button>
    </div>

    <?php
        $fromDate = request('from_date') ?? optional($result->first())->date;
        $toDate = request('to_date') ?? optional($result->last())->date;
    ?>
    <div id="print_section" class="print-content">
        <?php echo $__env->make('print-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="text-center" style="margin: 10px auto">
            <h5>
                <?php echo e(__("finance.purchases-analysis")); ?>

                <?php echo e($fromDate ? __('finance::finance.from_date') . ' ' . $fromDate : ''); ?>

                <?php echo e($toDate ? __('finance::finance.to_date') . ' ' . $toDate : ''); ?>

            </h5>
        </div>
        <table class="table table-hover table-bordered table-striped" id="toExcelTable" style="width:100%">
            <thead>
            <tr class="header">
                <th scope="col"><?php echo e(__("finance::finance.bill_number")); ?> </th>
                <th scope="col"><?php echo e(__("finance::finance.date")); ?> </th>
                <th scope="col"><?php echo e(__("finance::finance.vendor")); ?> </th>
                <th scope="col"><?php echo e(__("finance::finance.tax_number")); ?> </th>
                <th scope="col"><?php echo e(__("finance::finance.value_under_tax")); ?> </th>
                <th scope="col"><?php echo e(__("finance::finance.tax_value")); ?> </th>
                <th scope="col"><?php echo e(__("finance::finance.bill_value")); ?> </th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->id); ?></td>
                    <td><?php echo e($row->date); ?></td>
                    <td><?php echo e(@$row->supplier->name); ?></td>
                    <td><?php echo e(@$row->supplier->tax_number); ?></td>
                    <td><?php echo e($row->total_item); ?></td>
                    <td><?php echo e($row->tax_value); ?></td>
                    <td><?php echo e($row->final_total); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td colspan="4"><?php echo e(__('finance::finance.Total')); ?></td>
                <td><?php echo e($result->sum(function($row) {return $row->total_item;} )); ?></td>
                <td><?php echo e($result->sum('tax_value')); ?></td>
                <td><?php echo e($result->sum('final_total')); ?></td>
            </tr>

            </tbody>
        </table>
    </div>
<?php else: ?>
    <div role="alert" class="alert alert-danger text-center"> <?php echo e(__('finance::finance.no_data_found')); ?></div>

    <br>
<?php endif; ?>


<script src="<?php echo e(asset("plugins")); ?>/exelJs/dist/tableToExcel.517b1af9.js"></script>
<script>
    var button = document.querySelector('#toExcel');
    button.addEventListener('click', function (e) {
        var table = document.querySelector('#toExcelTable');
        TableToExcel.convert(table);
    });
</script>
<script>
    function handlePrint() {
        const printContent = document.getElementById('print_section').innerHTML;
        const styleSheet = `
            <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/assets/css/bootstrap.rtl.min.css">
            <style>
                body {
                    direction: rtl;
                    font-family: "Arial", sans-serif;
                    padding: 20px;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 6px 8px;
                    text-align: center;
                    vertical-align: middle;
                    font-size: 12px;
                }
                h5 {
                    text-align: center;
                    margin-bottom: 20px;
                }
                @media  print {
                    html, body {
                        width: 95%;
                        height: 100%;
                        margin: auto;
                        padding: 0;
                        overflow: visible;
                    }
                }
            </style>
        `;

        const printWindow = window.open('', '_blank');

        printWindow.document.open();
        printWindow.document.write(`
            <html>
                <head>
                    <title><?php echo e(__("finance::finance.sales-analysis")); ?></title>
                    ${styleSheet}
                </head>
                <body>
                    ${printContent}
                    <script>
                        window.onload = function() {
                            window.print();
                        };
                        window.onafterprint = function() {
                            window.close();
                        };
                    <\/script>
                </body>
            </html>
        `);
        printWindow.document.close();
    }
</script>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/purchases_analysis/result.blade.php ENDPATH**/ ?>