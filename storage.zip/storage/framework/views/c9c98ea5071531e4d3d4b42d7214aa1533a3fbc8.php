<?php $__env->startSection("style"); ?>


<link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/vendor/tree_collapse/tree-co.css">
<style>
    .my-swal {
        background-color: #f8d7da !important; /* Example background color */
    }
    .price {
        border: 0 !important;
        font-weight: bold;
    }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php

    function addButtonTree($route,$fullText="")
    {
        return '<button type="button" class="btn btn-success addButton  mx-1" data-bs-toggle="modal" data-bs-target="#createModal"
                   model-route="' . $route . '" model-title="' . $fullText . '">
               <i class="fa fa-plus-circle"></i>
            </button>';
    }
    function createTreeView($array,$createRoute,$constraints)
    {
        $sumDebtor = $sumCreditor = 0;
        $price = "";
        foreach ($array as $row) {
            if ($row->allChildrenIDs){
                // Calculate sum for all children
                foreach ($row->allChildrenIDs as $childId) {
                    if (isset($constraints[$childId])) {
                        $sumDebtor += $constraints[$childId]['debtor_value'] ?? 0;
                        $sumCreditor += $constraints[$childId]['creditor_value'] ?? 0;
                    }
                }
                $finalBalance = abs($sumDebtor - $sumCreditor);
                $price = "<span class='price'> رصيد ".$finalBalance."</span>";
            }
            if (count($row->childrenRecursive) > 0 ) {
                echo '<li>';
                echo '   <span>
                             <a  data-bs-toggle="collapse" href="#Page-' . $row->id . '" aria-expanded="true" aria-controls="Page-' . $row->id . '">
                             <i class="collapsed"><i class="fa fa-folder"></i></i>
                             <i class="expanded"><i class="fa fa-folder-open"></i></i> ' . $row->id . ' /
                                   <i class="fa fa-book"></i>  ' . $row->title .$price. '</a>'  ." ";
//                echo ($row->status == "debtor") ? "<b style='color: red'> (مدين) </b>" : "<b style='color: blue'> (دائن)  </b>";
                echo addButtonTree($createRoute."?parent_id=".$row->id).editButton(route("finance.cost-centers.edit",$row->id),$row->title)." ".deleteButton(route("finance.cost-centers.destroy",$row->id),$row->children->count() > 0 ? 1 : 0);
                echo '   </span>';
                echo '   <ul>
                           <div id="Page-' . $row->id . '" class="collapse in show">';
                createTreeView($row->childrenRecursive,$createRoute,$constraints);
                echo '      </div>
                         </ul>
                      </li>';
            }
            else {
                $finalBalance = 0;
                $sumDebtor = 0;
                $sumCreditor = 0;
                if (isset($constraints[$row->id])){
                    $sumDebtor += $constraints[$row->id]['debtor_value'] ?? 0;
                    $sumCreditor += $constraints[$row->id]['creditor_value'] ?? 0;
                    $finalBalance = abs($sumDebtor - $sumCreditor);
                    $price = "<span class='price'> رصيد ".$finalBalance."</span>";
                }
                else{
                    $finalBalance = 0;
                    $sumDebtor = 0;
                    $sumCreditor = 0;
                    $price = "<span class='price'> رصيد ".$finalBalance."</span>";
                }
                echo '<li>
                           <span> <i class="fa fa-database"></i> ' . $row->id . ' / <i class="fa fa-book"></i>  ' . $row->title .$price." ";
//                echo ($row->status == "debtor") ? "<b style='color: red'> (مدين) </b>" : "<b style='color: blue'> (دائن)  </b>";
                echo addButtonTree($createRoute."?parent_id=".$row->id). editButton(route("finance.cost-centers.edit",$row->id),$row->title)." ".deleteButton(route("finance.cost-centers.destroy",$row->id),$row->children->count() > 0 ? 1 : 0);
                echo '</span> ';
                echo ' </li>';
            }
        }// end foreach
    }
    //-------------------------------------------------------------------------------------------
    ?>
    <?php echo addButton($createRoute , $addButtonText); ?>


    <div class="col-md-12 " id="option_search">

        <div class="col-md-4 col-md-offset-4 col-sm-6 col-xs-12">
            <input type="text" class="form-control" id="filterUl" style="height: 40px;" placeholder="بحــــث"/>
        </div>
        <div class="clearfix"></div>
        <div class="tree searchTree">
            <ul>
                <li><span><a data-bs-toggle="collapse" href="#Web" aria-expanded="true" aria-controls="Web">
                            <i class="collapsed"><i class="fa fa-folder"></i></i>
                            <i class="expanded"><i class="fa fa-folder-open"></i></i> <?php echo e($bladeTitle); ?> </a>
                            </span>
                    <div id="Web" class="collapse in show">
                        <!--------------------------------------------->
                        <ul>
                            <?php createTreeView($accountTree,$createRoute,$constraints);?>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>

    </div>

    













<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>














<!-- bootstrap datepicker -->


<script>
    
    
    
</script>
<script>
    $('#filterUl').keyup(function () {
        var filter = jQuery(this).val();
        jQuery(".searchTree li").each(function () {
            if (jQuery(this).text().search(new RegExp(filter, "i")) < 0) {
                jQuery(this).hide();
            } else {
                jQuery(this).show();
                jQuery(this).children().show();
            }
        });
    });
</script>
<script>
    function checkAndResetSelect() {
        var checkbox = document.getElementById('checkboxInput');
        if (!checkbox.checked) {
            document.getElementById('parent_id').selectedIndex = null;
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/cost_centers/index.blade.php ENDPATH**/ ?>