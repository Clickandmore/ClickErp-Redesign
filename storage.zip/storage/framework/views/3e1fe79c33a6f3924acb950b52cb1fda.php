<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.salaries')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance.clients")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<form id="search-form" >
    <div class="row">
        <div class="col-3 my-2">
            <label for="month_year" class="form-label"> <?php echo e(__("hr::hr.Choose the month")); ?></label>
            <input class="form-control" type="month" name="month" value="<?php echo e(request()->month); ?>" id="month" data-validation="required">
        </div>
        <div class="col-3 my-2">
            <label class="form-label"><?php echo e(__('hr::hr.Select department')); ?></label>
            <?php echo addUpButton(route('departments.create'),'department','' ,'title',true); ?>

            <select name="department" id="department" class="form-control select2">
                <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</form>

<form class="from-submit-global" method="POST" action="<?php echo e(route("salaries.store")); ?>">
    <?php echo csrf_field(); ?>
    <div class="col-2 my-2 d-none">
        <label for="month_year" class="form-label"><?php echo e(__("hr::hr.Choose the month")); ?></label>
        <input class="form-control" type="month" value="<?php echo e(request()->month); ?>" name="month_year" data-validation="required">
    </div>
    <table class="table" id="table-body">
        <thead>
            <tr>
                <th>
                    <div class="col-12">
                        <input type="checkbox" name="checkbox" value="1">
                    </div>
                </th>
                <th><?php echo e(__('hr::hr.SL')); ?></th>
                <th><?php echo e(__("hr::hr.name")); ?></th>
                <th><?php echo e(__("hr::hr.department")); ?></th>
                <th><?php echo e(__("hr::hr.salary")); ?></th>
                <th><?php echo e(__("hr::hr.Number of days of attendance")); ?></th>
                <th><?php echo e(__("hr::hr.allowances")); ?></th>
                <th><?php echo e(__("hr::hr.sanctions")); ?></th>
                <th><?php echo e(__("hr::hr.insurances")); ?></th>
                <th><?php echo e(__("hr::hr.Tax")); ?></th>
                <th><?php echo e(__("hr::hr.Delays")); ?></th>
                <th><?php echo e(__("hr::hr.Net")); ?></th>
            </tr>
        </thead>
        <tbody id="search-results">
            <?php echo $__env->make('hr::hr.salaries.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tbody>
    </table>
    
        <button type="submit" class="btn btn-primary"><?php echo e(__("hr::hr.Disbursement of salaries")); ?></button>
    
</form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
<script>
    $(document).ready(function () {
        let columns = [
            {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
            {"data": "name", orderable: false, searchable: false},
            {"data": "deparment_id", orderable: false, searchable: false},
            {"data": "salary", orderable: false, searchable: false},
            {"data": "days", orderable: false, searchable: false},
            {"data": "allowances_id", orderable: false, searchable: false},
            {"data": "sanction_id", orderable: false, searchable: false},
            {"data": "delay_id", orderable: false, searchable: false},
            {"data": "net", orderable: false, searchable: false},
        ];
        showDataTable("<?php echo e(route("salaries.index")); ?>", columns);
    });
</script>

<script>
    document.querySelector('input[name="checkbox"]').addEventListener('change', function() {
        var checkboxes = document.querySelectorAll('input[name="checkbox[]"]');
        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = this.checked;
        }
    });
</script>

<script>
    window.onload = function() {
        var input = document.getElementsByName('month')[0];
        input.addEventListener('change', function() {
            var selectedMonth = input.value;
            document.getElementsByName('month_year')[0].value = selectedMonth;
        });
    }

    $(document).ready(function() {
        $('#month, #department').on('change', function(event) {
            event.preventDefault();
            var month = $('#month').val();
            var department = $('#department').val();
            $.ajax({
                url: '<?php echo e(route("salaries.index")); ?>',
                type: 'GET',
                data: { month: month, department: department },
                success: function(response) {
                    $('body #search-results').html(response.table);
                },
                error: function(xhr, status, error) {
                    alert('حدث خطأ: ' + error);
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/salaries/index.blade.php ENDPATH**/ ?>