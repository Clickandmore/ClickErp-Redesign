<style>
    header {
        padding: 12px;

        .tnavbar {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;

            .logo {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 4px;

                img {
                    object-fit: contain;
                    height: 100px;
                    width: 100px;
                    aspect-ratio: 1 / 1;
                    margin: auto;
                }

                p {
                    font-weight: 500;
                }
            }

            .Name {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 4px;
                text-align: center;

                h1 {
                    font-size: 16px;
                    text-transform: uppercase;
                    font-weight: bold;
                    color: #1e9226;
                }

                p {
                    font-weight: 500;
                }
            }
        }

        .line {
            border: 1px solid #1e9226;
        }
    }

    .line_hr {
        border: 1px solid #1e9226;
    }
</style>
<header>
    <div class="tnavbar">
        <div class="logo">
            <?php if(isset($setting_web)): ?>
                <img src="<?php echo e(showFile(@$setting_web->logo_header)); ?>" alt="logo" style="object-fit: contain"/>
                <p>الرقم الضريبي : <?php echo e(@$setting_web->tax_number); ?></p>
            <?php endif; ?>
        </div>
        <div class="Name Ar">
            <?php if(isset($setting_web)): ?>
                <h1> <?php echo e(@$setting_web->translate('ar')->website_name); ?> </h1>
                <h1> <?php echo e(@$setting_web->translate('en')->website_name); ?> </h1>
                <p><?php echo e(__('crm.commercial_registration_number', [], 'Arabic-ar')); ?> :
                    <?php echo e(@$setting_web->commercial_register); ?>

                </p>
            <?php endif; ?>
            
        </div>
        
    </div>
</header>

<?php if(@$from_date or @$to_date): ?>
    <h4 class="text-center">
        <?php echo e(__('hr.report_from', [], 'Arabic-ar')); ?> <?php echo e(@$from_date); ?> <?php echo e(__('hr.to', [], 'Arabic-ar')); ?>

        <?php echo e(@$to_date); ?>

    </h4>
<?php endif; ?>




















<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/print-header.blade.php ENDPATH**/ ?>