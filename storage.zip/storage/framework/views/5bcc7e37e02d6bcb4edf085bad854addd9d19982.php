<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo addButton($createRoute , $addButtonText); ?>

    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('finance::finance.SL')); ?></th>
            <th> <?php echo e(__("finance::finance.principle")); ?> </th>
            <th> <?php echo e(__("finance::finance.value")); ?> </th>
            <th> <?php echo e(__("finance::finance.date")); ?> </th>
            <th><?php echo e(__("finance::finance.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                {"data": "principle_id", orderable: false, searchable: true},
                {"data": "value", orderable: false, searchable: true},
                {"data": "date", orderable: false, searchable: true},
                {"data": "actions", orderable: false, searchable: false}
            ];
            showDataTable("<?php echo e($dataTableRoute); ?>", columns);
        });

        $(document).ajaxComplete(function() {
            // عند تغيير القائمة المنسدلة
            $('#principle_id').on('change', function() {
                // جلب القيم من الخيار المختار
                const selectedOption = $(this).find('option:selected');
                const perishedAccountId = selectedOption.data('perished_account_id');
                const perishedAccountName = selectedOption.data('perished_account_name');
                const expenseAccountId = selectedOption.data('expense_account_id');
                const expenseAccountName = selectedOption.data('expense_account_name');
                const accountId = selectedOption.data('account_id');

                // تحديث الحقول المخفية والنصية
                $('#perished_account_id').val(perishedAccountId);
                $('#expense_account_id').val(expenseAccountId);
                $('#account_id').val(accountId);

                // تحديث الحقول النصية إذا كانت هناك أسماء معروفة
                $('#perished_account_name').val(perishedAccountId ? `${perishedAccountName}` : '');
                $('#expense_account_name').val(expenseAccountId ? `${expenseAccountName}` : '');
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/manual_depreciations/index.blade.php ENDPATH**/ ?>