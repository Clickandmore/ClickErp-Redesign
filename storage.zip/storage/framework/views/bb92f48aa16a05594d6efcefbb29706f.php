<?php
//$permissions = ['printSettings.create', 'letters.index', 'officialVacations.index', 'departments.index', 'rewards.index', 'permissionsSettings.index', 'tax.index', 'jobs.index', 'allowances.index', 'permissions.index', 'sanctions.index', 'vacation-year.index', 'vacations.index', 'insurances.index', 'shifts.index'];
//
//$employeesPermissions = ['mluti-employee.index', 'employeeExecelFile.index', 'salaries.index', 'daily-work-reports.index', 'employeeAttendances.index', 'employees.index', 'employees.create', 'employees.edit', 'employeeVacations.index', 'employeeSanctions.index', 'employeePermissions.index', 'employee-rewards.index', 'employee-advances.index'];
//?><!---->



<?php
    $hrSettingsRoutes = [
        'hr.home.index',
        'departments.index',
        'jobs.index',
        'allowances.index',
        'sanctions.index',
        'vacation-year.index',
        'vacations.index',
        'employeePermissions.index',
        'permissions.index',
        'insurances.index',
        'tax.index',
        'rewards.index',
        'shifts.index',
        'officialVacations.index',
    ];
//    $readPermissions = array_filter($user_permission_list, function ($permission) use ($hrSettingsRoutes) {
//        return in_array(
//            $permission,
//            array_map(function ($route) {
//                return str_replace('.index', '-read', $route);
//            }, $hrSettingsRoutes),
//        );
//    });
?>








<li>
    <a class="m-link <?php echo e(in_array(Route::currentRouteName(), $hrSettingsRoutes) ? 'active' : ''); ?>"
       href="<?php echo e(route('departments.index')); ?>">
        <i class="fa  fa-file-text-o"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.Settings')); ?></span>
    </a>
</li>



<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employees.index' || Route::currentRouteName() == 'employees.create' || Route::currentRouteName() == 'employees.edit' ? 'active' : ''); ?>"
       href="<?php echo e(route('employees.index')); ?>">
        <i class="fas fa-user"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employees')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employeeVacations.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('employeeVacations.index')); ?>">
        <i class="fas fa-plane"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employeeVacations')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employee-advances.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('employee-advances.index')); ?>">
        <i class="fas fa-money-bill"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employee_advances')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employeeSanctions.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('employeeSanctions.index')); ?>">
        <i class="fas fa-exclamation-triangle"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employeeSanctions')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employeePermissions.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('employeePermissions.index')); ?>">
        <i class="fas fa-key"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employeePermissions')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employeeAttendances.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('employeeAttendances.index')); ?>">
        <i class="fas fa-calendar-check"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employeeAttendances')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employeeExecelFile.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('employeeExecelFile.index')); ?>">
        <i class="fas fa-file-excel"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employeeExecelFile')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'daily-work-reports.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('daily-work-reports.index')); ?>">
        <i class="fas fa-file-alt"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.daily-work-reports')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'mluti-employee.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('mluti-employee.index')); ?>">
        <i class="fas fa-users"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.mluti-employee')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'salaries.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('salaries.index')); ?>">
        <i class="fas fa-dollar-sign"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.salaries')); ?></span>
    </a>
</li>


<li>
    <a class="m-link <?php echo e(Route::currentRouteName() == 'employee-rewards.index' ? 'active' : ''); ?>"
       href="<?php echo e(route('employee-rewards.index')); ?>">
        <i class="fas fa-award"></i>
        <span class="ms-2"> <?php echo e(__('hr::hr.employeeRewards')); ?></span>
    </a>
</li>

<?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr.blade.php ENDPATH**/ ?>