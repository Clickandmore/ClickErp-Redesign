<div class="row g-2" >
    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.department")); ?>    </label>
        <?php echo addUpButton(route('departments.create'),'deparment_id','' ,'title',true); ?>

        <i class="fa fa-asterisk text-danger fs-10"></i>
        <select class="form-control show-tick ms select2" name="deparment_id" id="deparment_id" data-validation="required" onchange="checkOther()">
            <option value=""> <?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>"><?php echo e($department->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.jobs")); ?> </label>
        <?php echo addUpButton(route('jobs.create'),'job_id','' ,'title',true); ?>

        <i class="fa fa-asterisk text-danger fs-10"></i>
        <select class="form-control show-tick ms select2" name="job_id" id="job_id" data-validation="required" onchange="checkOther()">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?> </option>
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($job->id); ?>"><?php echo e($job->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.shifts")); ?>    </label>
        <?php echo addUpButton(route('shifts.create'),'shift_id','' ,'name',true); ?>

        <i class="fa fa-asterisk text-danger fs-10"></i>
        <select class="form-control show-tick ms select2" name="shift_id" id="shift_id" data-validation="required" onchange="checkOther()">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($shift->id); ?>"><?php echo e($shift->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.Date of hiring")); ?> <i class="fa fa-asterisk text-danger fs-10"></i></label>
        <input type="date" name="hired_date" class="form-control" data-validation="required" onchange="checkOther()">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Contract expiration date")); ?>  <i class="fa fa-asterisk text-danger fs-10"></i></label>
        <input type="date" name="contract_end_date" class="form-control" data-validation="required" onchange="checkOther()">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Responsible Employee Report")); ?>   </label>
        <select class="form-control show-tick ms max-select" multiple name="responsible[]">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <table id="myDataTable_no_filter" class="table align-middle card-table">
        <thead>
        <tr>
            <th></th>
            <th>
                <?php echo e(__("hr::hr.vacations")); ?>

                <span><?php echo addUpButton(route('vacations.create'),'allowancesSelect','' ,'title',true,'vacationsSelect'); ?></span>
            </th>
            <th><?php echo e(__("hr::hr.Total days")); ?></th>
            <th> <?php echo e(__("hr::hr.Consumer credit")); ?></th>
            <th> <?php echo e(__("hr::hr.Days left")); ?> </th>
            <th><?php echo e(__("hr::hr.actions")); ?></th>
        </tr>
        </thead>
        <tbody id="json_array3" class="content" data-mfield-options='{"section": ".y-group","btnAdd":"#btnAdd-2","btnRemove":".btnRemove"}'>
        <tr class="y-group">
            <td> </td>
            <td>
                <select class="form-select vacationsSelect" name="vacations[]" id="allowancesSelect">
                    <option value=""><?php echo e(__("hr::hr.Choose vacation")); ?> </option>
                    <?php $__currentLoopData = $vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option data-max="<?php echo e($vacation->number_of_days); ?>" value="<?php echo e($vacation->id); ?>"><?php echo e($vacation->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <input type="number"  readonly name="total_days[]" onkeyup="calculateTotal()" class="form-control total_days">
            </td>
            <td>
                <input type="number" name="token_days[]" onkeyup="calculateTotal()" class="form-control token_days">
            </td>
            <td>
                <input type="number" readonly name="remain_days[]" class="form-control remain_days">
            </td>
            <td>
                <i class="fa fa-plus-circle" id="btnAdd-2"></i>
                <i class="fa fa-trash-o btnRemove"></i>
            </td>
        </tr>
        </tbody>
    </table>

</div>
<?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employees/create/step2.blade.php ENDPATH**/ ?>