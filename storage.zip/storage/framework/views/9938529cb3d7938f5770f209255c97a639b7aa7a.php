<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('message', __('Page Not Found')); ?>
<?php $__env->startSection('firstDigit',4); ?>
<?php $__env->startSection('secondDigit', 0); ?>
<?php $__env->startSection('thirdDigit', 4); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/errors/404.blade.php ENDPATH**/ ?>