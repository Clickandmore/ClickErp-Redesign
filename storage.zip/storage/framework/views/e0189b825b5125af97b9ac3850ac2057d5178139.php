<?php if($data->count() > 0): ?>
    <?php
        $colspan = 6;
        $width   =  35;
    ?>
    <table class="table table-hover table-bordered table-striped" id="simpleTable4" style="width:100%">
        <thead>
        <tr class="header">
            <th style="width: 5%" scope="col">#</th>
            <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.account")); ?></th>
            <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.Transaction Date")); ?></th>
            <th style="width: 5%" scope="col"><?php echo e(__("finance::finance.Transaction Number")); ?></th>
            <th style="width: 10%" scope="col"><?php echo e(__("finance::finance.Transaction Type")); ?></th>

            <th style="width: <?php echo e($width); ?>%" scope="col"><?php echo e(__('finance::finance.statement')); ?></th>
            <th style="width: 5%" scope="col" class="currency-egp"><?php echo e(__("finance::finance.debtor")); ?></th>
            <th style="width: 5%" scope="col" class="currency-egp"><?php echo e(__("finance::finance.creditor")); ?></th>
            <th style="width: 5%" scope="col" class="currency-egp"><?php echo e(__('finance::finance.Balance')); ?></th>
            <th style="width: 5%" scope="col"><?php echo e(__('finance::finance.user')); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php
            $balance = 0;
            $sumCreditorValue = $sumDebtorValue = 0;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $balance += ($row->status == "debtor") ? ($row->debtor_value - $row->creditor_value) : ($row->creditor_value - $row->debtor_value);
                $sumDebtorValue += $row->debtor_value;
                $sumCreditorValue += $row->creditor_value;
                $trClass = ($row->debtor_value == 0 && $row->creditor_value == 0) ? "currency-usd" : "currency-egp";
            ?>
            <tr class="<?php echo e($trClass); ?>">
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e(@$row->account_name); ?></td>
                <td><?php echo e($row->date); ?></td>
                <td><?php echo e($row->constraint_id); ?></td>
                <td><?php echo e(getEnumValue('constraint_types', $row->constraints_type)); ?></td>

                <td><?php echo e($row->statement); ?></td>
                <td class="currency-egp"><?php echo e($row->debtor_value); ?></td>
                <td class="currency-egp"><?php echo e($row->creditor_value); ?></td>
                <td class="currency-egp"><?php echo e($balance); ?></td>
                <td><?php echo e($row->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="<?php echo e($colspan); ?>" class="text-center"><?php echo e(__('finance::finance.Balance')); ?></td>
            <td class="currency-egp"><?php echo e($sumDebtorValue); ?></td>
            <td class="currency-egp"><?php echo e($sumCreditorValue); ?></td>
            <td class="currency-egp" style="background-color: yellow"><?php echo e($balance); ?></td>
            <td></td>
        </tr>
        </tbody>
    </table>
<?php else: ?>
    <div role="alert" class="alert alert-danger text-center"> <?php echo e(__('finance::finance.no_data_found')); ?></div>
<?php endif; ?>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/account_cost_centers/result.blade.php ENDPATH**/ ?>