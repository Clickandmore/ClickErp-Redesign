
<div class="modal fade" data-bs-backdrop="static" id="createModal" tabindex="-1" aria-labelledby="exampleModalLgLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-scrollable <?php echo e((isset($modalType))? $modalType:"modal-xl"); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4" id="exampleModalLgLabel"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body custom_scroll"></div>
            
        </div>
    </div>
</div>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/resources/views/admin/layout/inc/global_modals.blade.php ENDPATH**/ ?>