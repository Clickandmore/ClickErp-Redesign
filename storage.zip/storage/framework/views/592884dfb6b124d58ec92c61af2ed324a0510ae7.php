<?php if($data): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <div class="col-12">
                <input type="checkbox" name="checkbox[]" value="1">
            </div>
        </td>
        <td><?php echo e($index + 1); ?></td>
        <td><?php echo e($item['employee']->name); ?>

            <input type="hidden" readonly name="employee_id[]" value="<?php echo e($item['employee']->id); ?>" style="width:50px"></td>
        <td><?php echo e($item['employee']->departments->title); ?></td>
        <td><?php echo e($item['employee']->salary); ?></td>
        <td><?php echo e($item['attandance_days']); ?>

            <input type="hidden" readonly name="attandance_days[]" value="10" style="width:50px">
        </td>
        <td><?php echo e($item['allowances']); ?>

            <input type="hidden" readonly name="allowances[]" value="<?php echo e($item['allowances']); ?>" style="width:70px">
        </td>
        <td><?php echo e($item['sanctions']); ?>

            <input type="hidden" readonly name="sanctions[]" value="<?php echo e($item['sanctions']); ?>" style="width:70px">
        </td>
        <td><?php echo e($item['insurances_sum']); ?>

            <input type="hidden" readonly name="Insurances[]" value="<?php echo e($item['insurances_sum']); ?>" style="width:70px">
        </td>
        <td><?php echo e($item['taxs']); ?>

            <input type="hidden" readonly name="tax[]" value="<?php echo e($item['taxs']); ?>" style="width:70px">
        </td>
        <td><?php echo e($item['delays']); ?>

            <input type="hidden" readonly name="delays[]" value="<?php echo e($item['delays']); ?>" style="width:70px">
        </td>
        <td><?php echo e($item['net']); ?>

            <input type="hidden" readonly name="final[]" value="<?php echo e($item['net']); ?>" style="width:70px">
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <td style="text-align: center">
        <?php echo e(__("hr::hr.No Data")); ?>

    </td>
<?php endif; ?>

<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/salaries/table.blade.php ENDPATH**/ ?>