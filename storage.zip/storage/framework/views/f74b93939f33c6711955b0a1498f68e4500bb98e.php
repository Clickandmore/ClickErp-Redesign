<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('hr::hr.employeeVacations')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__("finance.clients")); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


















<?php echo addButton(route("employeeVacations.create") , __('hr::hr.employeeVacation_order')); ?>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead>
        <tr>
            <th><?php echo e(__('hr::hr.SL')); ?></th>
            <th><?php echo e(__("hr::hr.Employee")); ?>  </th>
            <th><?php echo e(__("hr::hr.the kind of holiday")); ?></th>
            <th><?php echo e(__("hr::hr.Balance")); ?> </th>
            <th><?php echo e(__("hr::hr.From the date of")); ?></th>
            <th><?php echo e(__("hr::hr.To date")); ?></th>
            <th><?php echo e(__("hr::hr.Date difference")); ?></th>
            <th><?php echo e(__("hr::hr.comments")); ?> </th>
            <th><?php echo e(__("hr::hr.status")); ?></th>
            <th><?php echo e(__("hr::hr.View Attached File")); ?></th>
            <th><?php echo e(__("hr::hr.actions")); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('hr::hr.employeeVacations._js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employeeVacations/index.blade.php ENDPATH**/ ?>