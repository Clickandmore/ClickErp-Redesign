<form class="row g-3 from-submit-global" method="post" action="<?php echo e($storeRoute); ?>" enctype="multipart/form-data">
    <input type="hidden" name="employee_id" value="<?php echo e($employee_id); ?>">

    <div class="col-6">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Permission")); ?> </label>
        <select class="form-control show-tick ms" name="permission_id" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($permission->id); ?>"><?php echo e($permission->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-6">
        <label for="date" class="form-label"><?php echo e(__("hr::hr.date")); ?> </label>
        <input type="date" name="date" min="<?php echo e(date('Y-m-d')); ?>" class="form-control" data-validation="required" onchange="updateDays()">
    </div>

    <div class="col-6">
        <label for="time" class="form-label"><?php echo e(__("hr::hr.Time (minutes)")); ?></label>
        <input type="number" id="time" name="time" class="form-control" data-validation="required">
    </div>

    <div class="col-6">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.comments")); ?> </label>
        <textarea name="reason" class="form-control" data-validation="required" rows="4"></textarea>
    </div>
    <div class="col-md-12 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.file")); ?></label>
        <input type="file"  name="file" class="dropify">
    </div>
    <div class="col-12 modal-footer">
        <?php echo submitButton( $storeRoute ); ?>

        <?php echo closeButton(); ?>

    </div>

</form>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employees/permissions/create.blade.php ENDPATH**/ ?>