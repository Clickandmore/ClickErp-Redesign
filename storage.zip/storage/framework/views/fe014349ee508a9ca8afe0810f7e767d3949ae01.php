<?php $__env->startSection("style"); ?>
    <link rel="stylesheet" href="<?php echo e(asset("admin")); ?>/assets/cssbundle/dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e($bladeTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($bladeTitle); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-4 my-2">
            <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.Employee")); ?></label>
            <select class="form-control select2 show-tick ms" name="employee_id" id="employeeId"
                    data-validation="required">
                <option value=""><?php echo e(__("hr::hr.Choose")); ?> <?php echo e(__("hr::hr.Employee")); ?></option>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-4 my-2">
            <label for="TextInput" class="form-label"><?php echo e(__("hr::hr._date"). ' ' .__("hr::hr.report")); ?></label>
            <input class="form-control" type="date" name="date" id="date">
        </div>

    </div>


    <?php echo addButton($createRoute , $addButtonText); ?>


    <table id="dataTableObject" class="table display dataTable table-hover" style="width:100%">
        <thead class="thead-inverse">
        <tr>
            <th><?php echo e(__('hr::hr.SL')); ?></th>
            <th><?php echo e(__("hr::hr.Employee")); ?></th>
            <th><?php echo e(__("hr::hr.title")); ?></th>
            <th><?php echo e(__("hr::hr.date")); ?></th>
            <th><?php echo e(__("hr::hr.file")); ?></th>
            <th><?php echo e(__('hr::hr.actions')); ?></th>
        </tr>
        </thead>
        <tbody>

        </tbody>

    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("admin")); ?>/assets/js/bundle/dataTables.bundle.js"></script>
    <script>
        $(document).ready(function () {
            let columns = [
                {"data": 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                {"data": "employee_id", orderable: false, searchable: false},
                {"data": "title", orderable: false, searchable: false},
                {"data": "date", orderable: false, searchable: false},
                {"data": "file", orderable: false, searchable: false},
                {"data": "actions", orderable: false, searchable: false}
            ];
            var table = $('#dataTableObject').DataTable({
                responsive: true,
                processing: true,
                serverSide: false,
                ordering: true,
                searching: true,
                iDisplayLength: 10,
                lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "الكل"]],
                "sort": false,
                "ajax": {
                    "url": "<?php echo e($dataTableRoute); ?>",
                    "type": "GET",
                    "data": function (d) {
                        d.employee_id = $('#employeeId').val();
                        d.date = $('#date').val();
                    }
                },
                "columns": columns,
            });

            $('#employeeId').on('change', function () {
                table.ajax.reload();
            });
            $('#date').on('change', function () {
                table.ajax.reload();
            });

        });


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/daily_work_reports/index.blade.php ENDPATH**/ ?>