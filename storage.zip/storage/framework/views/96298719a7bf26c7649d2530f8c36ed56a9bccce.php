<div class="col-md-4 col-12">
    <label><?php echo e(__('finance::finance.Journal Entry Number')); ?> <span class="text-danger">*</span></label>
    <input type="text" class="form-control" name="code" value="<?php echo e($lastCode); ?>"
           placeholder="<?php echo e(__('finance::finance.Journal Entry Number')); ?>" disabled>
    <input type="hidden" name="code" value="<?php echo e($lastCode); ?>">
</div>
<div class="col-md-4 col-12">
    <label><?php echo e(__('finance::finance.date')); ?> <span class="text-danger">*</span></label>
    <input type="date" name="date" data-validation="required" class="form-control" value="<?php echo e(date('Y-m-d')); ?>"
           placeholder="<?php echo e(__('finance::finance.date')); ?>">
</div>
<div class="col-md-4 col-12">
    <label><?php echo e(__('finance::finance.statement')); ?></label>
    <textarea type="text" name="statement" class="form-control form-control-lg mb-1"
              placeholder="<?php echo e(__('finance::finance.statement')); ?>"></textarea>
</div>
<div class="debtor__value"></div>
<table id="myDataTable_no_filter" class="table align-middle card-table">
    <thead>
    <td>
        <div class="w-100 d-flex align-items-center justify-content-between add_debtor">
            <span><?php echo e(__('finance::finance.debtor')); ?> <span class="text-danger">*</span></span>
            <i class="fa fa-plus-circle"></i>
        </div>
    </td>
    <td>
        <div class="w-100 d-flex align-items-center justify-content-between add_creditor">
            <span><?php echo e(__('finance::finance.creditor')); ?> <span class="text-danger">*</span></span>
            <i class="fa fa-plus-circle"></i>
        </div>
    </td>
    <td><?php echo e(__('finance::finance.Account Name')); ?> <span class="text-danger">*</span></td>
    <td>
        <?php echo e(__('finance::finance.fn-cost-centers')); ?>

        <?php if(isset($cost_center_required) && $cost_center_required->value == 'on'): ?>
            <span class="text-danger">*</span>
        <?php endif; ?>
    </td>
    <td><?php echo e(__('finance::finance.Account Statement')); ?></td>
    <td><?php echo e(__('finance::finance.Delete')); ?></td>
    </thead>
    <tbody class="table-body">
    <tr class="item-row debtor_append" id="debtor_append">
        <td>
            <input type="hidden" class="form-control" value="debtor" name="account_type[]">
            <input class="debtor form-control" min="0.01" step="any" data-validation="required" type="number" value="0"
                   name="debtor_value[]">
            <span class="error-span" hidden style='color:red'><?php echo e(__('finance::finance.Enter Valid Values')); ?></span>
        </td>
        <td>
            <input type="hidden" value="0" name="creditor_value[]">
        </td>
        <td>
            <select name="account_id[]" data-validation="required"
                    class="form-control select-account select-unique-option select2">
                <?php echo showSelectElement($accounts, 'name'); ?>

            </select>
        </td>
        <td>
            <select class="form-control show-tick ms select2" name="cost_center_id[]"
                    <?php if(isset($cost_center_required) && $cost_center_required->value == 'on'): ?> data-validation="required" <?php endif; ?>>
                <?php echo showSelectElement($cost_centers, 'title'); ?>

            </select>
            <input type="hidden" name="cost_center_required"
                   value="<?php echo e(isset($cost_center_required) && $cost_center_required->value == 'on' ? 'on' : 'off'); ?>">
        </td>
        <td>
            <textarea name="statement_account[]" class="form-control" placeholder="<?php echo e(__('finance::finance.statement')); ?>"></textarea>
        </td>
        <td><i class="fa fa-trash"></i></td>
    </tr>
    <tr class="item-row" id="creditor_append">
        <td>
            <input type="hidden" value="0" name="debtor_value[]">
        </td>
        <td>
            <input type="hidden" class="form-control" value="creditor" name="account_type[]">
            <input type="number" data-validation="required" min="0.01" step="any" class="creditor form-control" value="0"
                   name="creditor_value[]">
            <span class="error-span" hidden style='color:red'> <?php echo e(__('finance::finance.Enter Valid Values')); ?></span>
        </td>
        <td>
            <select name="account_id[]" data-validation="required"
                    class="form-control select-account select-unique-option select2">
                <?php echo showSelectElement($accounts, 'name'); ?>

            </select>
        </td>
        <td>
            <select class="form-control show-tick ms select2" name="cost_center_id[]"
                    <?php if(isset($cost_center_required) && $cost_center_required->value == 'on'): ?> data-validation="required" <?php endif; ?>>
                <?php echo showSelectElement($cost_centers, 'title'); ?>

            </select>
        </td>
        <td>
            <textarea name="statement_account[]" class="form-control" placeholder="<?php echo e(__('finance::finance.statement')); ?>"></textarea>
        </td>
        <td><i class="fa fa-trash remove_creditor"></i></td>
    </tr>
    </tbody>
    <tfoot>
    <tr>
        <td><input id="debtor_footer_value" class="form-control" value="0" disabled></td>
        <td><input id="creditor_footer_value" class="form-control" value="0" disabled></td>
        <td><?php echo e(__('finance::finance.Total')); ?></td>
        <td></td>
        <td></td>
    </tr>
    </tfoot>
</table>

<hr>
<h4><?php echo e(__('finance::finance.attachments')); ?></h4>
<div class="col-12">
    <div class="work_samples_grid">
        <label class="img_upload">
            <input type="file" accept="image/*" multiple name="file[]" id="img-upload"
                   onchange="handleFileSelect(event)">
            <div class="img justify-content-center">
                <img loading="lazy"
                     src="<?php echo e(asset('admin')); ?>/assets/img/plus.svg"
                     alt="plus"
                     style="width: 30px; height: 30px;">
            </div>
        </label>
    </div>
</div>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/finance/src/../resources/views/finance/constraint/inc/__create.blade.php ENDPATH**/ ?>