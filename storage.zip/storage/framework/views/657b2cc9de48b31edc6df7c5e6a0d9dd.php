<?php $__env->startSection("style"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    <?php echo e(trans('auth.home')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-links'); ?>
<li class="breadcrumb-item active" aria-current="page"> <?php echo e(trans('auth.home')); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
    <div class="container-fluid">

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('nami.layout.indexs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/Data/test/resources/views/nami/dashboard.blade.php ENDPATH**/ ?>