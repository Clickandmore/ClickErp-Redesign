<div class="row g-2" >
    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.department")); ?> </label>
        <?php echo addUpButton(route('departments.create'),'deparment_id','' ,'title',true); ?>

        <select class="form-control show-tick ms" name="deparment_id" id="deparment_id" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?> </option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>" <?php echo e((($department->id==$obj->deparment_id) ? 'selected' : '')); ?>><?php echo e($department->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.jobs")); ?></label>
        <?php echo addUpButton(route('jobs.create'),'job_id','' ,'title',true); ?>

        <select class="form-control show-tick ms" name="job_id" id="job_id" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?> </option>
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($job->id); ?>" <?php echo e((($job->id==$obj->job_id) ? 'selected' : '')); ?>><?php echo e($job->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.shifts")); ?>    </label>
        <?php echo addUpButton(route('shifts.create'),'shift_id','' ,'name',true); ?>

        <select class="form-control show-tick ms" name="shift_id" id="shift_id" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($shift->id); ?>"
                    <?php if(isset($obj->shift->shift->id)): ?>
                    <?php echo e((($shift->id==$obj->shift->shift->id) ? 'selected' : '')); ?>

                    <?php endif; ?>
                    ><?php echo e($shift->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.Date of hiring")); ?> </label>
        <input type="date" name="hired_date" value="<?php echo e($obj->hired_date); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.Contract expiration date")); ?></label>
        <input type="date" name="contract_end_date" value="<?php echo e($obj->contract_end_date); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Responsible Employee Report")); ?>   </label>
        <select class="form-control show-tick ms max-select" multiple name="responsible[]">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?></option>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($employee->id); ?>" <?php echo e($obj->hasResponsible($employee->id) ? 'selected' : ''); ?>><?php echo e($employee->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

</div>

<hr::hr>

<?php if($obj->manyVacations->count() == 0): ?>
<table id="myDataTable_no_filter" class="table align-middle card-table">
   <thead>
   <tr>
       <th></th>
       <th>
           <?php echo e(__("hr::hr.vacations")); ?>

           <span><?php echo addUpButton(route('vacations.create'),'allowancesSelect','' ,'title',true,'vacationsSelect'); ?></span>
       </th>
       <th><?php echo e(__("hr::hr.Total days")); ?></th>
       <th> <?php echo e(__("hr::hr.Consumer credit")); ?></th>
       <th> <?php echo e(__("hr::hr.Days left")); ?> </th>
       <th><?php echo e(__("hr::hr.actions")); ?></th>
   </tr>
   </thead>
   <tbody id="json_array3" class="content" data-mfield-options='{"section": ".y-group","btnAdd":"#btnAdd-2","btnRemove":".btnRemove"}'>
   <?php if( isset($obj->vacations) && count($obj->vacations) > 0): ?>
       <?php $__currentLoopData = $obj->vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacationss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h1><?php echo e(dd($vacationss)); ?></h1>
           <tr class="y-group">
               <td> </td>
               <td>
                   <select class="form-select vacationsSelect" name="vacations[]"  id="allowancesSelect">
                       <option value=""><?php echo e(__("hr::hr.Choose vacation")); ?></option>
                       <?php $__currentLoopData = $vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($vacation->id); ?>" data-max="<?php echo e($vacation->number_of_days); ?>" <?php echo e($vacationss->pivot->vacation_id == $vacation->id ? 'selected' : ''); ?>><?php echo e($vacation->title); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
               </td>
               <td>
                   <input type="hidden" name="vacationss_id[]" value="<?php echo e($vacationss->pivot->id); ?>" class="form-control">
                   <input type="text" name="total_days[]" value="<?php echo e($vacationss->pivot->total_days); ?>" onkeyup="calculateTotal()" class="form-control total_days">
               </td>
               <td>
                   <input type="text" name="token_days[]" value="<?php echo e($vacationss->pivot->token_days); ?>" onkeyup="calculateTotal()" class="form-control token_days">
               </td>
               <td>
                   <input type="text" readonly name="remain_days[]" value="<?php echo e($vacationss->pivot->remain_days); ?>" class="form-control remain_days">
               </td>
               <td>
                   <i class="fa fa-plus-circle" id="btnAdd-2"></i>
                   <i class="fa fa-trash-o btnRemove"></i>
               </td>
           </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php else: ?>
       <tr class="y-group">
           <td> </td>
           <td>
               <select class="form-select vacationsSelect" name="vacations[]" id="allowancesSelect">
                   <option value=""> <?php echo e(__("hr::hr.Choose vacation")); ?></option>
                   <?php $__currentLoopData = $vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option data-max="<?php echo e($vacation->number_of_days); ?>" value="<?php echo e($vacation->id); ?>"><?php echo e($vacation->title); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
           </td>
           <td>
               <input type="hidden" name="vacationss_id[]" class="form-control">
               <input type="number"  readonly name="total_days[]" onkeyup="calculateTotal()" class="form-control total_days">
           </td>
           <td>
               <input type="number" name="token_days[]" onkeyup="calculateTotal()" class="form-control token_days">
           </td>
           <td>
               <input type="number" readonly name="remain_days[]" class="form-control remain_days">
           </td>
           <td>
               <i class="fa fa-plus-circle" id="btnAdd-2"></i>
               <i class="fa fa-trash-o btnRemove"></i>
           </td>
       </tr>
   <?php endif; ?>
   </tbody>
</table>
<?php endif; ?>
<?php /**PATH /mnt/Data/test/packages/hr/src/../resources/views/hr/employees/edit/step2.blade.php ENDPATH**/ ?>