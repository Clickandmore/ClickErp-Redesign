<div class="row g-2">
    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.name")); ?> </label>
        <input type="text" name="name" value="<?php echo e($obj->name); ?>" class="form-control" data-validation="required">
        <input type="hidden" name="employeee_id" value="<?php echo e($obj->id); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.Employee Code")); ?> </label>
        <input type="text" name="code" value="<?php echo e($obj->code); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.the address")); ?> </label>
        <input type="text" name="address" value="<?php echo e($obj->address); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.phone")); ?> </label>
        <input type="text" name="phone" value="<?php echo e($obj->phone); ?>" class="form-control" data-validation="required">
    </div>

    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.date of birth")); ?> </label>
        <input type="date" name="birthday" value="<?php echo e($obj->birthday); ?>" class="form-control" data-validation="required">
    </div>


    <div class="col-md-4 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.ID Number")); ?> </label>
        <input type="text" name="national_num" value="<?php echo e($obj->national_num); ?>" class="form-control"
               data-validation="required">
    </div>


    <div class="col-md-6 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.nationality")); ?> </label>
        <select class="form-control show-tick ms" name="country_id" data-validation="required">
            <option value=""><?php echo e(__("hr::hr.Choose")); ?> <?php echo e(__("hr::hr.nationality")); ?></option>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country->id); ?>"
                    <?php echo e((($country->id==$obj->country_id) ? 'selected' : '')); ?>><?php echo e($country->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-6 col-12">
        <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.Email")); ?> </label>
        <input type="text" name="email" value="<?php echo e($obj->email); ?>" class="form-control" data-validation="required">
    </div>

    <?php if($obj->admin_id): ?>
        <div class="col-md-6 col-12">
            <label for="TextInput" class="form-label"> <?php echo e(__("hr::hr.change password")); ?> </label>
            <input type="password" name="password" class="form-control" placeholder="**********">
        </div>
    <?php else: ?>
        <div class="col-md-6 col-12 mt-5">
            <label class="form-check-label">
                <input type="checkbox" id="createAdminToggle" class="form-check-input">
                <?php echo e(__("hr::hr.Create admin account")); ?>

                <input type="hidden" name="create_admin_account" id="createAdminAccountInput" value="0">
            </label>
        </div>
        <div class="col-md-6 col-12" id="passwordField" style="display: none;">
            <label for="TextInput" class="form-label"> <?php echo e(__("crm.password")); ?> </label>
            <input type="password" name="password" class="form-control" data-validation="required">
        </div>
    <?php endif; ?>




    <div class="col-md-12 col-12">
        <label for="TextInput" class="form-label"><?php echo e(__("hr::hr.image")); ?></label>
        <input type="file" data-default-file="<?php echo e(showFile($obj->image)); ?>" name="image" class="dropify">
    </div>

</div>
<?php /**PATH /mnt/Data/Erp-Rec-Operation/packages/hr/src/../resources/views/hr/employees/edit/step1.blade.php ENDPATH**/ ?>