<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('fn_suppliers', function (Blueprint $table) {
            $table->string('national_address')->nullable()->after('tax_image');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('fn_suppliers', function (Blueprint $table) {
            $table->dropColumn('national_address');
        });
    }
};
