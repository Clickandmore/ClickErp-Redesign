<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('fn_account_transfer_files', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('account_transfer_id')->nullable();
            $table->foreign('account_transfer_id')->references('id')->on('fn_account_transfers')->onDelete('cascade');
            $table->string('file');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('account_transfer_files');
    }
};
