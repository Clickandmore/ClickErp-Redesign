<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('fn_item_collects', function (Blueprint $table) {
            $table->string('notes')->nullable()->default('لا يوجد')->change();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('fn_item_collects', function (Blueprint $table) {
            $table->string('notes')->nullable()->default('لا يوجد')->change();
        });
    }
};
