<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('fn_product_num_settings', function (Blueprint $table) {
            $table->integer('code')->nullable()->change();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('fn_product_num_settings', function (Blueprint $table) {
            $table->integer('code')->nullable(false)->change();

        });
    }
};
