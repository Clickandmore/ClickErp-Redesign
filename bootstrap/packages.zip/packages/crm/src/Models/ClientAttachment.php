<?php

namespace Nami\Crm\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClientAttachment extends Model
{
    use HasFactory;
    protected $table = 'crm_clients_attachments';
    protected $fillable = ['title', 'attachment_id', 'client_id', 'file'];

    public function client()
    {
        return $this->belongsTo(Client::class,'client_id');
    }

    public function attachment()
    {
        return $this->belongsTo(AttachmentCategory::class,'attachment_id');
    }
}
