<?php

namespace Nami\Hr\Services;

use Illuminate\Support\Facades\DB;
use Nami\Hr\MainService;
use Nami\Hr\Models\Country;

class CountriesService extends MainService
{

    public function __construct(Country $model)
    {
        $this->model = $model;
    }

    public function getCountries()
    {
        $countries = DB::table('hr_countries')
            ->join('hr_countries_translations', 'hr_countries.id', '=', 'hr_countries_translations.country_id')
            ->where('hr_countries.deleted', 0)
            ->where('hr_countries_translations.locale', 'ar')
            ->select('hr_countries.id', 'hr_countries_translations.name')
            ->get();
        return $countries;
    }

}
