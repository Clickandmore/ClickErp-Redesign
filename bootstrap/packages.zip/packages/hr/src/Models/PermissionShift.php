<?php

namespace Nami\Hr\Models;

use Nami\Hr\Database\Seeders\Models\Shift;
use Nami\Hr\Database\Seeders\Models\Permission;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PermissionShift extends Model
{
    use HasFactory;
    protected $table = 'hr_permission_shifts';
    protected $fillable = ['shift_id','permission_id'];

    public function permission()
    {
        return $this->belongsTo(Permission::class, 'permission_id');
    }

    public function shift()
    {
        return $this->belongsTo(Shift::class, 'shift_id');
    }
}
