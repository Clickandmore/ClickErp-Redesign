<?php

namespace Nami\Hr\Models;

use Nami\Hr\Database\Seeders\Enums\AllowanceTypeis;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeSalary extends Model
{
    use HasFactory;
    protected $table = 'hr_employee_salary';
    protected $fillable = ['month_year','sanctions','employee_id','allowances','Insurances','tax','delays','attandance_days','final'];

    public function employees()
    {
        return $this->belongsTo(Employee::class,'employee_id');
    }
}
